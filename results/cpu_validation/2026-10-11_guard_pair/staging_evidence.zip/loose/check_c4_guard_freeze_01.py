from pathlib import Path
import json,hashlib,time,pytest
out=Path('external/c4_guard_freeze_checks_01');out.mkdir(exist_ok=False)
wall,cpu=time.perf_counter(),time.process_time()
code=pytest.main(['-q','tests/test_guard_pair_development.py','-k','formal_source_binding or unfrozen_real_physics','--basetemp',str(out/'pytest')])
(out/'execution.json').write_text(json.dumps({'exit_code':code,'wall_seconds':time.perf_counter()-wall,'cpu_seconds':time.process_time()-cpu,'source_sha256':{n:hashlib.sha256(Path(n).read_bytes()).hexdigest() for n in ['src/developmental_physics/guard_pair_development.py','docs/GUARD_PAIR_DEVELOPMENT_PROTOCOL.md']},'fake_calls':0,'actual_physics':0},indent=2)+'\n')
raise SystemExit(code)
