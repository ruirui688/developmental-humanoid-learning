# C4 A 正式执行前独立审查

这轮只读审查发现了影响异常溯源或独立审计的实质问题。调用起点、snapshot 白名单、已知预测失败账与异常 paid counters 已由各自 owner 修正；本审查者没有修改 tracked 文件。尚有一处异常输入诊断可能沿用旧迭代值，建议正式冻结前清空。

审查对象为 `src/developmental_physics/guard_pair_development.py`、`pd_selection_binding.py` 以及 ignored `external/c4_guard_pair_audit_staging/audit_guard_pair_development.py`，并按需只读原模型、原 collect helper、公共标准库 auditor 和已有 synthetic fixture。没有读取新的真实 raw、执行独立 auditor、物理、Git 或 A 科学门。root 随后明确授权一个单例纯 synthetic 日志回归，成本与这部分静态审查分开列在后文。

最近直接审阅的 source SHA256：

| 文件 | SHA256 |
|---|---|
| collector（root 已修 current entry） | `b7e4c35e18ebe34d102d61e317aedb017fff6d4d2f292722571fbf97bfa1fbf6` |
| PD helper | `956c85a08f3c6a6142acb659c0c9f8f49124983ff592b5f8ab9094ee68058b5c` |
| auditor（owner 最终修订版） | `393a2f3673bab952c34ea09a4d79d7d88e78c448e141a4ab83d865ab164dda93` |

审查过程中各 owner 正在修改文件。下列行号以各对应函数和上述最近读取的来源为准；后续修改不能继承本次字节身份或视为已独立验证。

## 具体问题与处理

### 1. P1：before-step 失败记录的观测起点可能陈旧——root 已修，单例回归通过

原 collector 在 planner、诊断预测都完成以后才执行 `previous = observation`。当第二个及以后 active 区间已经成功得到当前 q/v 的 MPC decision，后续诊断 predict 在 step 前失败，异常记录中的 `observation_before` 仍是上次区间的起点。独立 auditor 将从这个旧起点重放已成功的 decision，造成原件与实际数学调用不一致；也损害失败定位。

root 将赋值移到[迭代入口](D:/Codex_ws/robot_rl/src/developmental_physics/guard_pair_development.py:396)，在映射、规划和任何预测之前确认当前起点。修正不改变动作、模型、门或物理预算。后文单例验证 before 与上次正常 after 一致、与上次正常 before 不同，第二次已成功 planner 的当前 q/v 和 ledger 保留，未执行第二步环境调用。

### 2. P1：独立 snapshot exact whitelist 漏掉原 core 三字段——auditor owner 已修

旧 `verify_snapshot` 只允许 parameter record 加 fingerprint/trainable/counts，漏掉原 `PairBodyModel._snapshot_state` 的 `update_commit`、`initial_prior`、`input_boundary`。正常 nominal/initial/learned snapshot 会统一被拒绝，阻塞首次正式审计。

最新版[verify_snapshot](D:/Codex_ws/robot_rl/external/c4_guard_pair_audit_staging/audit_guard_pair_development.py:202) 纳入这三字段并检查固定内容，参数 fingerprint 仍只来自原 parameter record。没有放宽数学、来源、原子账或科学门。owner 已保留发现该问题的原始合成审计失败；本审查未再运行它们。

### 3. P1：已知 PairPredictionError 被误读为未知标量成本——auditor owner 已修

原 core `PairPredictionError` 提供 `to_dict()`，不设置 `pair_prediction_accounting` 属性。collector 将其存到 `failure_accounting.structured_failure`，PredictionMeter 则认出这个原生类型并记录已知标量 heads。旧 `verify_diagnostic_accounting` 只找 `pair_prediction_accounting`，把已知错误要求成 unknown 分支，拒绝合法账本。

最新版[已知失败重构](D:/Codex_ws/robot_rl/external/c4_guard_pair_audit_staging/audit_guard_pair_development.py:464) 仅对严格 `type=PairPredictionError`、五字段 exact schema、原 core stage 与 heads 对应作 fallback：native_features 0/0、velocity_output_0 1/0、velocity_output_1 2/1、endpoint_euler 2/2。其他异常仍保持 unknown/lower-bound 语义；没有用未知异常填假成本。

### 4. P2：有当前异常诊断时，付费累计缺少独立绑定——auditor owner 已修

旧异常分支允许缺失子步在 0..10 内、unreturned 不超过 missing，并把 metadata 与 episode/phase 自洽核对；没有把已经保存的失败时 `diagnostics.step_id/physics_steps/time` 和 episode 付费累计对应。合法范围内同步修改多个汇总字段可掩盖账本错误。

最新版[verify_exception_paid_counters](D:/Codex_ws/robot_rl/external/c4_guard_pair_audit_staging/audit_guard_pair_development.py:844) 对可用当前快照作精确绑定；缺少计数时明确标记剩余账不能独立重构，没有补造交互。

我最初提出的“unreturned 旧 observation_after 与 current qpos 必然不同”一般性判断已撤回：[collect._exception_snapshot](D:/Codex_ws/robot_rl/src/developmental_physics/collect.py:95) 会主动取当前 native observation，collector 的最终 `**` 展开覆盖显式 observation_after。getter 成功时它应与当前 qpos/qvel 对应；只有 `observation_after_retrieval_error` 才可能保留旧确认观测。owner 已按这个明确标志区分。未返回区间的当前快照不成为 RLS 标签。

### 5. P2：异常 input_diagnostics 仍可能沿用上一迭代——正式冻结前建议清空

[input_diagnostics](D:/Codex_ws/robot_rl/src/developmental_physics/guard_pair_development.py:372) 只在 trial 开始初始化；每迭代会清空 predicted，却要所有诊断 predict 成功以后才重建 input mapping。before-step predict/plan 失败时异常行可能保存上一 active 起点 q/u 的 mapping，误导关于当前 guard 屏蔽和力矩权限的解释。它不进入模型，也不会使该异常 trial 通过科学门，但属于实际失败证据的错误标签。

最小修正建议：和 `previous = observation` 一起在每次迭代入口设置 `input_diagnostics = {}`；若需要当前映射，可在相应安全检查完成后、诊断预测之前逐项生成。不能把上一迭代的 mapping 留作这次失败的当前信息。已通知 root；本审查者不修改 tracked。

## 未见实质问题的核验项与边界

- **归因匹配：** raw nominal/learned 共享 raw basis，guard nominal/learned 共享 public guard basis；cold own 先验、P、hinge、Euler 和权限一致。两模型同一完整 transition ID、同一 next-v 标签，顺序 raw 后 guard；后者失败不撤销前者已付费的提交。public rule diagnostic 与各自 RLS contribution 分开，不把 raw→guard 总差全部称学习。
- **因果边界：** 原生八轴观测只提取 j0/j1 q/v，actual torque/contact/qpos/qvel 属日志。校准 preupdate prediction 确实在物理 step 返回后由 RLS 计算，但其输入为区间开始 q/v、已知请求和更新前参数；next-v 只作为标签/评分。独立 prediction 和控制诊断发生在 step 之前。MPC 自身递推重新 G，不读 future actual 或隐藏参数。
- **冻结：** 只有完整校准发布 frozen clone；partial 不更新，完整 terminal 仍可提交/评分但不发布。评估没有 RLS，参数前后 fingerprint 与审计重构状态绑定；失败校准模型不进入独立 baseline。
- **独立 MPC：** 标准库 auditor 重放全部 81×H15 候选、约束、请求努力、tie-break 和 fallback，不导入在线模型或 NumPy。它的未来请求多步诊断明确是离线 labels，且校准 final-fit 诊断注明 in-sample，不计成在线预测能力。
- **完整门：** `complete_trials` 要求恰好三个唯一指定 seed、所需 trial 完整且无环境/研究停止；缺一个 seed、截短、partial、失败均无法通过。模型贡献每 basis 独立，PD 优势另要求本 basis 贡献门已过、完整 PD 和实际努力；最终 `validated_pass` 还需要整个审计零失败、正式来源与冻结 scope。
- **PD 来源：** helper 绑定独立 selection、manifest、first audit 和原 PD metadata/source ZIP 的字节/hash、候选/增益/协议/环境范围。collector 在环境构造前要求当前 clean commit、tracked 来源、归档字节与该 commit blob 一致；auditor 独立重建 binding，并检查 source ZIP 对声明 commit 的 blob 及实际 auditor/support 身份。它不重审此前 trace/episodes，依赖已验证 first audit 与其原 input hashes；本轮审查亦未重读或运行这些原件，不替代正式来源核验。

这里的 prediction 是开发 seed 上单条新采集轨迹，不是新未见最终 bank。固定 controller/target/public guard/初始化都是披露的公共初始条件；没有发现暗中步态教师、任务预训练策略或隐藏物理参数进入学习。静态源码审查不能证明真实学习优势、环境安全、全身技能或整个项目完成，也不证明尚未提升的最新 auditor 已被 root 采用。

## root 新授权的单例合成回归

片段：[test_current_prediction_failure.py](D:/Codex_ws/robot_rl/external/c4_guard_preflight_staging/test_current_prediction_failure.py)。根目录正式 CPU Python `external/cpu_physics_env/Scripts/python.exe`；NumPy 2.2.6、pytest 8.4.2、MuJoCo 3.15.0 仅被导入，环境构造和步进被显式 synthetic fixture 替代。

首次准备 attempt01 因默认 Python 没有可选 MuJoCo 而 **1 skipped / exit 5**；没有执行 collector 或数学，原件保留。换用 root 明确给定解释器后，attempt02 是该 case **唯一实际执行，1 passed**，未重复通过测试。

保留 [stdout](D:/Codex_ws/robot_rl/external/c4_guard_preflight_staging/attempt02/stdout.txt)、[执行与源码快照记录](D:/Codex_ws/robot_rl/external/c4_guard_preflight_staging/attempt02/execution.json)、[原始逐 trial 证据](D:/Codex_ws/robot_rl/external/c4_guard_preflight_staging/attempt02/regression_evidence.json)。test SHA256 `0259d2d547072a5de1658ac2e97c3a5b2497e66433359c45b4a1559a06bfbcd6`，evidence SHA256 `2a3761bbd5748cc5fb9d404abb7560def6c5ea04dd879d1ba8eec53599592a37`。

| 成本 | 值 |
|---|---:|
| pytest.main wall / CPU s | 0.5021969000808895 / 0.390625 |
| 真实物理 / Git / 新真实 raw | 0 / 0 / 0 |
| synthetic 环境调用 / 完成区间 / 子步 counter | 31 / 31 / 310 |
| 人工校准 committed vector / scalar RLS | 4 / 8 |
| diagnostic pair attempted / success，scalar attempted / success | 16 / 15，30 / 30 |
| RLS internal pair attempted / success，scalar attempted / success | 4 / 4，8 / 8 |
| SyntheticPlanner 报告占位账 pair / scalar | 8 / 16 |

SyntheticPlanner 没有执行数学候选预测，所报 placeholder ledger 只用于验证 collector 没漏成功 planner 账，不能算成实际执行的额外模型数学。实际模型预测为 diagnostic+RLS 共 20 pair attempts / 19 success、38 scalar attempts/success；已知人工 before-head 错误耗零标量 head。模型更新和 synthetic counter 不加到正式物理累计。

该 injected `PairPredictionError` 的 stage 明确为人工 `synthetic_before_velocity_heads`，作用仅为当前观测/成功 planner 日志回归。生产 auditor 只接受原 core 四种 stage，应该拒绝这个人工 stage；本case不作为 production audit fixture，也未执行 audit。root 可提升受影响日志断言，在提升后的源字节上运行相关工程测试。
