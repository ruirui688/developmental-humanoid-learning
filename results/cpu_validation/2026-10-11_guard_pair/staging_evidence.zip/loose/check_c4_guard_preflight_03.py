from pathlib import Path
import json,hashlib,time,pytest
out=Path('external/c4_guard_preflight_promoted_03')
out.mkdir(exist_ok=False)
wall,cpu=time.perf_counter(),time.process_time()
code=pytest.main(['-q','tests/test_audit_guard_pair_development.py','tests/test_guard_pair_development.py','-k','audit_guard_pair_development or successful_second_active or paid_unreturned or failed_planner or failed_second_model or failed_calibration_model or interrupt_adjacent or trace_write_failure','--basetemp',str(out/'pytest')])
files=['scripts/audit_guard_pair_development.py','tests/test_audit_guard_pair_development.py','tests/test_guard_pair_development.py','src/developmental_physics/guard_pair_development.py']
synthetic=[]
for p in (out/'pytest').rglob('metadata.json'):
    d=json.loads(p.read_text())
    if d.get('suite')=='guard_pair_development_draft':
        synthetic.append({k:d[k] for k in ('control_calls_attempted','control_steps','physics_steps','model_updates')})
e={'exit_code':code,'wall_seconds':time.perf_counter()-wall,'cpu_seconds':time.process_time()-cpu,'source_sha256':{n:hashlib.sha256(Path(n).read_bytes()).hexdigest() for n in files},'raw_fake_ledgers':synthetic,'actual_physics':0,'git_operations':0}
(out/'execution.json').write_text(json.dumps(e,indent=2)+'\n')
raise SystemExit(code)
