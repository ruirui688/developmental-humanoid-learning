"""Read-only correction of the promoted-check wrapper's synthetic suite filter."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parents[1]
base = root/'external/c4_guard_promoted_01'
output = base/'reconciled_synthetic_accounting.json'
assert not output.exists()
records = []
for path in sorted((base/'work').rglob('metadata.json')):
    metadata = json.loads(path.read_text(encoding='utf-8'))
    if metadata.get('suite') == 'guard_pair_development' and metadata.get('synthetic') is True:
        records.append({'path': path.relative_to(base).as_posix(),
            **{key: metadata[key] for key in ('control_calls_attempted', 'control_steps',
                                             'physics_steps', 'model_updates')}})
record = {'reason': 'Original wrapper incorrectly filtered guard_pair_development_draft; '
                    'the collector retains suite=guard_pair_development with synthetic=True. '
                    'Original execution.json is preserved; no tests or collection repeated.',
          'original_execution_sha256': hashlib.sha256((base/'execution.json').read_bytes()).hexdigest(),
          'synthetic_archives': records,
          'synthetic_total_cost': {key: sum(row[key] for row in records)
              for key in ('control_calls_attempted', 'control_steps', 'physics_steps', 'model_updates')}}
output.write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
print(json.dumps(record['synthetic_total_cost']))
