"""Single exclusive regression attempt; no formal execution or Git."""
from contextlib import redirect_stderr, redirect_stdout
import hashlib
import json
from pathlib import Path
import platform
import sys
import time

sys.dont_write_bytecode = True
staging = Path(__file__).resolve().parent
root = staging.parents[1]
output = staging/"attempt01"
output.mkdir(exist_ok=False)
sources = [staging/"test_current_prediction_failure.py", Path(__file__).resolve()]+[
    root/name for name in (
        "tests/test_guard_pair_development.py", "src/developmental_physics/guard_pair_development.py",
        "src/developmental_physics/pd_selection_binding.py", "src/developmental_physics/guard_pair_model.py",
        "src/developmental_physics/local_pair_model.py", "src/developmental_physics/local_model.py",
        "src/developmental_physics/collect.py", "src/developmental_physics/environment.py",
        "src/developmental_physics/feedback_validate.py", "src/developmental_physics/probes.py",
    )
]
records = {}
for path in sources:
    data = path.read_bytes()
    relative = path.relative_to(root).as_posix()
    target = output/"sources"/relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    records[relative] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
sys.path.insert(0, str(root/"src"))
sys.path.insert(0, str(root/"tests"))
import numpy
import pytest
arguments = [str(staging/"test_current_prediction_failure.py"), "-q", "-p", "no:cacheprovider",
             "--junitxml", str(output/"tests.xml"), "--basetemp", str(output/"synthetic_tmp")]
wall, cpu = time.perf_counter(), time.process_time()
with (output/"stdout.txt").open("w", encoding="utf-8") as stream:
    with redirect_stdout(stream), redirect_stderr(stream):
        result = pytest.main(arguments)
execution = {
    "exit_code": int(result), "wall_seconds": time.perf_counter()-wall,
    "cpu_seconds": time.process_time()-cpu, "timing_scope": "pytest.main only; imports/source snapshot excluded",
    "python": platform.python_version(), "numpy": numpy.__version__, "pytest": pytest.__version__,
    "actual_physical_calls": 0, "actual_physical_substeps": 0, "git_operations": 0,
    "sources": records, "pytest_arguments": arguments,
}
evidence = list((output/"synthetic_tmp").rglob("regression_evidence.json"))
if len(evidence) == 1:
    raw = evidence[0].read_bytes()
    (output/"regression_evidence.json").write_bytes(raw)
    execution["regression_evidence_sha256"] = hashlib.sha256(raw).hexdigest()
(output/"execution.json").write_text(json.dumps(execution, indent=2)+"\n", encoding="utf-8")
print((output/"stdout.txt").read_text(encoding="utf-8"))
print(json.dumps(execution, indent=2))
raise SystemExit(int(result))
