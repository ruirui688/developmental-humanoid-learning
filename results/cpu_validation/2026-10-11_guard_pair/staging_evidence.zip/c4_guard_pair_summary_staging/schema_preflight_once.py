"""Authorized metadata/first-audit schema reads only; not formal summary/re-audit."""
import hashlib
import json
from pathlib import Path
import time

ROOT = Path(__file__).resolve().parents[2]
output = Path(__file__).resolve().parent / "schema_preflight01"
output.mkdir(exist_ok=False)
started, cpu = time.perf_counter(), time.process_time()
paths = {"metadata": ROOT / "external/guard_pair_20261011_first/metadata.json",
         "first_audit": ROOT / "external/guard_pair_20261011_first_audit.json"}
records, documents = {}, {}
for key, path in paths.items():
    raw = path.read_bytes()
    records[key] = {"path": str(path), "filesystem_reads": 1, "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}
    documents[key] = json.loads(raw)
metadata, audit = documents["metadata"], documents["first_audit"]
report = {"original_read_records": records, "purpose": "Root-authorized schema-only preparation, no formal summary/audit replay",
          "audit_sha256": audit.get("audit_script_sha256"), "immutable_scope": audit.get("immutable_scope"),
          "audit_checks": audit.get("checks"), "audit_failed": audit.get("failed"),
          "metadata_keys": sorted(metadata), "archived_source_member_count": len(metadata["source_sha256"]),
          "metadata_pd_gains": metadata.get("pd_gains"), "audit_archive_keys": sorted(audit["archive"]),
          "audit_final_gates": audit["final_gates"],
          "audit_input_hash_mapping_keys": sorted(audit["archive"]["input_hashes"]),
          "metadata_commit": metadata["source_commit"], "saved_budget": audit["archive"]["budget"],
          "audit_execution": audit.get("execution"), "audit_seed_keys": [sorted(seed) for seed in audit["archive"]["seeds"]],
          "audit_evaluation_keys": {kind: sorted(ev) for kind, ev in audit["archive"]["seeds"][0]["evaluations"].items()},
          "physical_calls": 0, "updates": 0, "new_body_predictions": 0, "audit_executions": 0,
          "true_trace_reads": 0, "true_PD_raw_reads": 0,
          "wall_seconds": time.perf_counter() - started, "cpu_seconds": time.process_time() - cpu}
(output / "schema_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({k: report[k] for k in ("metadata_commit", "audit_sha256", "audit_checks", "audit_failed", "saved_budget", "metadata_pd_gains", "audit_input_hash_mapping_keys", "audit_execution", "audit_evaluation_keys")}))
