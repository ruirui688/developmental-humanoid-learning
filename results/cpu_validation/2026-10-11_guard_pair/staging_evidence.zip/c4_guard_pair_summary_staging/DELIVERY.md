# C4 A 一次描述性汇总交付

工具已封口：`summarize_guard_pair_once.py` SHA256 为
`e25fbc329c2e60d87b4e8da66c64b1c9cefa8c012c6ac47a95655231f4c98c78`。
只用 Python 标准库，不导入或执行 collector、身体模型、MPC、RLS、审计器、MuJoCo 或 NumPy。

接口：

```powershell
python external/c4_guard_pair_summary_staging/summarize_guard_pair_once.py --input external/guard_pair_20261011_first --audit external/guard_pair_20261011_first_audit.json --output external/guard_pair_20261011_summary_01
```

输出目录必须原先不存在。六份 raw 原件与 first_audit 各读取一次，读取失败也计尝试并保留；JSON、gzip、ZIP 与哈希均使用缓存字节。写出 `summary.json`、`execution.json`、`read_cost.json`、`attempt.json` 与 `tool_source.py`。工具自己的前后源码读取及输出封口哈希不属于原始实验文件读取。

绑定使用 `first_audit.archive.input_hashes` 的精确六文件覆盖，并验证 manifest、source ZIP 唯一成员/精确覆盖/逐成员 SHA、归档 auditor 与实际支持代码身份、协议身份、clean 源码声明及冻结生产 scope。冻结 auditor SHA 为 `393a2f3673bab952c34ea09a4d79d7d88e78c448e141a4ab83d865ab164dda93`。不重新执行 Git 查询，复述首审已经完成的源码 Git 原字节核验；不解包或重读 PD 原 trace。

科学门直接复制首审的 evaluated/passed/validated_pass；汇总不重判门，不排名，不用截短 RMSE 宣称闭环改善。每 seed、每 axis/joint 的匹配 raw/guard 贡献与 PD 比较、公共规则诊断、原预测指标、停止/partial/缺失完整分母、conditional/free-rollout、风险/努力、规划与诊断成本均保留。独立 prediction 的误差比只是已保存指标的算术描述，不能被错误写成控制门成功或预测失败。物理停止是合法报告；字节绑定或解析失败才形成失败汇总，原件不变。

## 首次人工测试

`run_fixture_tests.py` 只执行 handmade fixture。`attempt01/` 保留三份测试/工具源码快照、完整日志、人工 raw 六文件及人工 first_audit、独立 `test_cost.json`。

- 19 tests，0 failures、0 errors、0 skipped，首次运行通过。
- wall 1.0009938001 s，CPU .8125 s。
- 人工 fixture 模拟 18 complete/6 terminated，learned_raw active2、learned_guard active4；保留 200-active 规划分母而不把截短结果变成优势。
- 真 A/PD raw 读取、物理调用、RLS 更新/重放、身体预测、MPC 重放、审计执行及 Git 查询均为 0。
- 覆盖 metadata/manifest/首审六哈希、冻结身份、重复 ZIP、ZIP 成员篡改、重复 JSON/非有限数、假 validated flag、once reader 二次拒绝、失败读取计账、输出目录排他、独立 prediction 描述与控制门分离。
- 测试内部的 auditor pin 临时替换仅用于惰性人工成员；正式 CLI 没有修改 pin 的参数。

## 已授权的 schema 准备读取

在 root 授权人工 fixture 后只读真实 metadata/first_audit 准备 schema 的消息下，`schema_preflight_once.py` 各读取它们一次。`schema_preflight01/schema_report.json` 保存精确路径、字节数、SHA、读取数、时长和 scope。这项读取发生在 root 随后的停止预读消息收到前；收到后停止并主动报告。真 trace、其他 A raw、PD raw 读取为 0，无汇总/模型/审计运行。此成本与正式 once-only 汇总的读取账本分列，不能省略。

## root 的正式一次执行

root 已报告 `external/guard_pair_20261011_summary_01` 首次执行成功：6,489 个描述性绑定检查、0 失败，wall 1.256351800 s，六 raw 与 first_audit 各一次，新模型/物理/审计调用均为 0。这里不读取或重新核验真实 summary；正式费用和原件由 root 归档。

A 身体学习贡献与 PD 比较均 evaluated=false/passed=false。完整独立 prediction 有数值改善，不能据此掩盖 learned 控制停止，不能把首审与 summary 的 0 一致性失败称为科学通过。开发 seed 已见；无技能、安全、成熟、变化适应或独立最终泛化结论。

## 后续封口

当前目录、`INTEGRITY.json` 与原测试 attempt 只含本任务 ignored staging 产物；没有 tracked 编辑、Git 操作或新的实验运行。root 负责纳入 A 原始档案、提交/推送与下一阶段协议。本工具不再修改，真实 A/PD 原件不再读取。
