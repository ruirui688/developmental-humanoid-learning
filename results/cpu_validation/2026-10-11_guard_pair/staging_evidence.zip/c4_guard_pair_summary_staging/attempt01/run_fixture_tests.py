"""Once-only artificial test runner, with source snapshots and cost ledger."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import time
import unittest

ROOT = Path(__file__).resolve().parent
output = ROOT / "attempt01"
output.mkdir(exist_ok=False)
started, cpu = time.perf_counter(), time.process_time()
sources = {}
for name in ("summarize_guard_pair_once.py", "test_summary.py", "run_fixture_tests.py"):
    blob = (ROOT / name).read_bytes()
    (output / name).write_bytes(blob)
    sources[name] = hashlib.sha256(blob).hexdigest()
spec = importlib.util.spec_from_file_location("handmade_summary_tests", ROOT / "test_summary.py")
tests = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tests)
reads = []
original_read = tests.summary.OnceReader.read
def counted_read(self, key, path):
    entry = {"key": key, "path": str(path), "artifact_kind": "artificial fixture", "success": False}
    reads.append(entry)
    try:
        value = original_read(self, key, path)
        entry["success"] = True
        entry["bytes"] = len(value)
        return value
    except BaseException as error:
        entry["failure"] = {"type": type(error).__name__, "message": str(error)}
        raise
tests.summary.OnceReader.read = counted_read
raw, audit, pin = tests.fixture()
fixture_dir = output / "artificial_fixture"
fixture_dir.mkdir()
for name, data in raw.items():
    (fixture_dir / name).write_bytes(data)
(output / "artificial_first_audit.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
stream = io.StringIO()
suite = unittest.defaultTestLoader.loadTestsFromModule(tests)
result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
(output / "stdout.txt").write_text(stream.getvalue(), encoding="utf-8")
report = {"created_at_utc": datetime.now(timezone.utc).isoformat(), "artificial_only": True,
          "tests_run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
          "skips": len(result.skipped), "source_sha256": sources, "python": sys.version,
          "wall_seconds": time.perf_counter() - started, "cpu_seconds": time.process_time() - cpu,
          "fixture_original_read_wrapper_calls": len(reads), "fixture_successful_reads": sum(r["success"] for r in reads),
          "fixture_read_records": reads, "fixture_pin_override": pin,
          "true_A_or_PD_raw_reads": 0, "physical_simulation_calls": 0, "model_parameter_updates": 0,
          "body_predictions": 0, "RLS_replays": 0, "MPC_replays": 0, "auditor_executions": 0, "git_queries": 0,
          "mathematical_work": "JSON/hash/gzip/ZIP binding and saved-metric arithmetic only; no body model computation",
          "claim_boundary": "Engineering fixture checks only; no physical/scientific efficacy evidence"}
(output / "test_cost.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(stream.getvalue(), end="")
print(json.dumps({k: report[k] for k in ("tests_run", "failures", "errors", "skips", "wall_seconds", "cpu_seconds", "true_A_or_PD_raw_reads")}))
raise SystemExit(not result.wasSuccessful())
