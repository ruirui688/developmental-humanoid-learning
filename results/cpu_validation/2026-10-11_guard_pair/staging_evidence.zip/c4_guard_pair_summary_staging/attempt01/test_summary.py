"""Handmade evidence tests only: no physical collector/model/auditor imports."""
from copy import deepcopy
import gzip
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

spec = importlib.util.spec_from_file_location("once_summary_fixture_module", Path(__file__).with_name("summarize_guard_pair_once.py"))
summary = importlib.util.module_from_spec(spec)
spec.loader.exec_module(summary)


def encoded(value):
    return json.dumps(value, sort_keys=True, allow_nan=False).encode()


def fixture():
    """Artificial mirrors of the production schema, never scientific evidence."""
    members = {name: ("Handmade inert fixture member: " + name).encode() for name in summary.REQUIRED_MEMBERS}
    source_stream = io.BytesIO()
    with zipfile.ZipFile(source_stream, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, blob in sorted(members.items()):
            archive.writestr(name, blob)
    source_zip = source_stream.getvalue()
    source_hashes = {name: summary.sha256(blob) for name, blob in members.items()}
    zero_cost = {key: 0 for key in summary.MATH_KEYS}
    zero_cost.update(scalar_counts_complete=True, scalar_counts_is_lower_bound=False)
    episodes, seeds, derived_seeds, lines = [], [], [], []
    for seed in range(3):
        saved_evs, audit_evs = {}, {}
        for kind in summary.KINDS:
            tid = f"seed{seed}_{kind}"
            duration = 400 if kind == "calibration" else 100 if kind == "prediction" else 200
            actual = 2 if kind == "learned_raw" else 4 if kind == "learned_guard" else duration
            stopped = kind.startswith("learned_")
            status = "terminated" if stopped else "completed"
            budget = {"control_calls_attempted": 100 + actual, "control_steps": 100 + actual, "physics_steps": (100 + actual) * 10}
            active_phase = kind if kind in ("calibration", "prediction") else "control"
            phase_budget = {phase: dict.fromkeys(summary.BUDGET_KEYS, 0) for phase in summary.PHASES}
            phase_budget["prefix"] = {"control_calls_attempted": 100, "control_steps": 100, "physics_steps": 1000}
            phase_budget[active_phase] = {"control_calls_attempted": actual, "control_steps": actual, "physics_steps": actual * 10}
            stop = {"type": "StudyAbort", "active_index": actual - 1, "triggers": [{"joint_index": 1, "signal": "absolute_velocity_rad_s"}]} if stopped else None
            episodes.append({"trial_id": tid, "seed": seed, "kind": kind, "maximum_control_steps": 100 + duration,
                "status": status, "reason": "study_velocity" if stopped else None, "collector_exception": None,
                **budget, "phase_budgets": phase_budget, "study_abort": stop,
                "returned_unwritten_steps": 0, "unreturned_physics_steps": 0})
            prediction = {model: {"joint": .02 if model.startswith("learned") else .03,
                          "per_axis": [.02, .018] if model.startswith("learned") else [.03, .03],
                          "complete_endpoints": 100} for model in summary.EXPECTED_SCOPE["input_bases"]}
            prediction["persistence"] = {"joint": .04, "per_axis": [.04, .04], "complete_endpoints": 100}
            diagnostic = deepcopy(zero_cost)
            diagnostic.update(pair_prediction_attempts=4 * actual if kind == "prediction" else actual if kind in summary.KINDS[2:6] else 0,
                              pair_prediction_successes=4 * actual if kind == "prediction" else actual if kind in summary.KINDS[2:6] else 0)
            diagnostic["scalar_prediction_attempts"] = diagnostic["scalar_prediction_successes"] = 2 * diagnostic["pair_prediction_attempts"]
            saved_evs[kind] = {"completed": not stopped, "status": status, "study_abort": stop,
                "position_prediction_rmse": prediction if kind == "prediction" else {},
                "velocity_prediction_rmse": prediction if kind == "prediction" else {},
                "metric_prediction_step_count": {model: 100 for model in prediction} if kind == "prediction" else {},
                "diagnostic_prediction_accounting": diagnostic, "planning_accounting": deepcopy(zero_cost),
                "actual_effort_complete": True, "actual_effort_is_lower_bound": False,
                "planner_fallbacks": 0}
            audit_evs[kind] = {"eligible": not stopped, "completed": not stopped, "status": status,
                "tracking_rmse_rad": .01 if stopped else .03, "tracking_rmse_by_axis_rad": [.01, .01] if stopped else [.03, .03],
                "stored_returned_endpoints": 100 + actual, "collector_confirmed_written_endpoints": 100 + actual,
                "collector_returned_endpoints": 100 + actual, "complete_score_endpoints": actual,
                "partial_score_endpoints": 0, "unreconstructed_physics_substeps": 0,
                "conditional_rollouts": {"fixture_saved_not_recomputed": True, "planned_denominator": duration,
                                         "complete_start_count": max(0, actual - 15)},
                "target_segments_and_planned_tails": {"segment1_last20": {"planned_count": 20, "missing_complete_count": 20 if stopped else 0}}}
            for index in range(100 + actual):
                lines.append(encoded({"trial_id": tid, "seed": seed, "kind": kind, "step_index": index,
                    "phase": "prefix" if index < 100 else active_phase,
                    "requested_torque": [0.] * 8, "target_q": [.04, .04] if index >= 100 and active_phase == "control" else None,
                    "observation_before": {"joint_position": [0.] * 8, "joint_velocity": [0.] * 8},
                    "observation_after": {"joint_position": [0.] * 8, "joint_velocity": [0., 1.] + [0.] * 6 if stopped and index == 99 + actual else [0.] * 8},
                    "study_abort": stop if index == 99 + actual else None}))
        rls_cost = deepcopy(zero_cost)
        rls_cost.update(pair_prediction_attempts=400, pair_prediction_successes=400,
                        scalar_prediction_attempts=800, scalar_prediction_successes=800)
        seeds.append({"seed": seed, "reset_seed": seed + 100, "reference_q": [0., 0.], "direction": [1, 1],
                      "calibration_completed": True, "evaluations": saved_evs,
                      "rls_prediction_accounting": {"learned_raw": rls_cost, "learned_guard": rls_cost}})
        derived_seeds.append({"seed": seed, "evaluations": audit_evs,
                              "calibration_scalar_updates": 1600, "calibration_vector_updates": 800})
    budget = {key: sum(ep[key] for ep in episodes) for key in summary.BUDGET_KEYS}
    budget.update(model_updates=4800, vector_model_updates=2400)
    metadata = {"suite": "guard_pair_development", "synthetic": False, "gpu": None, "backend": "MuJoCo CPU",
                "seeds": [0, 1, 2], "pose": "supine", "joint_indices": [0, 1], "split": "development",
                "native_joint_count": 8, "model_input_bases": summary.EXPECTED_SCOPE["input_bases"],
                "source_status": "", "source_dirty": False, "source_commit": "f" * 40,
                "source_sha256": source_hashes, "source_snapshot_sha256": summary.sha256(source_zip),
                "independent_auditor": {"path": summary.AUDITOR, "sha256": source_hashes[summary.AUDITOR], "pending": False, "required_for_formal": True},
                "protocol": {"path": summary.PROTOCOL, "sha256": source_hashes[summary.PROTOCOL]},
                **budget, "planned_episode_count": 24, "maximum_control_steps": 7500, "maximum_physics_steps": 75000,
                "maximum_scalar_updates": 4800, "maximum_vector_updates": 2400}
    raw = {"metadata.json": encoded(metadata), "episodes.json": encoded(episodes), "seed_results.json": encoded(seeds),
           "trace.jsonl.gz": gzip.compress(b"\n".join(lines) + b"\n"), "source_snapshot.zip": source_zip}
    raw["manifest.json"] = encoded({name: summary.sha256(blob) for name, blob in raw.items()})
    gates = {"model_contribution": {}, "selected_pd_comparison": {}, "complete_matrix": False,
             "thresholds_frozen": True, "data_consistency_verified": True,
             "public_rule_diagnostic": {"available": True, "per_seed": [{"seed": seed, "guard_relative_improvement": change} for seed, change in enumerate((-.005, .015, -.005))]}}
    for group in ("model_contribution", "selected_pd_comparison"):
        gates[group] = {basis: {"basis": basis, "evaluated": False, "passed": False, "validated_pass": False,
                      "per_seed": [{"seed": seed, "eligible": False} for seed in range(3)]} for basis in ("raw", "guard")}
    audit = {"schema_version": 1, "immutable_scope": deepcopy(summary.EXPECTED_SCOPE),
        "audit_script_sha256": source_hashes[summary.AUDITOR],
        "audit_dependency_sha256": {name: source_hashes[name] for name in summary.SUPPORTS},
        "checks": 100, "failed": 0, "violations": [], "maximum_recomputation_difference": 0.,
        "archive": {"input_hashes": {name: summary.sha256(blob) for name, blob in raw.items()},
                    "episodes": episodes, "seeds": derived_seeds, "budget": budget, "native_joint_order": list(summary.JOINTS)},
        "final_gates": gates, "execution": {"physical_simulation_calls": 0, "model_parameter_updates": 0,
                                              "source_git_verification_enabled": True}}
    return raw, audit, source_hashes[summary.AUDITOR]


def rebind_raw(raw, audit):
    """Refresh artificial file identities only, never first-audit numbers."""
    raw = dict(raw)
    raw["manifest.json"] = encoded({name: summary.sha256(blob) for name, blob in raw.items() if name != "manifest.json"})
    audit = deepcopy(audit)
    audit["archive"]["input_hashes"] = {name: summary.sha256(blob) for name, blob in raw.items()}
    return raw, audit


class SummaryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw, cls.audit, cls.pin = fixture()

    def run_summary(self, raw=None, audit=None):
        with patch.object(summary, "EXPECTED_AUDITOR_SHA256", self.pin):
            return summary.summarize(raw or self.raw, encoded(self.audit if audit is None else audit), summary.Bindings())

    def test_stopped_controls_legal_summary_not_scientific_pass(self):
        result = self.run_summary()
        self.assertEqual(result["statuses"], {"completed": 18, "terminated": 6})
        self.assertEqual(result["paid_budget"]["control_calls_attempted"], 6318)
        self.assertTrue(result["prior_audit_data_consistency_verified"])
        self.assertFalse(result["scientific_gates_recomputed"])
        self.assertFalse(result["control_ranking_computed"])
        self.assertTrue(all(not flag["validated_pass"] for group in result["scientific_gate_flags"].values() for flag in group.values()))

    def test_truncated_denominators_and_raw_metrics_preserved(self):
        result = self.run_summary()
        stopped = [t for t in result["trials"] if t["status"] == "terminated"]
        self.assertEqual([t["endpoint_coverage"]["complete_score_endpoints"] for t in stopped], [2, 4] * 3)
        self.assertTrue(all(t["planned_active_calls"] == 200 and t["tracking"]["truncated_descriptive_only"] for t in stopped))
        self.assertTrue(all(not t["scientific_comparison_usable"] for t in stopped))
        self.assertEqual(stopped[0]["first_audit_diagnostics"]["conditional_rollouts"]["planned_denominator"], 200)

    def test_independent_prediction_improvement_is_not_control_gate(self):
        result = self.run_summary()
        for row in result["per_seed"]:
            prediction = row["independent_prediction"]
            self.assertTrue(prediction["completed"])
            reductions = prediction["comparisons"]["raw"]["velocity"]["descriptive_axis_relative_error_reduction"]
            self.assertAlmostEqual(reductions[0], 1 / 3)
            self.assertAlmostEqual(reductions[1], .4)
            self.assertNotIn("passed", prediction)

    def test_saved_cost_sum_no_online_calls(self):
        result = self.run_summary()
        self.assertEqual(result["cost_totals"]["calibration_rls_prediction_accounting"]["pair_prediction_attempts"], 2400)
        self.assertEqual(result["cost_totals"]["diagnostic_prediction_accounting"]["pair_prediction_attempts"], 2418)
        self.assertTrue(all(v == 0 for v in result["summary_new_computation_cost"].values()))

    def test_original_bytes_tamper_rejected_even_valid_json(self):
        raw = dict(self.raw)
        raw["episodes.json"] += b" "
        with self.assertRaisesRegex(summary.EvidenceError, "Manifest original-byte"):
            self.run_summary(raw=raw)

    def test_first_audit_six_hash_mapping_required(self):
        audit = deepcopy(self.audit)
        audit["input_hashes"] = audit["archive"].pop("input_hashes")
        with self.assertRaisesRegex(summary.EvidenceError, "archive.input_hashes"):
            self.run_summary(audit=audit)

    def test_no_unknown_raw_hash_key(self):
        audit = deepcopy(self.audit)
        audit["archive"]["input_hashes"]["extra.json"] = "a" * 64
        with self.assertRaisesRegex(summary.EvidenceError, "six-byte"):
            self.run_summary(audit=audit)

    def test_auditor_identity_pin_rejected(self):
        with self.assertRaisesRegex(summary.EvidenceError, "Frozen first-auditor"):
            summary.summarize(self.raw, encoded(self.audit), summary.Bindings())

    def test_archived_support_identity_rejected(self):
        audit = deepcopy(self.audit)
        audit["audit_dependency_sha256"][summary.SUPPORTS[0]] = "a" * 64
        with self.assertRaisesRegex(summary.EvidenceError, "support bytes"):
            self.run_summary(audit=audit)

    def test_duplicate_zip_member_rejected(self):
        raw, audit = dict(self.raw), deepcopy(self.audit)
        stream = io.BytesIO(raw["source_snapshot.zip"])
        with zipfile.ZipFile(stream, "a") as archive:
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", UserWarning)
                archive.writestr(summary.AUDITOR, b"duplicate inert fixture")
        raw["source_snapshot.zip"] = stream.getvalue()
        metadata = json.loads(raw["metadata.json"])
        metadata["source_snapshot_sha256"] = summary.sha256(raw["source_snapshot.zip"])
        raw["metadata.json"] = encoded(metadata)
        raw, audit = rebind_raw(raw, audit)
        with self.assertRaisesRegex(summary.EvidenceError, "duplicate source ZIP"):
            self.run_summary(raw=raw, audit=audit)

    def test_member_bytes_must_match_source_sha(self):
        raw, audit = dict(self.raw), deepcopy(self.audit)
        source = io.BytesIO()
        with zipfile.ZipFile(io.BytesIO(raw["source_snapshot.zip"])) as old, zipfile.ZipFile(source, "w") as new:
            for name in old.namelist():
                new.writestr(name, b"changed fixture byte" if name == summary.SUPPORTS[0] else old.read(name))
        raw["source_snapshot.zip"] = source.getvalue()
        metadata = json.loads(raw["metadata.json"])
        metadata["source_snapshot_sha256"] = summary.sha256(raw["source_snapshot.zip"])
        raw["metadata.json"] = encoded(metadata)
        raw, audit = rebind_raw(raw, audit)
        with self.assertRaisesRegex(summary.EvidenceError, "Archived member-byte"):
            self.run_summary(raw=raw, audit=audit)

    def test_scope_redefinition_rejected(self):
        audit = deepcopy(self.audit)
        audit["immutable_scope"]["control_steps"] = 4
        with self.assertRaisesRegex(summary.EvidenceError, "production first-audit scope"):
            self.run_summary(audit=audit)

    def test_false_integrity_does_not_become_scientific_pass(self):
        audit = deepcopy(self.audit)
        audit["failed"] = 1
        audit["final_gates"]["data_consistency_verified"] = False
        result = self.run_summary(audit=audit)
        self.assertFalse(result["prior_audit_data_consistency_verified"])

    def test_forged_validated_flag_rejected(self):
        audit = deepcopy(self.audit)
        audit["final_gates"]["model_contribution"]["raw"]["validated_pass"] = True
        with self.assertRaisesRegex(summary.EvidenceError, "validated scientific flag"):
            self.run_summary(audit=audit)

    def test_duplicate_json_and_nonfinite_rejected(self):
        for data in (b'{"x":0,"x":1}', b'{"x":NaN}', b'{"x":Infinity}'):
            with self.subTest(data=data), self.assertRaises(summary.EvidenceError):
                summary.parse_json(data)

    def test_safe_zip_names(self):
        for value in ("../evil.py", "/evil.py", "D:/evil.py", "sub\\evil.py", "sub//evil.py", "sub/./evil.py", "sub/", ""):
            self.assertFalse(summary._valid_member(value), value)
        self.assertTrue(summary._valid_member("src/example.py"))

    def test_second_read_denied_and_counted_once(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "one"
            path.write_bytes(b"one")
            reader = summary.OnceReader()
            self.assertEqual(reader.read("metadata.json", path), b"one")
            with self.assertRaisesRegex(summary.EvidenceError, "Second original-file"):
                reader.read("metadata.json", path)
            self.assertEqual(reader.record()["total_original_read_attempts"], 1)

    def test_execute_preserves_artifacts_and_each_file_read_once(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            raw_dir = root / "raw"
            raw_dir.mkdir()
            for name, data in self.raw.items():
                (raw_dir / name).write_bytes(data)
            audit_path = root / "first_audit.json"
            audit_path.write_bytes(encoded(self.audit))
            with patch.object(summary, "EXPECTED_AUDITOR_SHA256", self.pin):
                code, result = summary.execute(raw_dir, audit_path, root / "out")
            self.assertEqual(code, 0)
            self.assertEqual(result["summary_status"], "bound_descriptive_summary")
            read_cost = json.loads((root / "out/read_cost.json").read_bytes())
            self.assertEqual(read_cost["total_original_read_attempts"], 7)
            self.assertTrue(all(row["successful_reads"] == 1 for row in read_cost["original_inputs"].values()))
            self.assertTrue((root / "out/execution.json").exists())
            with self.assertRaises(FileExistsError):
                summary.execute(raw_dir, audit_path, root / "out")

    def test_failed_read_attempt_preserved(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            raw_dir = root / "raw"
            raw_dir.mkdir()
            for name, data in self.raw.items():
                (raw_dir / name).write_bytes(data)
            code, result = summary.execute(raw_dir, root / "missing_audit", root / "out")
            self.assertEqual(code, 1)
            self.assertEqual(result["summary_status"], "binding_or_parse_failed")
            read_cost = json.loads((root / "out/read_cost.json").read_bytes())
            self.assertEqual(read_cost["total_original_read_attempts"], 7)
            self.assertEqual(read_cost["original_inputs"]["first_audit"]["successful_reads"], 0)
            self.assertEqual(read_cost["original_inputs"]["first_audit"]["read_attempts"], 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
