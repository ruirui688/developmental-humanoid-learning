from pathlib import Path
stage=Path('D:/Codex_ws/robot_rl/external/c4_guard_pair_audit_staging');p=stage/'body_fragment.py.txt';s=p.read_text()
needle="""                endpoint=exception.get('observation_after')
                if endpoint is not None and exception.get('qpos') is not None and exception.get('qvel') is not None:
                    checks.check(endpoint['joint_position']==vector(exception['qpos'],15)[7:]
                        and endpoint['joint_velocity']==vector(exception['qvel'],14)[6:],'exception_native_encoder_mapping',tid)
"""
assert needle in s
s=s.replace(needle,"                verify_exception_native_mapping(exception,checks,tid)\n")
insert="""def verify_exception_native_mapping(exception,checks,location):
    endpoint=exception.get('observation_after')
    qpos,qvel=exception.get('qpos'),exception.get('qvel')
    if qpos is not None: vector(qpos,15)
    if qvel is not None: vector(qvel,14)
    returned=exception.get('returned_step_diagnostics') is not None
    if endpoint is not None and qpos is not None and qvel is not None and returned:
        checks.check(endpoint['joint_position']==qpos[7:] and endpoint['joint_velocity']==qvel[6:],
            'returned_exception_native_encoder_mapping',location)
    return {'native_observation_after_is_returned_endpoint':returned,
        'native_observation_after_is_last_confirmed_endpoint':not returned,
        'qpos_qvel_are_failure_time_snapshot':qpos is not None and qvel is not None,
        'unreturned_snapshot_is_not_a_native_learning_label':not returned}

"""
s=s.replace('def audit_archive(',insert+'def audit_archive(',1)
s=s.replace("'complete_score_endpoints':len(tracking),'partial_score_endpoints':len(partial_errors)}", "'complete_score_endpoints':len(tracking),'partial_score_endpoints':len(partial_errors),\n                'exception_native_time_semantics':[verify_exception_native_mapping(ex,checks,tid+'/derived_exception') for ex in exceptions]}")
p.write_text(s,encoding='utf-8',newline='\n')
