from pathlib import Path
stage=Path('D:/Codex_ws/robot_rl/external/c4_guard_pair_audit_staging')
(stage/'repair_attempt03/setup_failure.json').write_text('{"type":"AssertionError","message":"Pure engineering repair audit forbids all Git/subprocess.","origin":"pytest setup imported pyreadline3 -> platform.system -> win32_ver -> subprocess.check_output; stub was installed before pytest setup","tests_run":0,"simulation_calls":0,"model_updates":0,"git_calls":0}',encoding='utf-8')
s=(stage/'run_repair03.py').read_text(encoding='utf-8-sig').replace('repair_attempt03','repair_attempt04')
s=s.replace('a.subprocess.run=forbidden',"import platform\nplatform._uname_cache=platform.uname_result('Windows','synthetic','synthetic','synthetic','synthetic')\na.subprocess.run=forbidden")
(stage/'run_repair04.py').write_text(s,encoding='utf-8',newline='\n')
