from pathlib import Path
stage=Path('D:/Codex_ws/robot_rl/external/c4_guard_pair_audit_staging');p=stage/'gates.py.txt';s=p.read_text(encoding='utf-8-sig')
needle="""        failed=ex.get('failure_accounting',{}).get('pair_prediction_accounting')
        if failed is not None:
"""
repl="""        failed=ex.get('failure_accounting',{}).get('pair_prediction_accounting')
        structured=ex.get('failure_accounting',{}).get('structured_failure')
        if failed is None and type(structured) is dict and structured.get('type')=='PairPredictionError':
            _exact(structured,{'type','message','scalar_prediction_attempts','scalar_prediction_successes','failure_stage'})
            stages={'native_features':(0,0),'velocity_output_0':(1,0),'velocity_output_1':(2,1),'endpoint_euler':(2,2)}
            counts=(structured['scalar_prediction_attempts'],structured['scalar_prediction_successes'])
            if (structured['failure_stage'] not in stages or any(type(x) is not int for x in counts)
                or counts!=stages[structured['failure_stage']] or type(structured['message']) is not str):
                raise ValueError('Exact known PairPredictionError stage/head accounting required.')
            failed=structured
        if failed is not None:
"""
assert needle in s;s=s.replace(needle,repl);p.write_text(s,encoding='utf-8',newline='\n')
s=(stage/'run_unit01.py').read_text(encoding='utf-8-sig').replace('unit_attempt01','unit_attempt07');(stage/'run_unit07.py').write_text(s,encoding='utf-8',newline='\n')
