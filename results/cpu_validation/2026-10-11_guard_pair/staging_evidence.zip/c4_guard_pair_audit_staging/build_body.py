from pathlib import Path
root=Path('D:/Codex_ws/robot_rl')
stage=root/'external/c4_guard_pair_audit_staging'
old=(root/'scripts/audit_pair_frozen.py').read_text(encoding='utf-8')
body=old[old.index('def verify_transition'):old.index('def audit(path,')]
# Keep independently implemented native/partial/effort/risk audit helpers.
body=body.replace("def require_pair(path,spec=PAIR_DEVELOPMENT_SPEC):", "def unused_old_require_pair(path,spec=None):")
start=body.index('def unused_old_require_pair('); end=body.index('def verify_exception_updates(',start)
body=body[:start]+body[end:]
body=body.replace('PAIR_DEVELOPMENT_SPEC','PRODUCTION_SPEC')
body=body.replace("('diagonal','coupled')", "('learned_raw','learned_guard')")
body=body.replace("{'diagonal','coupled'}", "{'learned_raw','learned_guard'}")
body=body.replace("kind.startswith('prediction_')", "kind=='prediction'")
body=body.replace("kind!='combined_pd'", "kind!='PDselected'")
body=body.replace("kind=='combined_pd'", "kind=='PDselected'")
body=body.replace("kind.removesuffix('_mpc')", "kind")
body=body.replace("name=kind.removesuffix('_mpc')", "name=kind")
body=body.replace("states['nominal']=initial_state('diagonal_hinge5')", "states.update({name:initial_state(STRUCTURES[name],ranges[:2]) for name in ('nominal_raw','nominal_guard')})")
body=body.replace("initial_state(STRUCTURES[name])", "initial_state(STRUCTURES[name],ranges[:2])")
body=body.replace("states={'nominal':initial_state('diagonal_hinge5'),**{name:initial_state(STRUCTURES[name],ranges[:2]) for name in ('learned_raw','learned_guard')}}", "states={name:initial_state(STRUCTURES[name],ranges[:2]) for name in STRUCTURES}")
body=body.replace("name!='nominal'", "name.startswith('learned_')")
body=body.replace("name=='nominal'", "name.startswith('nominal_')")
body=body.replace("spec.pd_gains[i][1]", "metadata['pd_gains']['kd'][i]")
body=body.replace("spec.pd_gains", "metadata['pd_gains']")
body=body.replace("active_states={name:states[name] for name in ('learned_raw','learned_guard')} if kind=='calibration' else states", "active_states=({name:states[name] for name in LEARNED} if kind=='calibration' else states if kind=='prediction' else {kind:states[kind]} if kind in MPC_KINDS else {})")
body=body.replace("if kind!='calibration': predictions['persistence']", "if kind=='prediction' or kind in MPC_KINDS: predictions['persistence']")
body=body.replace("'all_five_required_trials_complete'", "'all_four_required_trials_complete'")
# Atomic helper remains structurally unchanged but state records are guard aware.
body=body.replace("common.verify_sources(path,metadata,checks,git_root,required=spec.required_sources)", "verify_sources(path,metadata,checks,git_root,spec)")
body=body.replace("'structures':['diagonal_hinge5','coupled_hinge9']", "'structures':['diagonal_hinge5']")
body=body.replace("'update_order':['diagonal','coupled']", "'update_order':['learned_raw','learned_guard']")
body=body.replace("spec.calibration_steps+2*spec.prediction_steps+5*spec.control_steps", "spec.calibration_steps+spec.prediction_steps+6*spec.control_steps")
body=body.replace("checks.compare(metadata['prediction_block_amplitudes_nm'],{k:list(v) for k,v in PRED_AMPLITUDES.items()},'prediction_doses')", "checks.compare(metadata['prediction_block_amplitudes_nm'],list(PRED_AMPLITUDES),'prediction_doses')")
body=body.replace("checks.compare(metadata['pd_boundary'],'combination of separately tuned single-axis gains; not a tuned two-axis strong baseline','combined_pd_boundary')", "verify_pd_binding(path,metadata,checks,spec)")
body=body.replace("5+/5zero/5-/5zero", "1+/9zero/1-/9zero")
body=body.replace("frozen_5pulse_schedule", "frozen_1pulse_schedule")
# Pair snapshot verification also checks nominal and mapping identities.
needle="if not states: states.update({name:initial_state(STRUCTURES[name],ranges[:2]) for name in ('nominal_raw','nominal_guard')})"
repl=needle+"\n                    for name in NOMINAL:\n                        verify_snapshot(sr['nominal_models'][name],states[name],qref,checks,tid+'/nominal/'+name)\n                        checks.compare(sr['nominal_models'][name]['trainable'],False,tid+'/nominal_frozen/'+name)"
assert needle in body;body=body.replace(needle,repl)
# Only complete calibration intervals carry RLS returned predictions.
needle="predictions={name:predict(s['observed_theta'],s['structure'],qref,q,v,u) for name,s in active_states.items()}"
repl="predictions={name:predict(s['observed_theta'],s['structure'],qref,q,v,u) for name,s in active_states.items()} if kind!='calibration' or n==10 else {}\n                checks.compare(row['model_input_diagnostics'],{name:describe_input(q,u,s['structure']) for name,s in active_states.items()},location+'/causal_input_projection')"
assert needle in body;body=body.replace(needle,repl)
# Diagnostic counters are audited separately from MPC and RLS.
needle="if ev['planner_spec'] is not None:"
repl="verify_diagnostic_accounting(ev,regular,exceptions,kind,checks,tid,prefix_steps)\n            "+needle
assert needle in body;body=body.replace(needle,repl)
needle="final_vector=sum(s['count'] for name,s in states.items() if name.startswith('learned_'))"
repl="verify_rls_accounting(sr,regular,exceptions,states,checks,tid,prefix_steps)\n                "+needle
assert needle in body;body=body.replace(needle,repl)
(stage/'body_fragment.py.txt').write_text(body,encoding='utf-8',newline='\n')
print(len(body.splitlines()))
