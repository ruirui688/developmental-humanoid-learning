from pathlib import Path
stage=Path('D:/Codex_ws/robot_rl/external/c4_guard_pair_audit_staging');p=stage/'body_fragment.py.txt';s=p.read_text()
start=s.index('def verify_exception_native_mapping(');end=s.index('def audit_archive(',start)
s=s[:start]+'''def verify_exception_native_mapping(exception,checks,location):
    endpoint=exception.get('observation_after');qpos,qvel=exception.get('qpos'),exception.get('qvel')
    if qpos is not None: vector(qpos,15)
    if qvel is not None: vector(qvel,14)
    returned=exception.get('returned_step_diagnostics') is not None
    retrieval_error=exception.get('observation_after_retrieval_error')
    if retrieval_error is not None:
        checks.check(type(retrieval_error) is dict and type(retrieval_error.get('type')) is str
            and type(retrieval_error.get('message')) is str,'explicit_native_snapshot_retrieval_failure',location)
    current_snapshot=retrieval_error is None
    if endpoint is not None and qpos is not None and qvel is not None and current_snapshot:
        checks.check(endpoint['joint_position']==qpos[7:] and endpoint['joint_velocity']==qvel[6:],
            'current_exception_native_encoder_mapping',location)
    return {'physical_interval_returned':returned,'native_after_current_failure_snapshot':current_snapshot,
        'native_after_fallback_to_last_confirmed_endpoint':not current_snapshot,
        'qpos_qvel_are_failure_time_snapshot':qpos is not None and qvel is not None,
        'unreturned_snapshot_is_not_a_native_learning_label':not returned}

def verify_exception_paid_counters(exception,ep,checks,location):
    diagnostics=exception.get('diagnostics')
    available=type(diagnostics) is dict and all(key in diagnostics for key in ('step_id','physics_steps','time'))
    if available:
        checks.compare(diagnostics['step_id'],ep['control_steps'],location+'/failure_control_counter')
        checks.compare(diagnostics['physics_steps'],ep['physics_steps'],location+'/failure_physics_counter')
        checks.compare(diagnostics['time'],ep['physics_steps']*PHYSICS_DT,location+'/failure_physical_time')
        if 'terminated' in diagnostics:
            checks.compare(diagnostics['terminated'],ep['environment_terminated'],location+'/failure_environment_stop')
    return {'failure_time_counters_available':available,
        'paid_budget_bound_to_saved_failure_time_counters':available,
        'missing_failure_time_counters_make_remaining_cost_not_independently_reconstructed':not available}

'''+s[end:]
s=s.replace("verify_exception_native_mapping(exception,checks,tid)\n", "verify_exception_native_mapping(exception,checks,tid)\n                verify_exception_paid_counters(exception,ep,checks,tid)\n")
s=s.replace("'exception_native_time_semantics':[verify_exception_native_mapping(ex,checks,tid+'/derived_exception') for ex in exceptions]", "'exception_native_time_semantics':[verify_exception_native_mapping(ex,checks,tid+'/derived_exception') for ex in exceptions],\n                'exception_failure_time_paid_counters':[verify_exception_paid_counters(ex,ep,checks,tid+'/derived_failure_counter') for ex in exceptions]")
p.write_text(s,encoding='utf-8',newline='\n')
p=stage/'test_audit_guard_pair_development.py';s=p.read_text(encoding='utf-8-sig');start=s.index('def test_unreturned_changed_qpos_is_distinct_from_last_confirmed_native():');s=s[:start]+'''def test_native_retrieval_failure_can_preserve_last_confirmed_endpoint():
    endpoint={'joint_position':[0.]*8,'joint_velocity':[0.]*8}
    ex={'observation_after':endpoint,'qpos':[0.]*7+[.123]*8,'qvel':[0.]*6+[.2]*8,'returned_step_diagnostics':None,
        'observation_after_retrieval_error':{'type':'ValueError','message':'fixture current getter unavailable'}}
    checks=a.Checks();semantics=a.verify_exception_native_mapping(ex,checks,'e')
    assert checks.failed==0 and semantics['native_after_fallback_to_last_confirmed_endpoint']
    assert semantics['unreturned_snapshot_is_not_a_native_learning_label']
    ex.pop('observation_after_retrieval_error')
    current_checks=a.Checks();a.verify_exception_native_mapping(ex,current_checks,'e')
    assert current_checks.failed==1

def test_unreturned_paid_counters_bind_saved_failure_snapshot():
    ep={'control_steps':100,'physics_steps':1003,'environment_terminated':False}
    ex={'diagnostics':{'step_id':100,'physics_steps':1003,'time':2.006,'terminated':False}}
    checks=a.Checks();result=a.verify_exception_paid_counters(ex,ep,checks,'e')
    assert checks.failed==0 and result['paid_budget_bound_to_saved_failure_time_counters']
    bad_ep=dict(ep,physics_steps=1004)
    bad=a.Checks();a.verify_exception_paid_counters(ex,bad_ep,bad,'e');assert bad.failed==2

def test_unreturned_native_snapshot_can_be_current_but_is_not_rls_label():
    ex={'observation_after':{'joint_position':[.1]*8,'joint_velocity':[.2]*8},
        'qpos':[0.]*7+[.1]*8,'qvel':[0.]*6+[.2]*8,'returned_step_diagnostics':None}
    checks=a.Checks();result=a.verify_exception_native_mapping(ex,checks,'e')
    assert checks.failed==0 and result['native_after_current_failure_snapshot'] and result['unreturned_snapshot_is_not_a_native_learning_label']
'''
p.write_text(s,encoding='utf-8',newline='\n')
s=(stage/'run_unit01.py').read_text(encoding='utf-8-sig').replace('unit_attempt01','unit_attempt06');(stage/'run_unit06.py').write_text(s,encoding='utf-8',newline='\n')
