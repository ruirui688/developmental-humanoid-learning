from pathlib import Path
stage=Path('D:/Codex_ws/robot_rl/external/c4_guard_pair_audit_staging')
p=stage/'body_fragment.py.txt';s=p.read_text()
start=s.index('def conditional_rollouts(');end=s.index('def state_coverage(',start)
replacement='''def conditional_rollouts(rows,states,qref,horizons=(2,5,15),*,prefix_steps=100,active_steps=200):
    regular={r['step_index']:r for r in rows if 'collector_exception' not in r}
    exception_indices={r.get('step_index') for r in rows if 'collector_exception' in r}
    result={}
    for name,state in [*states.items(),('persistence',None)]:
        output={}
        for horizon in horizons:
            endpoint_q,endpoint_v,path_q,path_v=[],[],[],[];excluded=Counter();terminal=0
            planned=max(active_steps-horizon+1,0)
            for start in range(prefix_steps,prefix_steps+planned):
                window=[regular.get(i) for i in range(start,start+horizon)]
                if any(i in exception_indices for i in range(start,start+horizon)):
                    excluded['collector_exception']+=1;continue
                if any(r is None for r in window): excluded['missing_endpoint']+=1;continue
                if any(r['diagnostics']['executed_substeps']!=10 for r in window): excluded['partial_interval']+=1;continue
                if any(r.get('study_abort') is not None or r['diagnostics']['terminated'] for r in window[:-1]):
                    excluded['crosses_terminal']+=1;continue
                if any(window[i-1]['observation_after']!=window[i]['observation_before'] for i in range(1,horizon)):
                    excluded['native_discontinuity']+=1;continue
                q,v=[window[0]['observation_before'][k][:2] for k in ('joint_position','joint_velocity')]
                paths=[]
                try:
                    for row in window:
                        u=row['requested_torque'][:2]
                        if state is None: q=[q[i]+DT*v[i] for i in range(2)]
                        else: q,v=predict(state['observed_theta'],state['structure'],qref,q,v,u)
                        if not all(finite(x) for x in q+v): raise ValueError('Nonfinite rollout.')
                        paths.append((q.copy(),v.copy()))
                except ValueError: excluded['nonfinite_rollout']+=1;continue
                eq=[];ev=[]
                for row,(pq,pv) in zip(window,paths):
                    eq.append([row['observation_after']['joint_position'][i]-pq[i] for i in range(2)])
                    ev.append([row['observation_after']['joint_velocity'][i]-pv[i] for i in range(2)])
                endpoint_q.append(eq[-1]);endpoint_v.append(ev[-1]);path_q.extend(eq);path_v.extend(ev)
                terminal+=window[-1].get('study_abort') is not None or window[-1]['diagnostics']['terminated']
            output[str(horizon)]={'expected_windows_from_planned_active_duration':planned,
                'available_saved_active_starts':sum(i>=prefix_steps for i in regular),'valid_windows':len(endpoint_q),
                'excluded_windows':sum(excluded.values()),'exclusion_reasons':dict(excluded),
                'windows_ending_in_terminal':terminal,'endpoint_q_rmse':paired_rmse(endpoint_q),
                'endpoint_v_rmse':paired_rmse(endpoint_v),'path_q_rmse':paired_rmse(path_q),'path_v_rmse':paired_rmse(path_v)}
        result[name]=output
    return {'models':result,'horizons':list(horizons),'recorded_future_requests_are_offline_labels':True,
        'online_future_information':False,'rule':'Free recursive prediction from one current native endpoint; no future true-state feedback.'}

'''
s=s[:start]+replacement+s[end:]
s=s.replace("conditional_rollouts(rows,states,qref,prefix_steps=prefix_steps)","conditional_rollouts(rows,states,qref,prefix_steps=prefix_steps,active_steps=trial_duration(kind))")
s=s.replace("'policy_parameter_updates':0,'gain_updates':0,'planned_episode_count':8*len(spec.seeds),", "'policy_parameter_updates':0,'gain_updates':0,'gate_updates':0,'planned_episode_count':8*len(spec.seeds),\n        'maximum_physics_steps':75000,'maximum_vector_updates':2400,\n        'maximum_independent_prediction_pair_calls':1200,'maximum_mpc_prediction_pair_calls':2916000,\n        'model_input_bases':dict(STRUCTURES),'guard_recomputed_on_each_predicted_start':True,")
s=s.replace("checks.compare(metadata['backend']", "checks.check(metadata['control_calls_attempted']<=7500 and metadata['control_steps']<=7500 and metadata['physics_steps']<=75000 and metadata['model_updates']<=4800,'batch_paid_budget_caps')\n    checks.compare(metadata['backend']",1)
s=s.replace("state_coverage(grouped.get(f'seed{seed}_calibration',[]),regular,qref)","state_coverage([r for r in grouped.get(f'seed{seed}_calibration',[]) if 'collector_exception' not in r],regular,qref)")
s=s.replace("for phase in risk:\n                risk[phase]['target_guarded_substeps_by_axis']", "for phase in risk:\n                risk[phase]['telemetry_missing_paid_substeps']=missing_physics if phase=='full' else ep['phase_budgets'][phase]['physics_steps']-phase_physics[phase]\n                risk[phase]['request_applied_mismatch_count_is_lower_bound']=risk[phase]['telemetry_missing_paid_substeps']>0\n                risk[phase]['target_guarded_substeps_by_axis']")
s=s.replace("risk[phase]['reconstruction_complete']=missing_physics==0 and not exceptions", "risk[phase]['reconstruction_complete']=risk[phase]['telemetry_missing_paid_substeps']==0\n                risk[phase]['risk_semantics']='Substep force/energy/impulse/penetration and request/applied screening; native speed/limit excursion from returned endpoints. Missing telemetry makes peaks/impulse/counts lower bounds, minimum contact distance an upper bound.'")
p.write_text(s,encoding='utf-8',newline='\n')
# Strengthen snapshot/causal metadata strictness independently.
p=stage/'header.py.txt';s=p.read_text(encoding='utf-8-sig')
s=s.replace("checks.compare(saved,parameter_record(qref,state),location+'/parameters')", "checks.check(set(saved)==set(parameter_record(qref,state))|{'parameter_fingerprint','vector_update_count','scalar_update_count','output_update_counts','trainable'},'exact_snapshot_parameter_whitelist',location)\n    checks.compare(saved,parameter_record(qref,state),location+'/parameters')")
p.write_text(s,encoding='utf-8',newline='\n')
