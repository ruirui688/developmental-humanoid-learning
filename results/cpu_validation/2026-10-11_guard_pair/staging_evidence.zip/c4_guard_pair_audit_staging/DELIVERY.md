# C4 A 独立标准库审计交付

全部编辑仅在 ignored `external/c4_guard_pair_audit_staging/`。未修改 tracked、未运行真实物理、未读真实新 raw 或 PD 原件、未调用 Git。仿真和算法在线模型均没有被 auditor 导入；collector schema联调仅替换假环境，原 RLS/MPC 数学在假 encoder 标签上执行。

## 提升与运行

- `audit_guard_pair_development.py` → `scripts/audit_guard_pair_development.py`
- `test_audit_guard_pair_development.py` → `tests/test_audit_guard_pair_development.py`
- 正式 CLI：`python scripts/audit_guard_pair_development.py --input RAW_DIRECTORY --output NEW_AUDIT_JSON`

auditor SHA-256：`393a2f3673bab952c34ea09a4d79d7d88e78c448e141a4ab83d865ab164dda93`。
tests SHA-256：`84529d8837cd94b6072cd12591f3280b4056a817f083658d49e4741a86d86dfe`。

生产 `GuardPairAuditSpec` 固定 0/1/2、supine、j0/j1、原8D、100前缀、400校准、100独立预测、200控制、1/9与24trial矩阵。纯 synthetic spec 仍是相同计划，只可建立工程一致性，scientific_gates_frozen=False、所有 validated_pass 永远 False。metadata不能缩短/替换生产scope。正式collector flag、commit/freeze由root掌握，本交付不执行它。

源码依赖只有标准库、`scripts/audit_local_frozen.py` 与 `scripts/audit_pair_frozen.py`。生产路径从仓库root定位，与ignored草稿无运行依赖。实际sourceZIP核验会对执行中auditor和两份support原字节核验，检查clean commit、包中全部py、每份ZIP与Gitblob、协议哈希、asset关节范围；生产必需PD五文件来源路径固定为selection.json、manifest.json、**first_audit.json**、raw/metadata.json、raw/source_snapshot.zip，以及原PD协议。原PDtrace/episodes不重读，不重新执行原PD审计。

## 独立重算范围

原生白名单/八轴位置速度映射、全部请求与实际子步history、权限、前缀一致性、qref/方向、研究停止等号和末区间、partial/失败/未返回/未写盘/努力未知账本、完整分phase risk、饱和/fallback均独立核验。固定public guard的clip、方向、等号、原生q不裁、causal feature projection与每个预测起点递推独立计算。两head原子RLS提议/提交、失败后实际count、shared transition、系数/P/fingerprint和冻结评估核验均不调用在线模型。

四MPC所有81候选/H15、常数vector成本、界限、回退、exact tie-break、planning scalar/pair统计独立重算。RLS内部预测、独立prediction、控制起点诊断分别核算，失败scalar未知明示lower bound。各模型/persistence 2/5/15 free recursive窗口从计划active时长生成完整分母，末端terminal允许评分但不能穿过terminal；partial、异常、缺失按原因排除。原生q/v校准支持域、全分段与planned末20独立报告，均不额外改变采用门。

PD五原件身份重建独立于helper：strict JSON/schema/每份SHA、原validated_selection/zero失败/不可变PDscope、picked索引/64增益/gridKd/预算、metadata原8D/seed/目标/权限/环境/更新边界、manifest raw hashes=原audit input_hashes，以及内层sourceZIP的协议/原auditor/support身份逐项核验。没有使用已选候选的物理表现调门。

raw和guard分别按root事前固定贡献门与已选PD比较门判断；公共规则nominal_guard vs nominal_raw单列，不能把raw→guard总差归RLS。没有新增安全/技能/泛化/完整old low-full复现结论。

## 合成测试、联调和原始失败

| 尝试 | 结果 | wall / CPU s | fake成本 / 真物理 |
|---|---|---|---|
| unit_attempt01 | 45pass | .785852 / .625 | 0 / 0 |
| schema_attempt01 | 初版952,995 checks，0fail | collector5.406914 / 5.1875；collector+audit10.751623 / 10.484375 | 3918调用/39180子步/4800scalar假标签；真0 |
| unit_attempt02 | 55pass | .743348 / .609375 | 0 / 0 |
| schema_attempt02 | 183,929 checks，42fail，均是snapshot whitelist缺字段 | collector1.500935 / 1.421875；总2.183306 / 2.09375 | 1515调用/15150子步/6scalar假标签；真0 |
| repair_attempt03 | pytest setup stub错误，0tests/0audit | 未完成计时；setup_failure.json保留 | 0 / 0 |
| repair_attempt04 | 56pass；只读修复重算两份原件953,480/184,181 checks，各0fail | 全部7.036183 / 6.921875 | 没有collector重跑，0 / 0 |

schema_attempt01完整执行24计划；3校准、3独立预测完整，18条控制各在第一active左肘速度=1触发固定StudyAbort，保留末区间评分。它验证terminal/schema，不称完整200控制通过。schema_attempt02是每seed第二guard模型_propose_update失败，raw已提交2scalar、guard0，学习依赖blocked，四独立baseline自己的前缀/首active仍支付并停止。两者都未满足科学门。

42fail来自新增exact whitelist没有纳入原核心snapshot已有的update_commit、initial_prior、input_boundary；修复恰这三个固定说明字段及固定内容，fingerprint仍只用parameter record，未改变任何数学或科学门。repair_attempt03在pytest导入pyreadline3时触发platform Windows版本查询，被提前subprocess stub挡住；repair04只把synthetic platform.uname缓存显式注入五参数，0真实平台查询/Git。

截至repair04的56项覆盖guard等号/方向/clip/不裁q、预测自递推重新guard、RLS闭式解、MPC81×15零误差tie/全部拒绝fallback计账、1/9努力、逐轴退化不可被joint均值藏住、零tracking denominator、PD零努力条件、必要trial停止、immutable生产scope、strict JSON、PD五文件字节及rebound-hash语义篡改、planned missing/partial/terminal窗口、已知/未知失败预测meter、snapshot额外隐藏字段拒绝。所有工程原件含源码、stdout、raw、audit、费用保留在各attempt，`INTEGRITY.json`记录文件字节与hash。

## 最后两项异常时间语义审阅

joint_probe_impl 的只读preflight促使核实 `_exception_snapshot` 的展开顺序：它主动调用env.observation()，成功时覆盖显式observation_after，因此正常未返回区间也有失败时当前原生snapshot，须与qpos/qvel对应；只有observation_after_retrieval_error存在时才允许fallback为最后确认endpoint。任何未返回snapshot都不能用作RLS完整transition标签。现有exception.diagnostics的step_id/physics_steps/time绑定episode paid ledger；getter无计数时明示剩余费用没有独立重构。没有更改科研门、数学或collector。

unit_attempt05先验证只在returned时对应的临时实现，57pass/.739745wall/.65625CPU；它被上面的更精确helper事实修正取代，不充作当前行为证据。unit_attempt06验证最终声明，59pass，包含getter失败后旧endpoint合法、getter成功但不对应拒绝、未返回当前snapshot不是RLS标签、paid counters篡改拒绝。费用在其execution.json，0collector/0真物理/0Git。

repair04的953480/184181两个读日志审计对应其原版本源码SHA3690a36a657464e0701452719813b17187a1d789614f2ec4116d564033f31088，原件不改。最终异常helper修改只有针对新增缺口的pure组件验证，不无理由重新采集或重复整个矩阵；root可用正常promoted tests确认clone路径。

## 已知预测失败账修正

核心PairPredictionError只有to_dict，不附pair_prediction_accounting；collector将它保存为structured_failure，PredictionMeter已经认其为已知scalar成本。最终meter重建仅允许strict type=PairPredictionError、原五字段、native_features(0/0)、velocity_output_0(1/0)、velocity_output_1(2/1)、endpoint_euler(2/2)的精确整数stage/head对应，再计一次失败pair。其他structured异常不能冒用此fallback。

unit_attempt07 59pass/4fail，新增四stage测试误从root在并行提升后的旧scripts路径导入，未测试当前staging修正。全部原件保留。修正测试定位为staging时优先相邻candidate，提升到tests目录时仍走正式scripts路径；unit_attempt08最终63pass/.28pytest，wrapper wall/CPU见execution.json，0Git/0物理。最终候选SHA在本文首部；source/math/scientific门未根据物理结果改变。
