from pathlib import Path
import hashlib
stage=Path('D:/Codex_ws/robot_rl/external/c4_guard_pair_audit_staging');p=stage/'DELIVERY.md';s=p.read_text(encoding='utf-8-sig')
audit_hash=hashlib.sha256((stage/'audit_guard_pair_development.py').read_bytes()).hexdigest();test_hash=hashlib.sha256((stage/'test_audit_guard_pair_development.py').read_bytes()).hexdigest()
s=s.replace('3690a36a657464e0701452719813b17187a1d789614f2ec4116d564033f31088',audit_hash).replace('52b0b0e8dc29f75444dea6a1e2fadf4a1fba5fd688d40b4998d6fcaa60352e94',test_hash)
s=s.replace('最终56项覆盖','截至repair04的56项覆盖')
s+='''
## 最后两项异常时间语义审阅

joint_probe_impl 的只读preflight促使核实 `_exception_snapshot` 的展开顺序：它主动调用env.observation()，成功时覆盖显式observation_after，因此正常未返回区间也有失败时当前原生snapshot，须与qpos/qvel对应；只有observation_after_retrieval_error存在时才允许fallback为最后确认endpoint。任何未返回snapshot都不能用作RLS完整transition标签。现有exception.diagnostics的step_id/physics_steps/time绑定episode paid ledger；getter无计数时明示剩余费用没有独立重构。没有更改科研门、数学或collector。

unit_attempt05先验证只在returned时对应的临时实现，57pass/.739745wall/.65625CPU；它被上面的更精确helper事实修正取代，不充作当前行为证据。unit_attempt06验证最终声明，59pass，包含getter失败后旧endpoint合法、getter成功但不对应拒绝、未返回当前snapshot不是RLS标签、paid counters篡改拒绝。费用在其execution.json，0collector/0真物理/0Git。

repair04的953480/184181两个读日志审计对应其原版本源码SHA3690a36a657464e0701452719813b17187a1d789614f2ec4116d564033f31088，原件不改。最终异常helper修改只有针对新增缺口的pure组件验证，不无理由重新采集或重复整个矩阵；root可用正常promoted tests确认clone路径。
'''
p.write_text(s,encoding='utf-8',newline='\n')
print(audit_hash,test_hash)
