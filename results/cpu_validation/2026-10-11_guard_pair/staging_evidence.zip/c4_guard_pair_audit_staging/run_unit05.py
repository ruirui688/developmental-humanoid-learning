from pathlib import Path
import time,json,shutil,pytest,contextlib
stage=Path('D:/Codex_ws/robot_rl/external/c4_guard_pair_audit_staging');attempt=stage/'unit_attempt05'
attempt.mkdir()
for name in ('audit_guard_pair_development.py','test_audit_guard_pair_development.py'):
    shutil.copyfile(stage/name,attempt/name)
wall,cpu=time.perf_counter(),time.process_time()
with (attempt/'stdout.txt').open('x',encoding='utf-8') as stream,contextlib.redirect_stdout(stream),contextlib.redirect_stderr(stream):
    code=pytest.main(['-q',str(stage/'test_audit_guard_pair_development.py'),'--basetemp',str(attempt/'work')])
(attempt/'execution.json').write_text(json.dumps({'exit':code,'wall_seconds':time.perf_counter()-wall,'cpu_seconds':time.process_time()-cpu,'physical_steps':0,'model_updates':0,'git_calls':0},indent=2))
print(code)
