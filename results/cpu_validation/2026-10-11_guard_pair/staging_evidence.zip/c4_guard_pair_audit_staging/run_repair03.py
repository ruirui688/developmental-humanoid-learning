from pathlib import Path
import importlib.util,sys,time,json,shutil,contextlib,pytest
stage=Path('D:/Codex_ws/robot_rl/external/c4_guard_pair_audit_staging');output=stage/'repair_attempt03';output.mkdir()
for name in ('audit_guard_pair_development.py','test_audit_guard_pair_development.py'):shutil.copyfile(stage/name,output/name)
loader=importlib.util.spec_from_file_location('repair03_audit',stage/'audit_guard_pair_development.py');a=importlib.util.module_from_spec(loader);sys.modules[loader.name]=a;loader.loader.exec_module(a)
def forbidden(*args,**kwargs):raise AssertionError('Pure engineering repair audit forbids all Git/subprocess.')
a.subprocess.run=forbidden
wall,cpu=time.perf_counter(),time.process_time()
with (output/'stdout.txt').open('x',encoding='utf-8') as stream,contextlib.redirect_stdout(stream),contextlib.redirect_stderr(stream):
    code=pytest.main(['-q',str(stage/'test_audit_guard_pair_development.py'),'--basetemp',str(output/'test_work')])
    for attempt in ('schema_attempt01','schema_attempt02'):
        report=a.audit(stage/attempt/'raw',git_root=None,spec=a.SYNTHETIC_SPEC)
        (output/(attempt+'_audit.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
        print(attempt,report['checks'],report['failed'])
(output/'execution.json').write_text(json.dumps({'tests_exit':int(code),'wall_seconds':time.perf_counter()-wall,'cpu_seconds':time.process_time()-cpu,
    'simulation_calls':0,'physical_steps':0,'model_updates':0,'git_calls':0,'scope':'Read-only repair replay of preserved synthetic archives; no collector rerun'},indent=2),encoding='utf-8')
print('done')
