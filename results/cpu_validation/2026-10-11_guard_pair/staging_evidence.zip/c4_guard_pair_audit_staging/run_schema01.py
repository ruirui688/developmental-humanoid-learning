from pathlib import Path
import importlib.util,sys,json,time,contextlib,shutil
root=Path('D:/Codex_ws/robot_rl');stage=root/'external/c4_guard_pair_audit_staging'
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module
fixture=load('guard_collector_schema_fixture',root/'tests/test_guard_pair_development.py')
audit=load('guard_audit_schema_01',stage/'audit_guard_pair_development.py')
runner=fixture.runner
class StopAllControlEnv(fixture.SyntheticEnv):
    def step(self,requested):
        if self.trial%8>=2: self.fault_trial,self.stop_step=self.trial,100
        return super().step(requested)
fixture.SyntheticEnv.instances=[]
fixture.SyntheticEnv.stop_step=fixture.SyntheticEnv.fail_step=None
fixture.SyntheticEnv.partial=fixture.SyntheticEnv.missing_history=fixture.SyntheticEnv.prefix_excursion=False
fixture.SyntheticEnv.failure_type=RuntimeError
runner.GroundBodyEnv=StopAllControlEnv
# Keep original mathematical RLS/model/MPC; only the environment is fake.
runner.FixedPairMPC=fixture.core.FixedPairMPC
runner.DEVELOPMENT_SEEDS=(0,1,2)
def forbidden(*args,**kwargs): raise AssertionError('Synthetic schema attempts must not query real Git or subprocess.')
runner.subprocess.check_output=forbidden;audit.subprocess.run=forbidden
sources={p.relative_to(root).as_posix():p.read_bytes() for p in sorted((root/'src/developmental_physics').glob('*.py'))}
for name in (audit.common.ASSET,'pyproject.toml',audit.PROTOCOL,'scripts/audit_pair_frozen.py','scripts/audit_local_frozen.py',audit.PD_PROTOCOL): sources[name]=(root/name).read_bytes()
sources[audit.AUDITOR]=(stage/'audit_guard_pair_development.py').read_bytes()
output=stage/'schema_attempt01';output.mkdir()
for name in ('audit_guard_pair_development.py','test_audit_guard_pair_development.py'): shutil.copyfile(stage/name,output/name)
shutil.copyfile(root/runner.SOURCE_PATH,output/'collector.py');shutil.copyfile(root/'tests/test_guard_pair_development.py',output/'collector_fixture.py')
wall,cpu=time.perf_counter(),time.process_time()
with (output/'stdout.txt').open('x',encoding='utf-8') as stream,contextlib.redirect_stdout(stream),contextlib.redirect_stderr(stream):
    meta=runner.run_guard_pair_development(output/'raw',protocol_path=root/runner.PROTOCOL_PATH,synthetic=True,
        synthetic_source_bytes=sources,synthetic_pd_binding={'status':'selected','selected_id':4,'kp':[64.,64.],'kd':[1.,2.]})
    collect_cost={'wall_seconds':time.perf_counter()-wall,'cpu_seconds':time.process_time()-cpu}
    report=audit.audit(output/'raw',git_root=None,spec=audit.SYNTHETIC_SPEC)
    (output/'audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps({'checks':report['checks'],'failed':report['failed'],'violations':report['violations']},indent=2))
(output/'execution.json').write_text(json.dumps({'collector_cost':collect_cost,'total_wall_seconds':time.perf_counter()-wall,
    'total_cpu_seconds':time.process_time()-cpu,'fake_budget':{k:meta[k] for k in ('control_calls_attempted','control_steps','physics_steps','model_updates')},
    'real_physical_steps':0,'git_calls':0,'failed_checks':report['failed']},indent=2),encoding='utf-8')
print(report['checks'],report['failed'])
