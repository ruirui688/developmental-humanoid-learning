from pathlib import Path
stage=Path('D:/Codex_ws/robot_rl/external/c4_guard_pair_audit_staging');p=stage/'test_audit_guard_pair_development.py';s=p.read_text(encoding='utf-8-sig')
needle="source=ROOT/'scripts/audit_guard_pair_development.py'\nif not source.exists(): source=Path(__file__).with_name('audit_guard_pair_development.py')"
repl="source=Path(__file__).with_name('audit_guard_pair_development.py')\nif not source.exists(): source=ROOT/'scripts/audit_guard_pair_development.py'"
assert needle in s;s=s.replace(needle,repl);p.write_text(s,encoding='utf-8',newline='\n')
s=(stage/'run_unit01.py').read_text(encoding='utf-8-sig').replace('unit_attempt01','unit_attempt08');(stage/'run_unit08.py').write_text(s,encoding='utf-8',newline='\n')
