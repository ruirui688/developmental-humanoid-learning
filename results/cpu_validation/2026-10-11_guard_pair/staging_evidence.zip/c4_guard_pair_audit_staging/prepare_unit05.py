from pathlib import Path
stage=Path('D:/Codex_ws/robot_rl/external/c4_guard_pair_audit_staging')
s=(stage/'run_unit01.py').read_text(encoding='utf-8-sig').replace('unit_attempt01','unit_attempt05')
(stage/'run_unit05.py').write_text(s,encoding='utf-8',newline='\n')
