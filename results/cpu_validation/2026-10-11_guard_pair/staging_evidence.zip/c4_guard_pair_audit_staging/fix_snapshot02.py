from pathlib import Path
stage=Path('D:/Codex_ws/robot_rl/external/c4_guard_pair_audit_staging');p=stage/'header.py.txt';s=p.read_text()
s=s.replace("{'parameter_fingerprint','vector_update_count','scalar_update_count','output_update_counts','trainable'}", "{'parameter_fingerprint','vector_update_count','scalar_update_count','output_update_counts','trainable','initial_prior','input_boundary','update_commit'}")
s=s.replace("checks.compare(saved,{'vector_update_count':state['count']", "checks.compare(saved,{'update_commit':'single immutable state reference for both outputs, covariance and counts',\n        'initial_prior':'generic velocity continuity and torque response; zero cross coefficients',\n        'input_boundary':'current native q/v and already known requested u; no actual future torque or simulator state',\n        'vector_update_count':state['count']")
p.write_text(s,encoding='utf-8',newline='\n')
