"""Pure synthetic audit tests; no raw experiments, Git or physical calls."""
import ast
import copy
import importlib.util
import io
import json
from pathlib import Path
import sys
import zipfile
import pytest
ROOT=next(p for p in Path(__file__).resolve().parents if (p/'pyproject.toml').is_file())
source=ROOT/'scripts/audit_guard_pair_development.py'
if not source.exists(): source=Path(__file__).with_name('audit_guard_pair_development.py')
spec=importlib.util.spec_from_file_location('guard_independent_audit_test',source)
a=importlib.util.module_from_spec(spec);sys.modules[spec.name]=a;spec.loader.exec_module(a)

@pytest.fixture(autouse=True)
def forbid_git(monkeypatch):
    def forbidden(*args,**kwargs): raise AssertionError('Pure audit tests must not execute subprocess/Git.')
    monkeypatch.setattr(a.subprocess,'run',forbidden)
    monkeypatch.setattr(a.subprocess,'check_output',forbidden)

@pytest.mark.parametrize('basis',['raw_request','known_angle_guard'])
def test_initial_prior_endpoint_euler(basis):
    state=a.initial_state(basis,[[-1.,1.],[0.,2.]])
    q,v=a.predict(state['theta'],state['structure'],[0.,.4],[0.,.4],[.1,-.1],[.5,-.5])
    assert v==pytest.approx([.11,-.11]);assert q==pytest.approx([.0022,.3978])

@pytest.mark.parametrize('q,u,expected,blocked',[
    ([0.,.03],[0.,-.5],[0.,0.],[False,True]),
    ([0.,.0300001],[0.,-.5],[0.,-.5],[False,False]),
    ([0.,1.97],[0.,.5],[0.,0.],[False,True]),
    ([0.,1.97],[0.,-.5],[0.,-.5],[False,False]),
    ([0.,-.1],[0.,0.],[0.,0.],[False,False]),
    ([0.,1.],[3.,-3.],[.5,-.5],[False,False]),
])
def test_guard_equality_direction_clip(q,u,expected,blocked):
    got=a.describe_input(q,u,('known_angle_guard',((-1.,1.),(0.,2.))))
    assert got['projected_start_nm']==expected and got['start_blocked']==blocked and got['native_q_rad']==q


def test_raw_features_not_guarded_or_model_clipped():
    raw=a.features(('raw_request',((-1.,1.),(0.,2.))),[0.,0.],[0.,-.1],[0.,0.],[2.,-.5])
    guard=a.features(('known_angle_guard',((-1.,1.),(0.,2.))),[0.,0.],[0.,-.1],[0.,0.],[2.,-.5])
    assert raw[0][2:4]==[2.,1.75] and raw[1][2:4]==[-.5,-.25]
    assert guard[0][2:4]==[.5,.25] and guard[1][2:4]==[0.,0.]


def test_prediction_recomputes_guard_on_own_forecast_state():
    state=a.initial_state('known_angle_guard',[[-1.,1.],[0.,2.]])
    state['theta'][1]=[1.,0.,.2,0.,0.]
    q,v=[0.,.031],[0.,-.2]
    q1,v1=a.predict(state['theta'],state['structure'],[0.,.031],q,v,[0.,-.5])
    q2,v2=a.predict(state['theta'],state['structure'],[0.,.031],q1,v1,[0.,-.5])
    assert v1[1]==pytest.approx(-.3) and q1[1]<.03
    assert v2[1]==pytest.approx(-.3) # second request is blocked at predicted q


def test_rls_closed_form_zero_state_velocity_label():
    s=a.initial_state('raw_request',[[-1.,1.],[0.,2.]])
    x,p=a.propose_pair(s,[0.,.5],[0.,.5],[0.,0.],[0.,0.],[.2,-.2])
    assert x==[[0.,0.,0.,0.,1.]]*2
    assert p[0][0][-1]==pytest.approx(20/101)
    assert p[0][1][-1][-1]==pytest.approx(100/101)
    assert p[1][0][-1]==pytest.approx(-20/101)


def test_mpc_exhaustive_tie_and_count_zero_error():
    s=a.initial_state('raw_request',[[-1.,1.],[0.,2.]])
    d=a.replay_mpc(s['theta'],s['structure'],[0.,.5],[0.,.5],[0.,0.],[0.,.5],[0.,0.],[[-1.,1.],[0.,2.]])
    assert d['torque']==[0.,0.] and d['cost']==0. and d['feasible_candidates']==81
    assert d['pair_prediction_attempts']==81*15 and d['scalar_prediction_attempts']==2*81*15
    assert len(d['candidate_records'])==81


def test_mpc_all_infeasible_fallback_keeps_prediction_cost():
    s=a.initial_state('raw_request',[[-1.,1.],[0.,2.]])
    s['theta']=[[0.,0.,0.,0.,100.]]*2
    d=a.replay_mpc(s['theta'],s['structure'],[0.,.5],[0.,.5],[0.,0.],[0.,.5],[0.,0.],[[-1.,1.],[0.,2.]])
    assert d['fallback'] and d['torque']==[0.,0.] and d['pair_prediction_attempts']==81


def test_1_9_calibration_schedule_and_cost():
    commands=[a.calibration_request(k,[1,1]) for k in range(400)]
    assert commands[0]==[.125,0.] and commands[1]==[0.,0.] and commands[10]==[-.125,0.]
    assert commands[200]==[.125,.125] and commands[300]==[.125,-.125]
    assert [sum(abs(u[i]) for u in commands)*.02 for i in range(2)]==pytest.approx([.18,.18])
    assert [sum(u[i]**2 for u in commands)*.02 for i in range(2)]==pytest.approx([.06375,.06375])

@pytest.mark.parametrize('bad',[-1,400,True,1.])
def test_schedule_rejects_invalid_index(bad):
    with pytest.raises(ValueError): a.calibration_request(bad,[1,1])

def fake_seeds():
    rows=[]
    for seed in (0,1,2):
        ev={k:{'eligible':True,'completed':True,'status':'completed','study_aborted':False,'environment_terminated':False} for k in a.KINDS}
        for name,val in [('nominal_raw',1.),('nominal_guard',.9),('learned_raw',.7),('learned_guard',.6),('PDselected',.8),('zero',2.)]:
            ev[name].update(tracking_rmse_rad=val,tracking_rmse_by_axis_rad=[val,val],actual_effort_complete=True,
                control_effort={'actual_absolute_nm_s':[.01,.01],'actual_squared_nm2_s':[.01,.01]})
        ev['prediction']['velocity_prediction_rmse']={'nominal_raw':[1.,1.],'nominal_guard':[1.,1.],'learned_raw':[.7,.7],'learned_guard':[.7,.7]}
        rows.append({'seed':seed,'evaluations':ev})
    return rows


def test_scientific_contribution_and_pd_gates_known_positive():
    gates=a.scientific_gates(fake_seeds())
    assert all(v['passed'] for group in ('model_contribution','selected_pd_comparison') for v in gates[group].values())
    assert gates['public_rule_diagnostic']['learning_updates_compared']==0

@pytest.mark.parametrize('axis',[0,1])
def test_axis_degradation_cannot_hide_in_joint_mean(axis):
    rows=fake_seeds();rows[1]['evaluations']['learned_raw']['tracking_rmse_by_axis_rad'][axis]=1.
    assert not a.contribution_gate(rows,'raw')['passed'] and a.contribution_gate(rows,'guard')['passed']


def test_zero_tracking_denominator_fails_improvement_gate():
    rows=fake_seeds()
    for row in rows:
        row['evaluations']['nominal_raw'].update(tracking_rmse_rad=0.,tracking_rmse_by_axis_rad=[0.,0.])
        row['evaluations']['learned_raw'].update(tracking_rmse_rad=0.,tracking_rmse_by_axis_rad=[0.,0.])
    assert not a.contribution_gate(rows,'raw')['passed']


def test_zero_pd_effort_requires_zero_learned_effort():
    rows=fake_seeds()
    for row in rows: row['evaluations']['PDselected']['control_effort']['actual_absolute_nm_s']=[0.,0.]
    assert not a.pd_comparison_gate(rows,'guard')['passed']
    for row in rows: row['evaluations']['learned_guard']['control_effort']['actual_absolute_nm_s']=[0.,0.]
    assert a.pd_comparison_gate(rows,'guard')['passed']

@pytest.mark.parametrize('kind',['calibration','prediction','nominal_guard','learned_guard','PDselected'])
def test_incomplete_required_trial_blocks_validated_claim(kind):
    rows=fake_seeds();rows[0]['evaluations'][kind]['status']='terminated';rows[0]['evaluations'][kind]['eligible']=False
    assert not a.pd_comparison_gate(rows,'guard')['passed']

@pytest.mark.parametrize('change',[{'seeds':(20,21,22)},{'control_steps':2},{'joint_indices':(0,2)},{'protocol':'docs/other.md'}, {'scientific_gates_frozen':False}])
def test_production_scope_cannot_be_redefined(change):
    with pytest.raises(ValueError): a.GuardPairAuditSpec(**change)


def test_planned_budget_24_7500_75000_4800():
    plans=a.planned_matrix()
    assert len(plans)==24 and sum(p['maximum_control_steps'] for p in plans)==7500
    assert 10*sum(p['maximum_control_steps'] for p in plans)==75000 and 3*400*4==4800


def test_synthetic_scope_never_scientifically_frozen():
    assert not a.SYNTHETIC_SPEC.scientific_gates_frozen
    with pytest.raises(ValueError): a.GuardPairAuditSpec(synthetic_fixture=True,scientific_gates_frozen=True)

@pytest.mark.parametrize('bad',['{"x":1,"x":2}','{"x":NaN}','{"x":Infinity}'])
def test_strict_json_rejects_duplicate_nonstandard(bad):
    with pytest.raises(ValueError): a.parse_json(bad)


def test_auditor_has_no_online_or_third_party_imports():
    parsed=ast.parse(source.read_text(encoding='utf-8'))
    names=[]
    for node in ast.walk(parsed):
        if isinstance(node,ast.Import): names.extend(alias.name for alias in node.names)
        if isinstance(node,ast.ImportFrom): names.append(node.module or '')
    assert not any(name.startswith(('numpy','mujoco','developmental_physics')) for name in names)


def pd_identity_fixture():
    members={a.PD_PROTOCOL:b'synthetic protocol', 'scripts/audit_pair_pd.py':b'synthetic auditor', 'scripts/audit_local_frozen.py':b'synthetic support'}
    buffer=io.BytesIO()
    with zipfile.ZipFile(buffer,'w') as archive:
        for name,raw in members.items(): archive.writestr(name,raw)
    sha=lambda raw:a.hashlib.sha256(raw).hexdigest()
    protocol={'path':a.PD_PROTOCOL,'sha256':sha(members[a.PD_PROTOCOL])}
    metadata=copy.deepcopy(a.PD_METADATA)
    metadata.update(environment_config=copy.deepcopy(a.ENVIRONMENT),protocol=protocol,source_snapshot_sha256=sha(buffer.getvalue()),source_sha256={name:sha(raw) for name,raw in members.items()})
    raw={'metadata.json':json.dumps(metadata).encode(),'source_snapshot.zip':buffer.getvalue(),
        'manifest.json':b'placeholder','episodes.json':b'forbidden','selection.json':b'forbidden','trace.jsonl.gz':b'forbidden'}
    audit={'validated_selection':True,'failed_checks':0,'source_git_verification_enabled':True,'immutable_scope':copy.deepcopy(a.PD_SCOPE),
        'selection':{'status':'selected','picked':{'candidate':4,'kp':[64.,64.],'kd':[1.,2.],'eligible':True,
            'sort_key':[.02,.03,.01,4],'paid_control_steps':900,'paid_physics_steps':9000}},
        'input_hashes':{name:sha(data) for name,data in raw.items()},
        'audit_sources_sha256':{'auditor':sha(members['scripts/audit_pair_pd.py']),'common':sha(members['scripts/audit_local_frozen.py'])}}
    manifest={'protocol':protocol,'files':{'raw/'+name:{'kind':'raw','source':'fixture/'+name,'bytes':len(data),'sha256':sha(data)} for name,data in raw.items()}}
    sources={a.PD_PROTOCOL:members[a.PD_PROTOCOL],a.PD_RAW_METADATA:raw['metadata.json'],a.PD_RAW_ZIP:raw['source_snapshot.zip'],
        a.PD_MANIFEST:json.dumps(manifest).encode(),a.PD_AUDIT:json.dumps(audit).encode()}
    selection={'schema':'c4-pd-selection-v1','status':'selected','selected':{'candidate_id':4,'joint_indices':[0,1],'kp':[64.,64.],'kd':[1.,2.]},
        'protocol':protocol,'sources':{label:{'path':name,'sha256':sha(sources[name])} for label,name in (('manifest',a.PD_MANIFEST),('audit',a.PD_AUDIT))}}
    sources[a.PD_SELECTION]=json.dumps(selection).encode();return sources


def test_pd_identity_independently_binds_five_archived_files():
    files=pd_identity_fixture();got=a.reconstruct_pd_binding(files)
    assert got['selected_id']==4 and got['kd']==[1.,2.] and got['audit_selection_confirmed']
    assert len(got['source_records'])==5 and not got['raw_trace_or_episodes_read']

@pytest.mark.parametrize('path',[a.PD_SELECTION,a.PD_MANIFEST,a.PD_AUDIT,a.PD_RAW_METADATA,a.PD_RAW_ZIP])
def test_pd_changed_source_bytes_rejected(path):
    files=pd_identity_fixture();files[path]+=b'x'
    with pytest.raises((ValueError,a.zipfile.BadZipFile)): a.reconstruct_pd_binding(files)
