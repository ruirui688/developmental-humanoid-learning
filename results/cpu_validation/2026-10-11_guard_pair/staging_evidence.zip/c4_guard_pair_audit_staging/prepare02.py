from pathlib import Path
stage=Path('D:/Codex_ws/robot_rl/external/c4_guard_pair_audit_staging')
s=(stage/'run_unit01.py').read_text(encoding='utf-8-sig').replace('unit_attempt01','unit_attempt02')
(stage/'run_unit02.py').write_text(s,encoding='utf-8',newline='\n')
s=(stage/'run_schema01.py').read_text(encoding='utf-8-sig').replace('schema_attempt01','schema_attempt02').replace("if self.trial%8>=2", "if self.trial%5!=0")
s=s.replace("output=stage/'schema_attempt02';output.mkdir()", "original_proposal=fixture.core.PairBodyModel._propose_update\ndef fail_guard(self,*args,**kwargs):\n    if self.input_basis=='known_angle_guard': raise ValueError('Synthetic second model proposal failure')\n    return original_proposal(self,*args,**kwargs)\nfixture.core.PairBodyModel._propose_update=fail_guard\noutput=stage/'schema_attempt02';output.mkdir()")
(stage/'run_schema02.py').write_text(s,encoding='utf-8',newline='\n')
