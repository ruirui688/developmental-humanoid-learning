from pathlib import Path
stage=Path('D:/Codex_ws/robot_rl/external/c4_guard_pair_audit_staging')
source='\n'.join((stage/name).read_text(encoding='utf-8-sig') for name in ('header.py.txt','mpc_fragment.py.txt','scope.py.txt','gates.py.txt','body_fragment.py.txt','footer.py.txt'))
source=source.replace("PD_AUDIT=PD_DIR+'audit.json'","PD_AUDIT=PD_DIR+'first_audit.json'")
(stage/'audit_guard_pair_development.py').write_text(source,encoding='utf-8',newline='\n')
compile(source,'audit_guard_pair_development.py','exec')
print(len(source.splitlines()))
