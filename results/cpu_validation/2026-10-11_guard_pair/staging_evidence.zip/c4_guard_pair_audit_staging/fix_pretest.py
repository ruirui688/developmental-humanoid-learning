from pathlib import Path
stage=Path('D:/Codex_ws/robot_rl/external/c4_guard_pair_audit_staging')
p=stage/'body_fragment.py.txt';s=p.read_text();s=s.replace("dependent=kind=='prediction' or kind in ('diagonal_mpc','coupled_mpc')","dependent=kind=='prediction' or kind in LEARNED")
p.write_text(s,encoding='utf-8',newline='\n')
