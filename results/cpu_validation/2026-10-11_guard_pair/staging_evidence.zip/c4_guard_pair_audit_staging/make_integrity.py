from pathlib import Path
import hashlib,json
stage=Path('D:/Codex_ws/robot_rl/external/c4_guard_pair_audit_staging')
records={}
for p in sorted(stage.rglob('*')):
    if not p.is_file() or '__pycache__' in p.parts or '.pytest_cache' in p.parts or p.name in ('INTEGRITY.json','DELIVERY.md'):continue
    raw=p.read_bytes();records[p.relative_to(stage).as_posix()]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
(stage/'INTEGRITY.json').write_text(json.dumps({'schema':1,'scope':'C4 A audit synthetic engineering evidence only','files':records},indent=2,allow_nan=False),encoding='utf-8',newline='\n')
print(len(records),sum(v['bytes'] for v in records.values()))
