from pathlib import Path
root=Path('D:/Codex_ws/robot_rl');stage=root/'external/c4_guard_pair_audit_staging'
old=(root/'scripts/audit_pair_frozen.py').read_text(encoding='utf-8')
chunk=old[old.index('def replay_mpc('):old.index('def calibration_request(')]
(stage/'mpc_fragment.py.txt').write_text(chunk,encoding='utf-8',newline='\n')
