from pathlib import Path
import hashlib
stage=Path('D:/Codex_ws/robot_rl/external/c4_guard_pair_audit_staging');p=stage/'DELIVERY.md';s=p.read_text()
s=s.replace('f670d98f15a810f3b30ad30c8edd9921019fa94c217acbc587529da4f9e3ce5e',hashlib.sha256((stage/'audit_guard_pair_development.py').read_bytes()).hexdigest()).replace('4d5323c937efa0f7c295ffd556bea4ed45c92809af2fd6c281504926a3b2e8cd',hashlib.sha256((stage/'test_audit_guard_pair_development.py').read_bytes()).hexdigest())
s+='''
## 已知预测失败账修正

核心PairPredictionError只有to_dict，不附pair_prediction_accounting；collector将它保存为structured_failure，PredictionMeter已经认其为已知scalar成本。最终meter重建仅允许strict type=PairPredictionError、原五字段、native_features(0/0)、velocity_output_0(1/0)、velocity_output_1(2/1)、endpoint_euler(2/2)的精确整数stage/head对应，再计一次失败pair。其他structured异常不能冒用此fallback。

unit_attempt07 59pass/4fail，新增四stage测试误从root在并行提升后的旧scripts路径导入，未测试当前staging修正。全部原件保留。修正测试定位为staging时优先相邻candidate，提升到tests目录时仍走正式scripts路径；unit_attempt08最终63pass/.28pytest，wrapper wall/CPU见execution.json，0Git/0物理。最终候选SHA在本文首部；source/math/scientific门未根据物理结果改变。
'''
p.write_text(s,encoding='utf-8',newline='\n')
print(hashlib.sha256((stage/'audit_guard_pair_development.py').read_bytes()).hexdigest())
print(hashlib.sha256((stage/'test_audit_guard_pair_development.py').read_bytes()).hexdigest())
