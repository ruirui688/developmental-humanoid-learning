"""One preserved strict audit of the original synthetic fixture; no physics."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time

HERE=Path(__file__).resolve().parent
PREFIX=HERE/'audit_synthetic_01'

def save(path,obj):
    with path.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(obj,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')

def main():
    wall,cpu=time.perf_counter(),time.process_time()
    record={'started_at_utc':datetime.now(timezone.utc).isoformat(),'source':{},'physical_calls':0,
        'model_updates':0,'new_predictions':0,'formal_raw_reads':0,'audited_synthetic_archive_count':1}
    save(Path(str(PREFIX)+'_attempt.json'),record)
    for path in (HERE/'audit_pair_calibration.py',Path(__file__)):
        data=path.read_bytes();snapshot=Path(str(PREFIX)+'_'+path.name)
        with snapshot.open('xb') as f:f.write(data)
        record['source'][str(path)]={'snapshot':str(snapshot),'sha256':hashlib.sha256(data).hexdigest()}
    spec=importlib.util.spec_from_file_location('auditor_baseline_01',HERE/'audit_pair_calibration.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    result=module.audit(HERE/'synthetic_01_outputs/test_full_six_trials_no_learning_choose_pulse2',git_root=None,synthetic_fixture=True)
    output=Path(str(PREFIX)+'_result.json');save(output,result)
    for path,item in record['source'].items():
        item['after_sha256']=hashlib.sha256(Path(path).read_bytes()).hexdigest()
        item['unchanged']=item['after_sha256']==item['sha256']
    record.update(checks=result['checks'],failed=result['failed'],audit_sha256=result['audit_script_sha256'],
        result_sha256=hashlib.sha256(output.read_bytes()).hexdigest(),wall_seconds=time.perf_counter()-wall,
        cpu_seconds=time.process_time()-cpu,python=sys.version,execution_status='completed_expected_strict_legacy_failure')
    save(Path(str(PREFIX)+'_execution.json'),record)
    print(json.dumps({'checks':result['checks'],'failed':result['failed'],'violations':result['violations'][:3],
        'formal_execution_accepted':result['formal_execution_accepted'],'physical_calls':0}))

if __name__=='__main__':main()
