# C4-D 固定短脉冲校准可执行性草稿交付

UNFROZEN；真实入口 `FORMAL_EXECUTION_FROZEN=False`。本次只实现ignored草稿和有限synthetic；未执行真实物理、model fit/update、新预测、科研audit或原pair raw重读，没有修改tracked/Git，也未读取20–22。

root明确授权的矩阵为两候选2正/8zero/2反/8zero、1正/9zero/1反/9zero，各原开发0/1/2，共六trial。按2/8三seed再1/9三seed的预定顺序全部运行；选择先2/8全部完整且stop0/遥测全，否则1/9，否则blocked。不按截断努力选择，不补跑原5/5或追加新候选。

原supine、j0+j1、原生8D、100paidprefix、400active、20块肩-only/肘-only/同向/反向、幅度[.125,.25,.375,.5,.25]、.5权限、baseline接触、StudyAbort(qoffset>=.12或speed>=1)与原环境保护保持。真实完整上限3000call/30000substep/0参数学习；2/8每trial每轴请求绝对/平方努力.36/.1275，1/9 .18/.06375。只构造环境，不构造身体模型；teacher/model/gain/policy updates0。qref略负不裁，freshenv、固定既有reset seed、独立原生prefix不缓存。

每trial保存raw请求、前后原生观测、actual子步history、force/energy/contact distance、qpos/qvel、study和model_update=None，phase预算/effort与参数指纹。partial不假装完整10子步，末计划端点stop不complete；缺遥测/invalid history/fingerprint变化/异常不eligible。ordinary stop/incomplete继续预定trial；interrupt/integration/IO/trace错误fatal，剩余planned blocked。

`synthetic_01` **18 tests passed /7.648 s**；完整wrapper wall **8.011149799916893 s**、CPU **6.0 s**。import、快照、整个finite tests、source稳定性检查及输出hash均含在该时间，最终execution写盘除外。保留15份fake采集档案；fake backend合计attempted14732call/报告147285substep，只是fake计账，并非真实物理预算。wrapper把MuJoCo MjModel/MjData构造、mj_step、mj_forward全部替换成抛错入口；真实physics0、model update0。

覆盖：完整六trial/3000call选择2；2失败后选择预定1；两组失败none；末计划步stop；没有stop latch的partial；3paid子步interrupt与unknown实际努力；interrupt原异常保留同时after fingerprint失败；invalid8D actualhistory；缺raw遥测；环境stop与j0研究stop；trace写失败后paid1010/returned未写1；checkpoint IO失败后500完整物理调用保留并fatal；plant变化；既有输出拒绝；真实入口disabled；两精确pulse/原5拒绝；较低截断努力不得获选。全部synthetic失败档案留在 `synthetic_01_outputs/`，没有删除或补跑。

exact来源与tests/protocol/wrapper在执行前exclusive快照为 `synthetic_01_*`，测试import原稿并核验执行后hash完全不变；其原字节等于对应before快照。执行记录逐文件列出所有fake档案hash；本结果只支持合同，不表示短pulse在MuJoCo可执行或动作充分可辨识。正式root应另冻结路径/source commit/clean gate、提出独立标准库审计，提交推送后才一次正式采集，不把fake结果授科研门。

| 文件 | SHA256 |
|---|---|
| `calibration_feasibility.py` | `773574e9b4818ad4e4951a0f17e1b357bf852f838d2abf8222e5ffc8cbfa8f98` |
| `test_calibration_feasibility.py` | `fd47a46fc6757479a5e980fcda4b063fac2269d92dd739460c5997483e22006f` |
| `CALIBRATION_FEASIBILITY_PROTOCOL_DRAFT.md` | `83df19d258517f8cbb9f30a6bf4fdcc6918820aaee380eb310e98d760bdddcc0c` |
| `run_synthetic_01.py` | `e665fd10dd29f8ef4e3c2a2d936df91eccc5bacec9d76cada75f67d06b246098` |
| `synthetic_01_execution.json` | `842c1b9f2b6853891392c0d6c85eb3ca7c6a6b5e5af096e84f48032537324916` |
| `synthetic_01_stdout.txt` | `835e3f4026c276f6f5efb8f086edb8e3ebd7bd58b31f42b1b79d5568059467f6` |

静态whitespace、引用文件存在、ignored状态与 `git diff --check` 全通过。没有在通过后修改collector/tests/protocol/wrapper来源。
