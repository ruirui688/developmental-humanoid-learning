# C4-D independent no-learning calibration audit delivery

No tracked files, Git operations, real physics, model fitting, new model predictions, formal raw archive reads or holdout-seed reads were performed by this subtask. Root owns promotion, preregistration, formal execution and commits/pushes. All initial01 snapshots and failed evidence remain intact.

## Source and interface

- Auditor: `external/c4d_pair_calibration_staging/audit_pair_calibration.py`
- SHA256: `222a5c69a12dade92b0f5a47b2383f485d86052db1ca7f4ccf97bd098636b2cc`
- Standard-library finite tests: `test_audit_pair_calibration.py`, SHA256 `21619879d1703589955e0f1358f31ca24b2e0ce9f04c3fda3a8769ae13ee5d4f`
- Existing collector `calibration_feasibility.py` was not changed: SHA256 `773574e9b4818ad4e4951a0f17e1b357bf852f838d2abf8222e5ffc8cbfa8f98`.

The public API is `audit(path, *, git_root=ROOT, synthetic_fixture=False, expected_source_commit=None)`. It returns a JSON-serializable report; it does not write or modify the input archive. CLI: `python scripts/audit_pair_calibration.py ARCHIVE --output NEW_JSON --source-commit FROZEN_COMMIT`. Output creation is exclusive. Formal input requires the preregistered exact commit, clean source metadata and Git blob verification; synthetic fixtures can use `--synthetic-fixture --no-git-verification` and never receive `validated_eligible` or `formal_execution_accepted`.

Copying the unchanged auditor bytes to `scripts/audit_pair_calibration.py` preserves its SHA. Its own `__file__` hash must equal the auditor source ZIP member. Formal source ZIP membership is independently fixed to exactly eight paths:

1. `src/developmental_physics/pair_calibration_development.py`
2. `scripts/audit_pair_calibration.py`
3. `docs/PAIR_CALIBRATION_DEVELOPMENT_PROTOCOL.md`
4. `src/developmental_physics/environment.py`
5. `src/developmental_physics/probes.py`
6. `src/developmental_physics/collect.py`
7. `src/developmental_physics/assets/ground_body.xml`
8. `pyproject.toml`

The collector must include the auditor in its `sources` list and update the draft's `PROTOCOL_PATH` to the formal protocol. The auditor imports no collector, environment, NumPy, MuJoCo or body model. Formal Git/source binding remains root's schema integration responsibility; the synthetic execution intentionally does not fabricate formal clean/Git proof.

## Independently frozen checks

Six trials only: development seeds0/1/2, pulse2/zero8 then pulse1/zero9; each starts with100 zero-prefix control calls and allows400 active calls. Original20 blocks and amplitudes `.125/.25/.375/.5/.25` remain fixed. Both schedules execute; selection needs all three complete raw trajectories and follows pulse2 priority. Requested effort per axis is `.36 Nm s / .1275 Nm2 s` for pulse2, `.18 Nm s / .06375 Nm2 s` for pulse1.

The auditor independently parses the XML native8 joint/motor order, public ranges, unit gears and ±.5 permissions. Full qpos/qvel addresses come from XML traversal rather than a hardcoded native offset; a deliberately reordered body fixture verifies nonidentity mapping. Six native observation fields are whitelisted. Commands, native reference and signed public-room choice, counters/time, full actual histories, force/energy/penetration substep arrays, peaks/impulse, study thresholds and episode/batch budgets are recomputed. Last planned endpoint stops are rejected as completion. Blocked trials require zero interaction cost.

First applied substep guard is checked exactly from native start q and XML ranges with `.03 rad` margin. Later actual substeps must either preserve the request or zero it; guarded-substep counts are recomputed. The collector does not record pre-substep q, so the audit does not claim complete later-substep angle replay.

Partial/unreturned/invalid-history effort stays paid. Exception command reconstructs requested effort where possible; raw missing actual effort remains a lower bound with an explicit missing-substep count. A fully measured endpoint lost during trace write can explain collector `complete_active_endpoints`, but it never makes an incomplete raw trial eligible. Checkpoint/fingerprint/trace failures and the primary interruption remain separate facts.

## Preserved executions

Initial strict audit `audit_synthetic_01_*` applied the original independent source to the original full fake archive once:463,305 checks,36,135 failures. The old fake omitted counters/time/termination/telemetry summaries and bypassed the known public guard. These are fixture failures; no audit threshold was weakened. Exact before/after source SHA, result SHA and timing are in `audit_synthetic_01_execution.json`. Wall `.8518193999771029 s`, CPU `.828125 s`; physical calls0, formal acceptance false.

One repaired fixture execution under `synthetic_02_*` passed18 collector contract tests. It corrects hip ranges, uses public guards in fake actual history/native torque and supplies complete diagnostics. Collector/protocol bytes remain unchanged. Wall `9.861650499980897 s`, CPU `7.484375 s`;15 synthetic archives;14,732 fake attempted calls /147,285 fake-reported substeps; actual physical calls0 and model updates0. Execution SHA256: `93100d286c6fb74c12f754151890f78000f9d9054ce198bed1b1f1856136a14d`.

Repaired standard-library audit execution `audit_synthetic_02_*` passed8 finite tests in one run. It independently audited all15 repaired archives once:2,641,703 checks /0 failures. It rejected9 deliberate synthetic mutations: commands18 failures, native field1, missing study1, blocked cost15, source hash1, source commit1, manifest1, invalid eligibility1, XML motor order8. It also checks hand arithmetic, exact stopping/guard equalities, unique-three-seed selection, partial unknown effort and nonidentity XML mapping. No third-party modules were loaded. All24 reports have formal acceptance false. Wall `7.097557100001723 s`, CPU `6.4375 s`; physical calls0 /model updates0 /new predictions0.

Auditor02 execution SHA256: `fc15a12706f9e0447099b9e63c0c478dc6656b64bc343720fd743d48c1fb2230`. The output directory is spelled `audit_synthetic_02outputs/`; per-report hashes, source snapshots and stdout hashes are recorded in the execution JSON. Do not rename originals when archiving evidence; root may copy them.

These are bookkeeping, parsing and finite synthetic contracts. They provide no formal six-trial physical result, no safety claim and no learning/skill benefit. The next authorized formal step remains root's once-frozen six-trial CPU execution plus the independently source-bound audit.
