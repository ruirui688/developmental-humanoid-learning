"""Finite standard-library hand/synthetic tests; no collector or physics imports."""
import ast
import gzip
import hashlib
import importlib.util
import io
import json
import math
import os
from pathlib import Path
import shutil
import unittest
import xml.etree.ElementTree as ET
import zipfile

HERE=Path(__file__).resolve().parent
OUTPUT=Path(os.environ['PAIR_CALIBRATION_AUDIT_OUTPUT_ROOT'])
FIXTURES=HERE/'synthetic_02_outputs'
spec=importlib.util.spec_from_file_location('independent_pair_auditor',HERE/'audit_pair_calibration.py')
auditor=importlib.util.module_from_spec(spec);spec.loader.exec_module(auditor)
REPORTS={}

def write_json(path,obj):
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')

def save_report(name,result):
    path=OUTPUT/(name+'.json')
    with path.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(result,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
    REPORTS[name]={'checks':result['checks'],'failed':result['failed'],'formal_execution_accepted':result['formal_execution_accepted'],
        'wall_seconds':result['execution']['wall_seconds'],'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

def repair_manifest(path):
    write_json(path/'manifest.json',{p.name:hashlib.sha256(p.read_bytes()).hexdigest()
        for p in path.iterdir() if p.is_file() and p.name!='manifest.json'})

class AuditTests(unittest.TestCase):
    def test_a_no_external_imports(self):
        tree=ast.parse((HERE/'audit_pair_calibration.py').read_text())
        names=[]
        for node in ast.walk(tree):
            if isinstance(node,ast.Import):names.extend(x.name.split('.')[0] for x in node.names)
            if isinstance(node,ast.ImportFrom):names.append((node.module or '').split('.')[0])
        self.assertFalse(set(names)&{'numpy','mujoco','developmental_physics','calibration_feasibility'})
    def test_b_pulse_slots_blocks_effort_by_hand(self):
        for pulse,absolute,squared in ((2,.36,.1275),(1,.18,.06375)):
            u=[auditor.command(i,pulse,[-1,1]) for i in range(400)]
            self.assertEqual([x[0] for x in u[:20]],[-.125]*pulse+[0.]*(10-pulse)+[.125]*pulse+[0.]*(10-pulse))
            self.assertEqual(u[100],[0.,.125]+[0.]*6)
            self.assertEqual(u[200],[-.125,.125]+[0.]*6)
            self.assertEqual(u[300],[-.125,-.125]+[0.]*6)
            for i in range(2):
                self.assertAlmostEqual(sum(abs(x[i])*.02 for x in u),absolute)
                self.assertAlmostEqual(sum(x[i]*x[i]*.02 for x in u),squared)
        for args in ((0,5,[1,1]),(400,2,[1,1]),(0,2,[True,1])):
            with self.assertRaises(ValueError):auditor.command(*args)
    def test_c_public_guard_and_threshold_equalities(self):
        limits=[[-1.,1.]]*8;q=[0.]*8;u=[.5]*8
        q[0]=-.97;q[1]=.97;u[0]=-.5
        self.assertEqual(auditor.guard(q,u,limits),[0.,0.]+[.5]*6)
        q[0]=-.969;q[1]=.969
        self.assertEqual(auditor.guard(q,u,limits),u)
        self.assertIsNone(auditor.study([.12,0.],[1.,0.],[0.,0.],99))
        stop=auditor.study([.12,0.],[1.,0.],[0.,0.],100)
        self.assertEqual(stop['triggers'],[{'joint_index':0,'signal':'absolute_q_minus_qref_rad'},{'joint_index':0,'signal':'absolute_velocity_rad_s'}])
        self.assertIsNone(stop['feedback_action'])
    def test_d_xml_nonidentity_address_mapping(self):
        source=(HERE.parents[1]/'src/developmental_physics/assets/ground_body.xml').read_bytes()
        root=ET.fromstring(source);torso=root.find('worldbody/body');bodies=torso.findall('body')
        for b in bodies:torso.remove(b)
        for b in (bodies[1],bodies[0],bodies[2],bodies[3]):torso.append(b)
        checks=auditor.Checks();mapping,nq,nv=auditor.parse_asset(ET.tostring(root),checks)
        self.assertEqual(checks.failed,0);self.assertEqual((nq,nv),(15,14))
        self.assertEqual([m['qpos'] for m in mapping],[9,10,7,8,11,12,13,14])
        self.assertEqual([m['qvel'] for m in mapping],[8,9,6,7,10,11,12,13])
        self.assertAlmostEqual(mapping[4]['range'][1],math.pi/2)
    def test_e_partial_unknown_cost_by_hand(self):
        recorded=auditor.new_effort();recorded[auditor.EFFORT[0]]=[.00075,0.];recorded[auditor.EFFORT[1]]=[.00009375,0.]
        checks=auditor.Checks()
        report=auditor.reconcile_effort(recorded,auditor.new_effort(),3,0,0,[[-.125]+[0.]*7],checks,'hand')
        self.assertEqual(checks.failed,0);self.assertEqual(report['unreconstructed_physics_substeps'],3)
        self.assertTrue(report['requested_reconstruction_complete']);self.assertFalse(report['raw_actual_reconstruction_complete'])
        bad={k:list(v) for k,v in recorded.items()};bad[auditor.EFFORT[0]]=[0.,0.]
        checks=auditor.Checks();auditor.reconcile_effort(bad,auditor.new_effort(),3,0,0,[[-.125]+[0.]*7],checks,'handbad')
        self.assertGreater(checks.failed,0)
    def test_f_priority_requires_all_unique_three_seeds(self):
        rows=[{'pulse_steps':p,'seed':s,'trial_id':f'p{p}s{s}','independent_complete':True} for p in (2,1) for s in (0,1,2)]
        self.assertEqual(auditor.selection(rows)['selected_pulse_steps'],2)
        rows[1]['independent_complete']=False
        self.assertEqual(auditor.selection(rows)['selected_pulse_steps'],1)
        rows[4]['seed']=0
        self.assertIsNone(auditor.selection(rows)['selected_pulse_steps'])
    def test_g_fifteen_retained_synthetic_archives(self):
        paths=sorted(p for p in FIXTURES.iterdir() if (p/'manifest.json').is_file())
        self.assertEqual(len(paths),15)
        for p in paths:
            with self.subTest(archive=p.name):
                result=auditor.audit(p,git_root=None,synthetic_fixture=True);save_report(p.name,result)
                self.assertEqual(result['failed'],0,result['violations'][:4])
                self.assertFalse(result['formal_execution_accepted']);self.assertFalse(result['validated_eligible'])
                self.assertEqual(result['execution']['physical_calls'],0);self.assertEqual(result['execution']['third_party_imports'],[])
        stop=REPORTS['test_final_planned_step_stop_is_not_complete'];self.assertEqual(stop['failed'],0)
        trace=json.loads((OUTPUT/'test_trace_failure_after_paid_endpoint_is_fatal.json').read_text())
        self.assertEqual(trace['archive']['episodes'][0]['complete_active_endpoints'],1)
        self.assertEqual(trace['archive']['budget']['physics_steps'],1010)
        self.assertEqual(trace['archive']['episodes'][0]['unreconstructed_physics_substeps'],10)
        interrupt=json.loads((OUTPUT/'test_interrupt_paid_partial_and_remaining_blocked.json').read_text())
        self.assertEqual(interrupt['archive']['budget']['physics_steps'],1003)
        self.assertEqual(interrupt['archive']['episodes'][0]['unreconstructed_physics_substeps'],3)
    def test_h_finite_tampered_archives_rejected(self):
        original=FIXTURES/'test_both_candidates_stopped_none_selected'
        for mode in ('command','native_whitelist','study','blocked_cost','source_hash','source_commit','manifest','eligibility','xml_motor_order'):
            with self.subTest(mode=mode):
                path=OUTPUT/('tampered_'+mode);shutil.copytree(original,path)
                if mode in ('command','native_whitelist','study'):
                    rows=[json.loads(x) for x in gzip.decompress((path/'trace.jsonl.gz').read_bytes()).decode().splitlines()]
                    if mode=='command':rows[100]['requested_torque'][0]=-.25
                    if mode=='native_whitelist':rows[0]['observation_before']['privileged_mass']=[1.]
                    if mode=='study':rows[100]['study_abort']=None
                    (path/'trace.jsonl.gz').write_bytes(gzip.compress(('\n'.join(json.dumps(x) for x in rows)+'\n').encode()))
                elif mode=='blocked_cost':
                    ep=json.loads((path/'episodes.json').read_text());ep[1]['status']='blocked';ep[1]['physics_steps']=2
                    write_json(path/'episodes.json',ep)
                elif mode in ('source_hash','source_commit','eligibility'):
                    meta=json.loads((path/'metadata.json').read_text())
                    if mode=='source_hash':meta['source_sha256'][auditor.ASSET]='0'*64
                    if mode=='source_commit':meta['source_commit']='not-a-commit'
                    if mode=='eligibility':meta['candidate_selection']['selected_pulse_steps']=2
                    write_json(path/'metadata.json',meta)
                elif mode=='xml_motor_order':
                    with zipfile.ZipFile(path/'source_snapshot.zip') as z:members={n:z.read(n) for n in z.namelist()}
                    root=ET.fromstring(members[auditor.ASSET]);motors=root.find('actuator');first=motors[0];motors.remove(first);motors.append(first)
                    members[auditor.ASSET]=ET.tostring(root)
                    with zipfile.ZipFile(path/'source_snapshot.zip','w') as z:
                        for n,data in members.items():z.writestr(n,data)
                    meta=json.loads((path/'metadata.json').read_text());meta['source_sha256'][auditor.ASSET]=hashlib.sha256(members[auditor.ASSET]).hexdigest()
                    write_json(path/'metadata.json',meta)
                repair_manifest(path)
                if mode=='manifest':
                    manifest=json.loads((path/'manifest.json').read_text());manifest['episodes.json']='0'*64;write_json(path/'manifest.json',manifest)
                result=auditor.audit(path,git_root=None,synthetic_fixture=True);save_report('tampered_'+mode,result)
                self.assertGreater(result['failed'],0);self.assertFalse(result['data_consistency_verified']);self.assertFalse(result['formal_execution_accepted'])

if __name__=='__main__':unittest.main()
