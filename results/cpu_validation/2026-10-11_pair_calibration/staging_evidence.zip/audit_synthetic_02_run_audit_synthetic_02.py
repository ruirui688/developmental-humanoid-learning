"""Finite repaired standard-library hand/archive checks, frozen before import."""
import contextlib
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import time
import traceback
import unittest

HERE=Path(__file__).resolve().parent
PREFIX=HERE/'audit_synthetic_02'
def sha(data):return hashlib.sha256(data).hexdigest()
def save(path,obj):
    with path.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(obj,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def main():
    wall,cpu=time.perf_counter(),time.process_time()
    record={'started_at_utc':datetime.now(timezone.utc).isoformat(),'python':sys.version,'source':{},
        'physical_calls':0,'model_updates':0,'new_predictions':0,'formal_raw_reads':0,'first_audit_reexecutions':0,
        'repair_of':'audit_synthetic_01: complete synthetic telemetry and paid-unwritten endpoint reconciliation'}
    save(Path(str(PREFIX)+'_attempt.json'),record)
    for original in (HERE/'audit_pair_calibration.py',HERE/'test_audit_pair_calibration.py',Path(__file__)):
        data=original.read_bytes();snapshot=Path(str(PREFIX)+'_'+original.name)
        with snapshot.open('xb') as f:f.write(data)
        record['source'][str(original)]={'snapshot':str(snapshot),'sha256':sha(data)}
    output=Path(str(PREFIX)+'outputs');output.mkdir();os.environ['PAIR_CALIBRATION_AUDIT_OUTPUT_ROOT']=str(output)
    stream=io.StringIO();code=1;module=None
    with contextlib.redirect_stdout(stream),contextlib.redirect_stderr(stream):
        try:
            spec=importlib.util.spec_from_file_location('finite_audit_tests_02',HERE/'test_audit_pair_calibration.py')
            module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
            result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module))
            code=int(not result.wasSuccessful());record.update(tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors))
        except BaseException as exc:record['exception']={'type':type(exc).__name__,'message':str(exc)};traceback.print_exc()
    for original,item in record['source'].items():
        item['after_sha256']=sha(Path(original).read_bytes());item['unchanged']=item['after_sha256']==item['sha256']
        if not item['unchanged']:code=1
    stdout=stream.getvalue().encode()
    with Path(str(PREFIX)+'_stdout.txt').open('xb') as f:f.write(stdout)
    record.update(reports={} if module is None else module.REPORTS,exit_code=code,stdout_sha256=sha(stdout),
        wall_seconds=time.perf_counter()-wall,cpu_seconds=time.process_time()-cpu,
        third_party_modules_loaded=sorted(set(sys.modules)&{'numpy','mujoco','developmental_physics'}))
    save(Path(str(PREFIX)+'_execution.json'),record)
    print(stream.getvalue(),end='');print(json.dumps({k:record[k] for k in ('exit_code','wall_seconds','cpu_seconds','physical_calls','model_updates','third_party_modules_loaded')}))
    return code
if __name__=='__main__':raise SystemExit(main())
