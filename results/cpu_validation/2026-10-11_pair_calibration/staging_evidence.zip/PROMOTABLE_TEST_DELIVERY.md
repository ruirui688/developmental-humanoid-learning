# Clone-independent finite test promotion delivery

Root requested clone-independent tests after the original independent auditor delivery. This supplements `AUDITOR_DELIVERY.md`; all older collector/auditor source and execution snapshots remain unchanged.

Copy the following exact ignored bytes into the formal targets:

| Current source | Formal target | SHA256 |
|---|---|---|
| `test_pair_calibration_development.py` | `tests/test_pair_calibration_development.py` | `515a6d61b75b74e5e165a0040b3aa2bf5689e84bce9fcedffe17f7f84c9b3c45` |
| `test_audit_pair_calibration_promotable.py` | `tests/test_audit_pair_calibration.py` | `94faa903c24d75e137e0385bbecd2dd845b255ff7014ec2dfb98dd39278794a3` |
| `audit_pair_calibration_promotable.py` | `scripts/audit_pair_calibration.py` | `b7e00b07bc19407d9a9a01ba19dbb8b38439411523ae8973a5303ff0e5473a58` |

Collector tests import the existing formal module when present, with draft fallback only for staging. They resolve the protocol from the module's public constant, use temporary directories when no output-root environment variable is declared, explicitly patch the frozen flag to test real-entry disablement, and skip at module collection when optional NumPy/MuJoCo are absent. The formal CLI test stubs `run_validation`; it constructs no physical environment.

Auditor tests load the formal script after promotion and need no optional packages, ignored fixtures or environment variables. They hand-check effort, pulse/shape slots, exact guard/study thresholds, unknown partial effort and nonidentity XML addresses. Their minimal schema fixture is explicitly synthetic and hand-authored, with one declared zero-cost setup failure and five blocked trials. It is not an executed collector record. It checks manifest/blocked-cost mutation rejection and never receives formal acceptance.

The auditor API adds `synthetic_source_layout='staging'` and CLI `--synthetic-source-layout staging|formal`. The formal layout override is permitted only when `synthetic_fixture=True`; it preserves the exact eight-source set and currently executed auditor SHA binding. Ordinary formal calls retain their prior source/Git/clean/preregistered-commit checks. A formal call using this override is rejected. All synthetic acceptance remains false. No real scientific threshold, command schedule, source model or candidate selection rule changed.

Single authorized related pure-test run: `run_promotable_tests_01.py`. Exact before snapshots were taken for both tests, revised auditor, root's promoted collector/protocol and wrapper. Before/after hashes match. 28 tests passed (19 collector and9 auditor); test runner9.750s; wrapper wall `9.989821100141853 s`, CPU `7.515625 s`. All MuJoCo constructors/step/forward entry points were patched to fail. Actual physical calls0, model updates0, new predictions0, formal raw reads0, old fifteen-audit reruns0. Collector fake files used temporary directories and were cleaned by the self-contained tests.

Execution JSON: `promotable_tests_01_execution.json`, SHA256 `d3cf5344d8d8d01d90b50c5c0d8aa1c04d2f205e35c9aa0e81596fc3e8bc6a21`. Stdout SHA256 `805a222709685f46b6f3bb21d131da975b9a471e6efa0e23193f32583fe2c8f5`. These contract tests do not supply formal physical evidence; root still owns clean-source freeze, once-only six-trial execution, independent audit and tracked promotion/commits.
