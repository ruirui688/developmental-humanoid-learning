"""One finite promotable-test run; snapshots first, all MuJoCo physics blocked."""
import contextlib
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import time
import traceback
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
PREFIX=HERE/'promotable_tests_01'
def sha(data):return hashlib.sha256(data).hexdigest()
def save(path,obj):
    with path.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(obj,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def main():
    wall,cpu=time.perf_counter(),time.process_time()
    record={'started_at_utc':datetime.now(timezone.utc).isoformat(),'python':sys.version,'source':{},
        'physical_calls':0,'model_updates':0,'new_predictions':0,'formal_raw_reads':0,'old_fifteen_audit_reruns':0,
        'fixture_scope':'Fresh TemporaryDirectory collector fakes and zero-cost hand-authored standard-library schema fixtures only'}
    save(Path(str(PREFIX)+'_attempt.json'),record)
    originals=[HERE/'test_pair_calibration_development.py',HERE/'test_audit_pair_calibration_promotable.py',
        HERE/'audit_pair_calibration_promotable.py',ROOT/'src/developmental_physics/pair_calibration_development.py',
        ROOT/'docs/PAIR_CALIBRATION_DEVELOPMENT_PROTOCOL.md',Path(__file__)]
    for i,path in enumerate(originals):
        data=path.read_bytes();copy=Path(str(PREFIX)+f'_{i}_'+path.name)
        with copy.open('xb') as f:f.write(data)
        record['source'][str(path)]={'snapshot':str(copy),'sha256':sha(data)}
    os.environ.pop('PAIR_CALIBRATION_SYNTHETIC_OUTPUT_ROOT',None)
    stream=io.StringIO();code=1
    with contextlib.redirect_stdout(stream),contextlib.redirect_stderr(stream):
        try:
            import mujoco
            def forbidden(*a,**k):raise AssertionError('Real MuJoCo entry forbidden in pure promotable tests')
            with patch.object(mujoco,'MjModel',SimpleNamespace(from_xml_path=forbidden)),patch.object(mujoco,'MjData',forbidden),patch.object(mujoco,'mj_step',forbidden),patch.object(mujoco,'mj_forward',forbidden):
                suite=unittest.TestSuite()
                for name in ('test_pair_calibration_development.py','test_audit_pair_calibration_promotable.py'):
                    spec=importlib.util.spec_from_file_location('pure_promotable_'+name[:-3],HERE/name)
                    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
                    suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
                result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
            code=int(not result.wasSuccessful());record.update(tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors))
        except BaseException as exc:record['exception']={'type':type(exc).__name__,'message':str(exc)};traceback.print_exc()
    for path,item in record['source'].items():
        item['after_sha256']=sha(Path(path).read_bytes());item['unchanged']=item['after_sha256']==item['sha256']
        if not item['unchanged']:code=1
    stdout=stream.getvalue().encode()
    with Path(str(PREFIX)+'_stdout.txt').open('xb') as f:f.write(stdout)
    record.update(exit_code=code,stdout_sha256=sha(stdout),wall_seconds=time.perf_counter()-wall,cpu_seconds=time.process_time()-cpu)
    save(Path(str(PREFIX)+'_execution.json'),record)
    print(stream.getvalue(),end='');print(json.dumps({k:record[k] for k in ('exit_code','wall_seconds','cpu_seconds','physical_calls','model_updates')}))
    return code
if __name__=='__main__':raise SystemExit(main())
