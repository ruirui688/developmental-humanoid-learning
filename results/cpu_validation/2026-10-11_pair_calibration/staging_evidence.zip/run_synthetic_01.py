"""Finite synthetic contract execution; physical entry points blocked."""
import contextlib
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import time
import traceback
import unittest
from unittest.mock import patch
from types import SimpleNamespace

HERE=Path(__file__).resolve().parent
PREFIX=HERE/'synthetic_01'


def sha(data):return hashlib.sha256(data).hexdigest()


def save(path,obj):
    with path.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(obj,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')


def main():
    wall,cpu=time.perf_counter(),time.process_time()
    record={'started_at_utc':datetime.now(timezone.utc).isoformat(),'python':sys.version,
        'physical_calls':0,'model_updates':0,'formal_raw_reads':0,'first_audit_reexecutions':0,
        'source':{},'imports_execute_original_files_with_exact_before_snapshots':True}
    save(Path(str(PREFIX)+'_attempt.json'),record)
    originals=[HERE/'calibration_feasibility.py',HERE/'test_calibration_feasibility.py',
               HERE/'CALIBRATION_FEASIBILITY_PROTOCOL_DRAFT.md',Path(__file__)]
    for original in originals:
        data=original.read_bytes();copy=Path(str(PREFIX)+'_'+original.name)
        with copy.open('xb') as f:f.write(data)
        record['source'][str(original)]={'snapshot':str(copy),'sha256':sha(data)}
    output_root=Path(str(PREFIX)+'_outputs');output_root.mkdir()
    os.environ['PAIR_CALIBRATION_SYNTHETIC_OUTPUT_ROOT']=str(output_root)
    stream=io.StringIO();code=1
    with contextlib.redirect_stdout(stream),contextlib.redirect_stderr(stream):
        try:
            import mujoco
            def blocked(*a,**k):raise AssertionError('Real MuJoCo entry is forbidden in synthetic tests')
            with patch.object(mujoco,'MjModel',SimpleNamespace(from_xml_path=blocked)),patch.object(mujoco,'MjData',blocked),patch.object(mujoco,'mj_step',blocked),patch.object(mujoco,'mj_forward',blocked):
                spec=importlib.util.spec_from_file_location('executed_calibration_feasibility_tests',HERE/'test_calibration_feasibility.py')
                module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
                result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module))
            code=int(not result.wasSuccessful());record.update(tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors))
        except BaseException as exc:
            record['exception']={'type':type(exc).__name__,'message':str(exc)};traceback.print_exc()
    for original,item in record['source'].items():
        item['after_sha256']=sha(Path(original).read_bytes())
        if item['after_sha256']!=item['sha256']:code=1;item['source_changed']=True
    text=stream.getvalue().encode()
    with Path(str(PREFIX)+'_stdout.txt').open('xb') as f:f.write(text)
    synthetic_metadata=[json.loads(p.read_text()) for p in output_root.rglob('metadata.json')]
    record.update(stdout_sha256=sha(text),synthetic_archive_count=len(synthetic_metadata),
        fake_backend_attempted_calls=sum(m['control_calls_attempted'] for m in synthetic_metadata),
        fake_backend_reported_substeps=sum(m['physics_steps'] for m in synthetic_metadata),
        output_sha256={str(p.relative_to(HERE)):sha(p.read_bytes()) for p in sorted(output_root.rglob('*')) if p.is_file()},
        exit_code=code,wall_seconds=time.perf_counter()-wall,cpu_seconds=time.process_time()-cpu,
        timing_scope='Imports, complete finite tests, snapshots, source stability check, synthetic archive and stdout hashes; excludes final execution write')
    save(Path(str(PREFIX)+'_execution.json'),record)
    print(stream.getvalue(),end='');print(json.dumps({k:record[k] for k in ('exit_code','wall_seconds','cpu_seconds','fake_backend_attempted_calls','physical_calls','model_updates')}))
    return code


if __name__=='__main__':raise SystemExit(main())
