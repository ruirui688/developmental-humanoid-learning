# C4 C minimal independent auditor delivery

Promote `audit_guard_exploration_development.py` to
`scripts/audit_guard_exploration_development.py` and the nine artificial standard
library tests to `tests/test_guard_exploration_audit.py`. The tests support both
staging and promoted locations. Exact SHA256 values are in `INTEGRITY.json`.

The auditor imports only four existing independent standard-library audit
helpers, never simulator, collector or online model code. It never reexecutes
an A/B audit, reads their old raw archives or refits diagonal models. Production
validity requires the immutable formal scope, clean source Git bytes, executing
auditor/support bytes, every physics source, and the selected-PD five original
source identities. Synthetic verification never validates a scientific gate.

Two independent cold coupled9 cal400 trials per seed are atomically replayed
from their own complete original native labels. Publication requires all 400
updates and complete nonterminal calibration. Available predictors on the
fresh common continuation/veto trajectory are derived from successful model
publication. Every predictor/parameter fingerprint, planned request, fixed
native q/v veto, start-G, actual substep effort and separately paid prediction
cost is independently reconstructed. No future actual torque is a model input.

For each MPC trial an explicit canonical mathematical view changes only the
current model name and excludes two independently verified zero-cost inactive
phases. Existing coupled9/H15/81-candidate mathematics checks every original
candidate and native control transition. This does not mutate any B global
scope, original archive row or scientific rule.

Frozen gates are separate: each group's own complete contribution with <=0.8
velocity error per seed/axis and strict tracking per seed plus >=20% means by
axis and joint; exploration >=20% tracking plus <=0.8 prediction and <=1.05
both actual joint efforts after continuation own contribution; selected PD
>=5% joint mean, each seed/axis/joint noninferiority, both efforts <=1.05 after
own contribution. Minimum calibration excitation per axis: >=1 nonzero start-G
complete interval and actual absolute effort >0. Common prediction requires
>=1 nonzero start-G complete interval per axis. No rank threshold.

Necessary tests pass. The single valid original-MPC artificial archive contains
6,309 artificial calls / 63,090 artificial substeps / 4,800 scalar cal updates,
15 complete / 9 study stops. First audit's float/integer shape schema mismatch
is preserved; corrected reread of the same original bytes has 2,704,019 checks,
zero failures. There was no recollection. All synthetic validated gates false.
See `ATTEMPTS.md` and the two engineering audit JSON files for exact records.

This agent made no Git operations, tracked-file edits, real physical calls,
online imports or real A/B/PD raw reads. Root retains final protocol/source
freeze, submission/push, formal one-shot execution and continued research.
