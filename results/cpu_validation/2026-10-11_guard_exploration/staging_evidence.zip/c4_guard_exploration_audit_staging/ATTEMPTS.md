# C independent auditor engineering attempt ledger

Only artificial standard-library data. Real simulation, online model imports,
real A/B/PD raw reads, Git operations and parameter fitting: zero.

1. Initial nine manual tests: eight passed, one assertion failed. The veto
   equality test used active 100, whose fixed shape is `(0, 1)`; its first axis
   request was naturally zero and therefore correctly was not vetoed. The
   test was corrected to active 200, fixed shape `(1, 1)`. No algorithm or
   protocol change. Zero physical or model update costs.

Further tests and the single original-MPC artificial archive are recorded
separately; a failed audit is retained before any corrected reread.

2. Promotion-path test loader was made location-aware for eventual `tests/`
   placement. Nine tests passed, retained `manual_tests_promotion_path.log`.
3. The one valid 24-plan original-MPC artificial archive was collected by the
   runner at `../c4_guard_exploration_staging/attempt_02/engineering/fixture/raw`.
   6,309 artificial control calls / 63,090 artificial substeps / 4,800 scalar
   calibration updates; 15 completed / 9 study stops. Its initial construction
   failure with zero calls is retained by that runner as `attempt_01`.
4. First independent audit of that same archive: 2,704,019 checks / 5,400
   failures, retained `engineering_audit_attempt_01.json`. Diagnostic shape
   labels were expected as integers while the frozen runner archives float
   shapes. Two strict label mismatches for each of 2,700 active calibration/
   prediction rows caused the failures. Auditor expectation corrected to the
   runner's float shape schema; no schedule, physical permission or scientific
   gate changed. The archive is never recollected or overwritten.
5. Corrected independent auditor reread of the identical original archive:
   2,704,019 checks / zero failures, retained `engineering_audit_attempt_02.json`.
   Paid budget reconciles 6,309 / 63,090 / 4,800 scalar. All validated scientific
   gates remain false because the fixture is artificial and its nine MPC
   control trials stop on their first active interval.
