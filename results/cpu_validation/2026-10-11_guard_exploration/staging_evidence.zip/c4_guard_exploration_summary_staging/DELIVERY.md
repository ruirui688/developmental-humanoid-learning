# C thin once-only summary 交付

- 工具：`summarize_guard_exploration_once.py`
- SHA-256：`440645b9433cb1b20b7b54fa5a00934395e0aeb7256607621b2203c21cb1705e`
- 最终C auditor声明：`962a928b5d643ed2a3d4da20da2940a9a4e17932818c859beb204f11bf59ffa3`；工具必须由root显式传入 `--expected-auditor-sha256`，没有metadata默认信任来源。
- 固定六C raw：metadata、episodes、seed_results、trace gzip、source ZIP、manifest；加firstaudit，共七份文件各一次缓存读取。输出目录排他创建，已存在即拒绝。
- 原始manifest、firstaudit六hash、source ZIP每成员、执行auditor及四support SHA、协议、clean commit声明和嵌入五PD身份绑定；嵌入PD来自缓存ZIP，不能访问原A/B/C/PD目录补身份。
- 仅透传原首审：sparse/continuation自身贡献、探索干预、两组PD门及完整资格/不完整矩阵；没有新科学门、fit/predict/RLS/MPC replay/audit/physics/Git。
- 每trial保留首审原指标、停止/blocked/不完整、原生探索veto/激励、actual努力/未知下界、模型可用性；截短指标只描述，不排序。
- 前缀/calibration/prediction/control物理费用分别求原账和；新C在线校准4800scalar/2400vector上限与实际提交数、首审RLS/预测/控制诊断/MPC数学账分别报告，offline replay=0。
- 手写fake byte/schema fixture仅执行一次：8 tests passed，wall .2224033 s、CPU .09375 s；费用、原源码、完整stdout与fake工件位于 `attempt01/`。没有复用另一fake工程档或读取真实实验数据。
- 初次静态AST准备中的路径常量未替换错误发生在工具文件写出前，保留于 `preparation_attempt01_failure.txt`；不是测试或物理失败。源码未因测试而修改。
- Root首次正式summary执行并归档；C5 prospective两文档另静态归档 `external/c5_adaptation_design_staging/`，不作为C结果或新算法收益。

命令模板：

```powershell
python external/c4_guard_exploration_summary_staging/summarize_guard_exploration_once.py --input <first-C-raw-dir> --audit <first-C-audit.json> --output <exclusive-new-summary-dir> --expected-auditor-sha256 962a928b5d643ed2a3d4da20da2940a9a4e17932818c859beb204f11bf59ffa3
```

工件仅证明来源绑定、计账与既有门的描述一致；integrity通过不能替代C科学门。
