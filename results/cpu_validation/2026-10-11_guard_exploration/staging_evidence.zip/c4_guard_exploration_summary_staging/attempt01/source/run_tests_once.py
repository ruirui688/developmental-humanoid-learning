"""Exclusive one handmade fixture test attempt, retaining source/stdout/cost."""
import contextlib
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time
import unittest

folder = Path(__file__).resolve().parent
attempt = folder / "attempt01"
attempt.mkdir(exist_ok=False)
source = attempt / "source"; source.mkdir()
snapshots = {}
for name in ("summarize_guard_exploration_once.py", "test_summarize_guard_exploration_once.py", "run_tests_once.py"):
    data = (folder / name).read_bytes(); (source / name).write_bytes(data)
    snapshots[name] = hashlib.sha256(data).hexdigest()
wall, cpu = time.perf_counter(), time.process_time(); result = None; error = None
try:
    with (attempt / "stdout.txt").open("x", encoding="utf-8") as out, contextlib.redirect_stdout(out), contextlib.redirect_stderr(out):
        spec = importlib.util.spec_from_file_location("C_thin_handmade_tests", folder / "test_summarize_guard_exploration_once.py")
        module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        suite = unittest.defaultTestLoader.loadTestsFromModule(module)
        result = unittest.TextTestRunner(stream=out, verbosity=2).run(suite)
except BaseException as exc:
    error = {"type": type(exc).__name__, "message": str(exc)}
record = {"python": sys.version, "wall_seconds": time.perf_counter()-wall, "cpu_seconds": time.process_time()-cpu,
    "tests_run": None if result is None else result.testsRun, "failures": None if result is None else len(result.failures),
    "errors": None if result is None else len(result.errors), "exception": error, "source_sha256": snapshots,
    "source_unchanged": all(hashlib.sha256((folder / n).read_bytes()).hexdigest() == h for n, h in snapshots.items()),
    "fixture_scope": "Handmade byte/schema artifacts only; no actual C/A/B/PD evidence read",
    "physical_calls": 0, "model_updates": 0, "body_predictions": 0, "audit_executions": 0, "git_queries": 0}
code = int(error is not None or result is None or not result.wasSuccessful() or not record["source_unchanged"])
record["exit_code"] = code
(attempt / "execution.json").write_text(json.dumps(record, indent=2)+"\n", encoding="utf-8")
print(json.dumps(record)); raise SystemExit(code)
