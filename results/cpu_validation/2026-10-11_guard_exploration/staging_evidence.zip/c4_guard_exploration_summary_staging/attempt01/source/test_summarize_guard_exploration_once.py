"""Handmade byte/schema fixtures only. No project modules or real experiment data."""
from copy import deepcopy
import gzip
import importlib.util
import io
import json
from pathlib import Path
import unittest
import zipfile

ROOT = Path(__file__).resolve().parent
loader = importlib.util.spec_from_file_location("thin_C_summary_under_test", ROOT / "summarize_guard_exploration_once.py")
m = importlib.util.module_from_spec(loader); loader.loader.exec_module(m)


def blob(value): return (json.dumps(value, allow_nan=False) + "\n").encode()


def packed(members, duplicate=None):
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in members.items(): z.writestr(name, data)
        if duplicate is not None: z.writestr(duplicate, members[duplicate])
    return out.getvalue()


def rebind(raw, audit):
    raw["manifest.json"] = blob({n: m.sha(b) for n, b in raw.items() if n != "manifest.json"})
    audit["archive"]["input_hashes"] = {n: m.sha(b) for n, b in raw.items()}
    return raw, blob(audit)


def handmade():
    """This production-shaped mock is not a real audit or physical evidence."""
    sources = {name: ("handmade-static-source: " + name).encode() for name in m.REQUIRED}
    pd_protocol = {"path": m.PD_PROTOCOL, "sha256": m.sha(sources[m.PD_PROTOCOL])}
    pd_inner = {m.PD_PROTOCOL: sources[m.PD_PROTOCOL], "scripts/audit_pair_pd.py": b"handmade-PD-auditor",
                "scripts/audit_local_frozen.py": b"handmade-PD-support"}
    pd_zip = packed(pd_inner)
    pd_metadata = {"protocol": pd_protocol, "source_snapshot_sha256": m.sha(pd_zip),
                   "source_sha256": {n: m.sha(b) for n, b in pd_inner.items()}}
    pd_metadata_blob = blob(pd_metadata)
    records = {"raw/" + n: {"kind": "handmade-only", "source": "fake/" + n, "bytes": len(b), "sha256": m.sha(b)}
        for n, b in {"metadata.json": pd_metadata_blob, "source_snapshot.zip": pd_zip,
            "manifest.json": b"dummy-PD-raw-manifest", "episodes.json": b"dummy-PD-episodes",
            "selection.json": b"dummy-PD-raw-selection", "trace.jsonl.gz": b"dummy-PD-trace"}.items()}
    pd_outer = blob({"protocol": pd_protocol, "files": records})
    pd_audit = blob({"validated_selection": True, "source_git_verification_enabled": True, "failed_checks": 0,
        "input_hashes": {n[4:]: r["sha256"] for n, r in records.items()},
        "selection": {"status": "selected", "picked": {"candidate": 2, "kp": [64., 64.], "kd": [0., 4.],
            "eligible": True, "paid_control_steps": 900, "paid_physics_steps": 9000}},
        "audit_sources_sha256": {"auditor": m.sha(pd_inner["scripts/audit_pair_pd.py"]),
                                  "common": m.sha(pd_inner["scripts/audit_local_frozen.py"])}})
    pd_sources = {label: {"path": m.PD_ROOT + name, "sha256": m.sha(b)}
        for label, name, b in (("manifest", "manifest.json", pd_outer), ("audit", "first_audit.json", pd_audit))}
    pd_selection = blob({"schema": "c4-pd-selection-v1", "status": "selected", "selected": {
        "candidate_id": 2, "joint_indices": [0, 1], "kp": [64., 64.], "kd": [0., 4.]},
        "protocol": pd_protocol, "sources": pd_sources})
    pd_blobs = {"selection.json": pd_selection, "manifest.json": pd_outer, "first_audit.json": pd_audit,
                "raw/metadata.json": pd_metadata_blob, "raw/source_snapshot.zip": pd_zip}
    for n, b in pd_blobs.items(): sources[m.PD_ROOT + n] = b
    binding = {"schema": "c4-pd-source-binding-v1", "status": "selected", "selected_id": 2, "joint_indices": [0, 1],
        "kp": [64., 64.], "kd": [0., 4.], "selection_path": m.PD_ROOT + "selection.json",
        "selection_sha256": m.sha(pd_selection), "selection_tracking_evidence": "caller_verified_tracked_paths",
        "sources": pd_sources, "source_records": {m.PD_ROOT + n: m.sha(b) for n, b in pd_blobs.items()},
        "protocol": pd_protocol, "archive_member_records": {n: m.sha(pd_inner[n]) for n in pd_inner},
        "audit_selection_confirmed": True, "audit_reexecuted": False, "raw_trace_or_episodes_read": False,
        "remaining_original_bytes": "not reread; manifest hashes matched existing independent audit input_hashes"}
    expected = m.sha(sources[m.AUDITOR]); source_zip = packed(sources)
    metadata = {"schema_version": 1, "suite": "guard_exploration_development", "synthetic": False,
        "source_status": "", "source_dirty": False, "seeds": [0, 1, 2], "pose": "supine", "joint_indices": [0, 1],
        "split": "development", "native_joint_count": 8, "gpu": None, "backend": "MuJoCo CPU",
        "prefix_steps": 100, "calibration_steps": 400, "prediction_steps": 100, "control_steps_per_trial": 200,
        "maximum_control_steps": 8100, "maximum_physics_steps": 81000, "maximum_scalar_updates": 4800,
        "maximum_vector_updates": 2400, "calibration_data_shared": False, "prior_a_b_raw_replayed": False,
        "policy_parameter_updates": 0, "gain_updates": 0, "gate_updates": 0, "teacher_calls": 0,
        "source_commit": "0"*40, "source_snapshot_sha256": m.sha(source_zip),
        "source_sha256": {n: m.sha(b) for n, b in sources.items()},
        "independent_auditor": {"path": m.AUDITOR, "sha256": expected, "pending": False, "required_for_formal": True},
        "protocol": {"path": m.PROTOCOL, "sha256": m.sha(sources[m.PROTOCOL])},
        "pd_binding": binding, "pd_gains": {"kp": [64., 64.], "kd": [0., 4.]},
        "control_calls_attempted": 0, "control_steps": 0, "physics_steps": 0,
        "model_updates": 0, "vector_model_updates": 0, "completed_trials": 0, "terminated_trials": 0,
        "exception_trials": 0, "blocked_trials": 24}
    episodes = [{"trial_id": f"seed{s}_{kind}", "seed": s, "kind": kind, "status": "blocked",
        "control_calls_attempted": 0, "control_steps": 0, "physics_steps": 0,
        "phase_budgets": {p: {k: 0 for k in m.KEYS} for p in m.PHASES}}
        for s in (0, 1, 2) for kind in m.KINDS]
    original = [{"seed": s, "evaluations": {k: {"status": "blocked"} for k in m.KINDS}, "calibrations": {}}
                for s in (0, 1, 2)]
    derived = [{"seed": s, "evaluations": {k: {"eligible": False, "completed": False, "status": "blocked"}
                for k in m.KINDS}} for s in (0, 1, 2)]
    gate = {"evaluated": False, "passed": False, "validated_pass": False, "required_trials_complete": False}
    audit = {"schema_version": 1, "checks": 1, "failed": 0, "violations": [], "immutable_scope": deepcopy(m.SCOPE),
        "audit_script_sha256": expected, "audit_dependency_sha256": {n: m.sha(sources[n]) for n in m.SUPPORT},
        "archive": {"episodes": episodes, "seeds": derived,
            "budget": {k: 0 for k in (*m.KEYS, "model_updates", "vector_model_updates")},
            "paid_pair_prediction_attempts": {k: 0 for k in ("rls", "prediction", "control_diagnostic", "mpc")}},
        "final_gates": {"body_contribution": {g: deepcopy(gate) for g in m.GROUPS},
            "exploration_intervention": deepcopy(gate), "selected_pd_comparison": {g: deepcopy(gate) for g in m.GROUPS},
            "matrix_complete": {"passed": False, "validated_pass": False}, "data_consistency_verified": True},
        "execution": {"source_git_verification_enabled": True, "physical_simulation_calls": 0,
            "model_parameter_updates": 0, "online_model_imports": 0, "prior_A_B_audit_reexecutions": 0,
            "diagonal_model_refits": 0}}
    raw = {"metadata.json": blob(metadata), "episodes.json": blob(episodes), "seed_results.json": blob(original),
           "trace.jsonl.gz": gzip.compress(b""), "source_snapshot.zip": source_zip}
    raw, audit_blob = rebind(raw, audit)
    return raw, audit_blob, expected


class ThinSummaryTests(unittest.TestCase):
    def test_failure_gates_and_blocked_trials_are_preserved(self):
        raw, first, expected = handmade(); result = m.summarize(raw, first, expected, m.Checks())
        self.assertEqual(result["scientific_gates_from_first_audit"], m.parse(first)["final_gates"])
        self.assertEqual(result["statuses"], {"blocked": 24})
        self.assertFalse(result["control_ranking_computed"])
        self.assertTrue(all(t["truncated_metrics_descriptive_only"] for t in result["trials"]))
        self.assertEqual(result["C_new_online_calibration_updates"]["maximum_scalar_updates"], 4800)

    def test_execute_reads_seven_fake_originals_once_and_refuses_overwrite(self):
        raw, first, expected = handmade(); base = ROOT / "attempt01" / "fake_execution"
        base.mkdir(); source = base / "raw"; source.mkdir()
        for name, data in raw.items(): (source / name).write_bytes(data)
        audit_path = base / "fake_first_audit.json"; audit_path.write_bytes(first)
        output = base / "summary"
        code, result = m.execute(source, audit_path, output, expected)
        self.assertEqual(code, 0); self.assertEqual(result["summary_status"], "bound_descriptive_summary")
        costs = m.parse((output / "read_cost.json").read_bytes())
        self.assertEqual(costs["total_original_read_attempts"], 7)
        self.assertTrue(all(r["read_attempts"] == r["successful_reads"] == 1 for r in costs["original_inputs"].values()))
        self.assertEqual(costs["A_B_PD_original_filesystem_reads"], 0)
        with self.assertRaises(FileExistsError): m.execute(source, audit_path, output, expected)

    def test_root_expected_auditor_never_defaults_to_metadata(self):
        raw, first, expected = handmade()
        for wrong in (None, "", "f"*64):
            with self.assertRaises(ValueError): m.summarize(raw, first, wrong, m.Checks())

    def test_duplicate_zip_members_denied_with_other_bindings_resealed(self):
        raw, first, expected = handmade(); audit = m.parse(first); metadata = m.parse(raw["metadata.json"])
        with zipfile.ZipFile(io.BytesIO(raw["source_snapshot.zip"])) as z: sources = {n: z.read(n) for n in z.namelist()}
        raw["source_snapshot.zip"] = packed(sources, duplicate=m.AUDITOR)
        metadata["source_snapshot_sha256"] = m.sha(raw["source_snapshot.zip"])
        raw["metadata.json"] = blob(metadata); raw, first = rebind(raw, audit)
        with self.assertRaisesRegex(ValueError, "unique names"): m.summarize(raw, first, expected, m.Checks())

    def test_embedded_pd_identity_not_trusted_from_metadata(self):
        raw, first, expected = handmade(); audit = m.parse(first); metadata = m.parse(raw["metadata.json"])
        metadata["pd_binding"]["source_records"][m.PD_ROOT + "first_audit.json"] = "f"*64
        raw["metadata.json"] = blob(metadata); raw, first = rebind(raw, audit)
        with self.assertRaisesRegex(ValueError, "embedded PD original binding"): m.summarize(raw, first, expected, m.Checks())

    def test_original_online_update_counter_mismatch_denied(self):
        raw, first, expected = handmade(); audit = m.parse(first); metadata = m.parse(raw["metadata.json"])
        metadata["model_updates"] = 2; raw["metadata.json"] = blob(metadata); raw, first = rebind(raw, audit)
        with self.assertRaisesRegex(ValueError, "committed update sum"): m.summarize(raw, first, expected, m.Checks())

    def test_reader_failed_attempt_retained_without_second_read(self):
        reader = m.Reader(); missing = ROOT / "attempt01" / "deliberately_missing_fake_input"
        with self.assertRaises(FileNotFoundError): reader.read("metadata.json", missing)
        with self.assertRaisesRegex(ValueError, "Second original read denied"): reader.read("metadata.json", missing)
        record = reader.record()["original_inputs"]["metadata.json"]
        self.assertEqual(record["read_attempts"], 1); self.assertEqual(record["successful_reads"], 0)

    def test_stopped_score_is_only_descriptive_and_never_ranked(self):
        raw, first, expected = handmade(); audit = m.parse(first)
        episodes = m.parse(raw["episodes.json"]); metadata = m.parse(raw["metadata.json"])
        ep = next(e for e in episodes if e["trial_id"] == "seed0_nominal_guard")
        ep.update(status="terminated", reason={"type": "handmade-stop-before-request"})
        metadata.update(terminated_trials=1, blocked_trials=23)
        audit["archive"]["episodes"] = episodes
        audit["archive"]["seeds"][0]["evaluations"]["nominal_guard"].update(
            status="terminated", tracking_rmse_rad=.0001, complete_score_endpoints=0)
        raw["episodes.json"] = blob(episodes); raw["metadata.json"] = blob(metadata)
        raw, first = rebind(raw, audit)
        result = m.summarize(raw, first, expected, m.Checks())
        trial = next(t for t in result["trials"] if t["trial_id"] == "seed0_nominal_guard")
        self.assertTrue(trial["truncated_metrics_descriptive_only"])
        self.assertFalse(trial["eligible"]); self.assertFalse(result["control_ranking_computed"])
        self.assertFalse(result["scientific_gates_from_first_audit"]["body_contribution"]["continuation"]["validated_pass"])


if __name__ == "__main__": unittest.main()
