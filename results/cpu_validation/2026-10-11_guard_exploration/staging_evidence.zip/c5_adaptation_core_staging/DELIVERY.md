# C5完整状态克隆：数学工程准备

仅ignored staging与外层人工检查wrapper新增；没有修改已有coupled/RLS核心，没有读取真实A/B/C/PD原件、Git或运行物理。

`adaptation_model_clone.py`复制同一不可变RLS发布的theta、P、向量计数、qref、公开guard和所有声明配置；frozen控制、online控制和不控制的shadow独立持有数组。online新增更新按初始计数差计算，不把继承的cal400再计为本trial新学习。

首次4项人工检查通过，pytest0.09s、外层wall1.5079766s/CPU.6875s；实际两次人工update尝试、一vector/two scalar提交、两pair/four scalar内置预测。手写fixture的继承400是人工计数事实，不是400次已执行校准；所有数学费用与真实物理/在线项目账分开，真物理与真实archive读取均0。

检查覆盖完整协方差/计数/guard克隆且无数组共享、仅online更新且frozen/shadow不变、第二proposal失败无新commit以及缺失/可训练/重置模型的拒绝。没有泛化异常框架或模拟新的C5事件。

源码SHA：helper `366a274c2464d222222ad9d027f98b05f56c5284cea7b58bc595a0c208edeab8`；tests `1402c252ea6496b6345a366393fd511ffa62c90f03d243eb1d9c51681a955c19`。原件在`attempt01/`、外层wrapper `external/run_c5_clone_core_once.py`和stdout `external/c5_clone_core_01_stdout.txt`。

这是prospective C5模型克隆工程，无科学适应结果；C完整贡献与C5新校准资格仍必须满足。后续正式提升时需把helper/tests源码路径改为正常包导入，并由独立auditor重构状态与新增计数差，不能以本检查放行物理。协议设计位于`external/c5_adaptation_design_staging/`。
