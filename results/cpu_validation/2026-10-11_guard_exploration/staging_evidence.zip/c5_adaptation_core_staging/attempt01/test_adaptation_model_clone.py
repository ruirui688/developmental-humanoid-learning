"""Handwritten states; no real calibration, simulator or archive read."""
import importlib.util
from pathlib import Path
import sys

import numpy as np
import pytest

from developmental_physics.guard_coupled_pair_model import GuardCoupledPairBodyModel
from developmental_physics.local_pair_model import _parameter_state

spec=importlib.util.spec_from_file_location('c5_clone_tested',Path(__file__).with_name('adaptation_model_clone.py'))
helper=importlib.util.module_from_spec(spec);sys.modules[spec.name]=helper;spec.loader.exec_module(helper)


def source_fixture():
    model=GuardCoupledPairBodyModel((.1,.1),public_joint_ranges=((-1.,1.),(0.,2.)))
    # 400 is an explicit artificial inherited counter, not 400 executed updates.
    theta=model.coefficients;theta[0,1]=.2;theta[1,0]=-.1
    covariance=model.covariance;covariance[0,0,1]=covariance[0,1,0]=.3
    covariance[1]*=.7
    model._state=_parameter_state(theta,covariance,400)
    return model.clone_frozen()


def test_online_preserves_covariance_and_inherited_count_without_aliasing():
    source=source_fixture();actors=helper.independent_actors(source)
    old=source.snapshot()
    for name in ('online','frozen','shadow'):
        model=actors[name];snapshot=model.snapshot();snapshot['trainable']=False
        assert snapshot==old
        assert not np.shares_memory(source._state.theta,model._state.theta)
        assert not np.shares_memory(source._state.covariance,model._state.covariance)
    assert actors['online'].trainable and not actors['shadow'].trainable
    assert actors['new_vector_updates']==actors['new_scalar_updates']==0


def test_new_updates_exclude_inheritance_and_leave_other_actors_unchanged():
    source=source_fixture();actors=helper.independent_actors(source)
    before={n:actors[n].snapshot() for n in ('frozen','shadow')}
    actors['online'].update((.1,.1),(.01,.02),(.125,.125),(.03,.04),
                            transition_id='handwritten:0',phase='identification')
    ledger=helper.trial_update_delta(actors['online'],400)
    assert ledger['new_vector_updates']==1 and ledger['new_scalar_updates']==2
    assert ledger['final_vector_updates']==401 and ledger['inherited_scalar_updates']==800
    assert source.snapshot()==source_fixture().snapshot()
    assert all(actors[n].snapshot()==before[n] for n in before)


def test_failed_second_proposal_has_zero_new_cost_and_cannot_damage_shared_start(monkeypatch):
    source=source_fixture();actors=helper.independent_actors(source)
    online=actors['online'];old=online.snapshot();original=online._propose_update
    def fail(index,*args,**kwargs):
        if index==1:raise ValueError('artificial second proposal failure')
        return original(index,*args,**kwargs)
    monkeypatch.setattr(online,'_propose_update',fail)
    with pytest.raises(ValueError):
        online.update((.1,.1),(.01,.02),(.125,.125),(.03,.04),
                      transition_id='handwritten:1',phase='identification')
    assert online.snapshot()==old
    assert helper.trial_update_delta(online,400)['new_scalar_updates']==0
    assert actors['shadow'].snapshot()==source.snapshot()


def test_missing_trainable_or_replaced_start_is_rejected():
    with pytest.raises(ValueError):helper.clone_for_online(None)
    trainable=GuardCoupledPairBodyModel((.1,.1),public_joint_ranges=((-1.,1.),(0.,2.)))
    with pytest.raises(ValueError):helper.clone_for_online(trainable)
    with pytest.raises(ValueError):helper.trial_update_delta(trainable,400)
    with pytest.raises(ValueError):helper.trial_update_delta(trainable,True)
