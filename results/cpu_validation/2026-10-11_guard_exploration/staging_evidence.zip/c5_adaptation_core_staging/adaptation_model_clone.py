"""Prospective C5 complete-state cloning; pure body-model mathematics only.

This helper does not establish C scientific eligibility and cannot start an
environment. The separate frozen collector/auditor must enforce all protocol
dependencies. Counts inherited from calibration are never new trial updates.
"""
from developmental_physics.guard_coupled_pair_model import GuardCoupledPairBodyModel
from developmental_physics.local_pair_model import _parameter_state


def clone_for_online(source):
    """Copy the exact immutable RLS publication, including P and counters."""
    if type(source) is not GuardCoupledPairBodyModel or source.trainable:
        raise ValueError('A frozen public-guard coupled calibration model is required')
    state = source._state
    clone = GuardCoupledPairBodyModel(source.qref,
        public_joint_ranges=source.public_guard.public_joint_ranges,
        dt=source.dt, trainable=True)
    clone._state = _parameter_state(state.theta.copy(), state.covariance.copy(),
                                    state.vector_update_count)
    old, new = source.snapshot(), clone.snapshot()
    new['trainable'] = False
    if new != old:
        raise ValueError('Online clone did not preserve the full declared model state')
    return clone


def independent_actors(source):
    """Fresh online actor, frozen actor and noncontrolling frozen shadow."""
    online = clone_for_online(source)
    frozen, shadow = source.clone_frozen(), source.clone_frozen()
    return {'online': online, 'frozen': frozen, 'shadow': shadow,
        'initial_parameter_fingerprint': source.parameter_fingerprint(),
        'inherited_vector_updates': source.update_count,
        'inherited_scalar_updates': source.scalar_update_count,
        'new_vector_updates': 0, 'new_scalar_updates': 0,
        'scope': 'Independent cloned RLS states; no physical interaction or fit.'}


def trial_update_delta(model, inherited_vector_updates):
    """Actual atomic counter change; retain it even after a failed return."""
    if type(inherited_vector_updates) is not int or inherited_vector_updates < 0:
        raise ValueError('A nonnegative inherited vector counter is required')
    if type(model) is not GuardCoupledPairBodyModel:
        raise ValueError('Exact public-guard coupled model required')
    delta = model.update_count - inherited_vector_updates
    if delta < 0:
        raise ValueError('Trial model count went backwards; no reset or replacement allowed')
    return {'inherited_vector_updates': inherited_vector_updates,
        'inherited_scalar_updates': 2 * inherited_vector_updates,
        'new_vector_updates': delta, 'new_scalar_updates': 2 * delta,
        'final_vector_updates': model.update_count,
        'final_scalar_updates': model.scalar_update_count}
