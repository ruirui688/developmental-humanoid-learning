# C 一次封口归档工具交付

- 工具：`external/archive_guard_exploration_20261011_once.py`
- SHA-256：`566cfa212544eca672689f81ab35d500b6fa38ffdfba1faaa780984d2b2e46ff`
- 固定目标：`results/cpu_validation/2026-10-11_guard_exploration`，独占创建，不覆盖既有工件。
- 原始输入：C 首次六raw、firstaudit、once-summary、四种原始stdout、首次/后处理execution和两个wrapper原源码。名称沿B，root已确认。
- 执行时显式绑定 root冻结commit；auditor SHA固定 `962a928b5d643ed2a3d4da20da2940a9a4e17932818c859beb204f11bf59ffa3`；summary SHA固定 `440645b9433cb1b20b7b54fa5a00934395e0aeb7256607621b2203c21cb1705e`。
- 工具仅缓存原字节、复制、SHA/ZIP与既有身份/计账绑定；每原路径成功读取一次，sourceZIP每成员一次。不会重新audit/summary、fit/predict/RLS/MPC、physics或Git。
- 保留firstaudit的source_git_verification声明及source hash映射；若存在其verified_source_git_blobs字段原样保存，缺失则为null，不发明计数或重新Git核验。
- C当前源、共享C/原PD源和嵌入原PD五身份证据分类保存；不从当前tracked文件重建运行源。
- 原五个科学子门完整复制；all_trials_successful与含最低激励的matrix_complete分开保存，不新增科研门、不排序截短结果。
- 全部C runner/auditor/summary staging递归打包（仅排除瞬时__pycache__），包括attempt_01/02工程原档、5400类型错误审核、全部手写测试、AST准备失败和production_preflight_01/02。C5 design/core及clone原stdout/wrapper作为准备材料单列，不称为C科学数据。
- 累计先付239120调用/控制步、2391200子步、17652在线scalar、2400既有B离线scalar；新增C按绑定原件另计，在线/离线、调用/步数/子步均分列。
- 子代理仅静态准备、AST解析、工具自身哈希及目录/文件名清单检查；未执行归档，未读取正在写盘/真实C/A/B/PD raw，未运行测试/模型/physics/audit/summary/Git，未改tracked。
- Root首次执行后检查外manifest并提交推送。字节完整不代表C科学门通过。

执行命令：

```powershell
python external/archive_guard_exploration_20261011_once.py --expected-source-commit 5ea8df42b09588845760daf0dc1f270aef2a87f1
```
