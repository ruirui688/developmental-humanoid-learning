"""First pure cloned-state regressions, with actual mathematical call counts."""
from pathlib import Path
import hashlib
import json
import os
import time

import pytest
from developmental_physics.local_pair_model import PairBodyModel

root=Path(__file__).resolve().parents[1]
stage=root/'external/c5_adaptation_core_staging'
out=stage/'attempt01';out.mkdir(exist_ok=False)
for name in ('adaptation_model_clone.py','test_adaptation_model_clone.py'):
 (out/name).write_bytes((stage/name).read_bytes())
cost={'real_physical_calls':0,'real_physics_substeps':0,'real_archive_reads':0,'Git_calls':0,
 'vector_update_attempts':0,'committed_vector_updates':0,'committed_scalar_updates':0,
 'pair_prediction_attempts':0,'pair_prediction_successes':0,
 'scalar_prediction_attempts':0,'scalar_prediction_successes':0}
old_update,old_predict=PairBodyModel.update,PairBodyModel._predict_state
def update(self,*args,**kwargs):
 cost['vector_update_attempts']+=1;before=self.update_count
 try:return old_update(self,*args,**kwargs)
 finally:
  delta=self.update_count-before
  cost['committed_vector_updates']+=delta;cost['committed_scalar_updates']+=2*delta
def predict(self,*args,**kwargs):
 cost['pair_prediction_attempts']+=1;cost['scalar_prediction_attempts']+=2
 result=old_predict(self,*args,**kwargs)
 cost['pair_prediction_successes']+=1;cost['scalar_prediction_successes']+=2
 return result
PairBodyModel.update=update;PairBodyModel._predict_state=predict
wall,cpu=time.perf_counter(),time.process_time()
try:
 code=pytest.main(['-q',str(stage/'test_adaptation_model_clone.py'),'--junitxml',str(out/'tests.xml')])
finally:
 PairBodyModel.update=old_update;PairBodyModel._predict_state=old_predict
record={'exit_code':int(code),'wall_seconds':time.perf_counter()-wall,'cpu_seconds':time.process_time()-cpu,
 'scope':'Pure synthetic state fixtures; inherited counter400 is handwritten, not executed calibration.',
 'actual_cost':cost,'source_sha256':{n:hashlib.sha256((out/n).read_bytes()).hexdigest()
                                  for n in ('adaptation_model_clone.py','test_adaptation_model_clone.py')},
 'source_C_or_C5_science_validated':False}
with (out/'execution.json').open('x',encoding='utf-8') as stream:
 json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record,indent=2))
raise SystemExit(code)
