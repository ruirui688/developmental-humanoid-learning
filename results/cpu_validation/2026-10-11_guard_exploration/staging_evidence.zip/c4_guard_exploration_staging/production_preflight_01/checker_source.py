"""Six production-wiring checks, stdlib/AST only; zero physics/model/math/Git.

The only executed production code is an isolated entry-point AST with its draft
flag set False. No production module is imported; guard refusal precedes all
dependencies, filesystem operations, source reads and environment creation.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
from pathlib import Path
import time

ROOT = next(p for p in Path(__file__).resolve().parents if (p / "pyproject.toml").is_file())
STAGE = Path(__file__).resolve().parent
SOURCE = "src/developmental_physics/guard_exploration_development.py"
PROTOCOL = "docs/GUARD_EXPLORATION_DEVELOPMENT_PROTOCOL.md"
AUDITOR = "scripts/audit_guard_exploration_development.py"
TESTS = "tests/test_guard_exploration_development.py"
CORE = "src/developmental_physics/guard_coupled_pair_model.py"
EXPECTED = {
    SOURCE: "9ad08faaa663f3d86d7d0a0947b0b24c16ebabe07dd98402a3c213e7314f64af",
    PROTOCOL: "b3632387938dbb2ec018599e4168815119836f17843be6c8d6038067da573038",
    AUDITOR: "962a928b5d643ed2a3d4da20da2940a9a4e17932818c859beb204f11bf59ffa3",
    TESTS: "1132c0c77732b2ff0ce2194a72399b0afafaba232d5b29271519fe1e762442fe",
    CORE: "7f234760e8f3d5b9cc799c871e84e7adfebecdf92e11f315735fad8b38ad78ed",
}


def constants(tree):
    result = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            try:
                result[node.targets[0].id] = ast.literal_eval(node.value)
            except (ValueError, TypeError):
                pass
    return result


def function(tree, name):
    return next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == name)


def call_lines(node, names):
    return [part.lineno for part in ast.walk(node) if isinstance(part, ast.Call)
            and (isinstance(part.func, ast.Name) and part.func.id in names
                 or isinstance(part.func, ast.Attribute) and part.func.attr in names)]


def check_files(blobs, trees, records):
    for name, expected in EXPECTED.items():
        assert hashlib.sha256(blobs[name]).hexdigest() == expected, f"exact production bytes: {name}"
    c = constants(trees[SOURCE])
    assert c["FORMAL_EXECUTION_FROZEN"] is True
    assert c["SOURCE_PATH"] == SOURCE and c["PROTOCOL_PATH"] == PROTOCOL and c["AUDITOR_PATH"] == AUDITOR
    records.append({"name": "production_flags_paths_and_exact_source_bytes", "passed": True,
                    "production_flag": True, "paths": list(EXPECTED)})


def check_self_contained(blobs, trees, records):
    c = constants(trees[SOURCE])
    paths = list(c["AUDITOR_SUPPORT_PATHS"])
    dependencies = []
    for node in ast.walk(trees[SOURCE]):
        if isinstance(node, ast.ImportFrom) and node.module and node.module.startswith("developmental_physics."):
            name = "src/"+node.module.replace(".", "/")+".py"
            assert (ROOT/name).is_file(), name
            dependencies.append(name)
    for name in paths:
        assert (ROOT/name).is_file() and not name.startswith("external/"), name
    assert "external/" not in blobs[SOURCE].decode("utf-8")
    assert all((ROOT/name).resolve().is_relative_to(ROOT) for name in paths+dependencies)
    assert constants(trees[SOURCE])["KINDS"] == ("calibration_sparse", "calibration_continuation", "prediction",
        "nominal_guard", "learned_sparse", "learned_continuation", "PDselected", "zero")
    records.append({"name": "production_imports_and_math_supports_self_contained", "passed": True,
                    "direct_internal_imports": dependencies, "audit_supports": paths,
                    "production_modules_imported": 0})


def check_guard_order(blobs, trees, records):
    entry = function(trees[SOURCE], "run_guard_exploration_development")
    formal = function(trees[SOURCE], "_formal_provenance")
    first_guard = entry.body[0]
    assert isinstance(first_guard, ast.If) and isinstance(first_guard.body[0], ast.Raise)
    assert "FORMAL_EXECUTION_FROZEN" in ast.unparse(first_guard.test)
    assert min(call_lines(entry, {"_formal_provenance"})) < min(call_lines(entry, {"mkdir", "run_trial"}))
    status_guard = next(node for node in formal.body if isinstance(node, ast.If)
                        and isinstance(node.test, ast.Name) and node.test.id == "status")
    assert isinstance(status_guard.body[0], ast.Raise)
    assert status_guard.lineno < min(call_lines(formal, {"read_bytes", "load_pd_binding"}))
    assert "frozen tracked path" in ast.get_source_segment(blobs[SOURCE].decode("utf-8"), formal)
    records.append({"name": "draft_and_formal_source_guards_precede_io_and_trials", "passed": True,
                    "check_kind": "AST call ordering only; no provenance/Git/PD/physics execution"})


def check_draft_refusal(blobs, trees, records):
    entry = function(trees[SOURCE], "run_guard_exploration_development")
    namespace = {"FORMAL_EXECUTION_FROZEN": False}
    # Only this function AST is compiled. Defaults are literals; guard executes
    # before any missing global could perform I/O, imports, model work or Git.
    exec(compile(ast.Module(body=[entry], type_ignores=[]), "isolated_draft_guard", "exec"), namespace)
    try:
        namespace[entry.name]("never-created", protocol_path="never-read", synthetic=False)
    except RuntimeError as error:
        assert str(error) == "draft C real execution disabled until root freezes protocol, source and auditor"
    else:
        raise AssertionError("draft must refuse before resolving paths or dependencies")
    assert set(namespace) == {"FORMAL_EXECUTION_FROZEN", "__builtins__", entry.name}
    records.append({"name": "isolated_entry_point_draft_refuses_before_dependencies", "passed": True,
                    "isolated_guard_calls": 1, "physical_calls": 0, "file_operations_inside_guard": 0})


def check_frozen_gates(blobs, trees, records):
    spec = next(node for node in trees[AUDITOR].body if isinstance(node, ast.ClassDef) and node.name == "ExplorationAuditSpec")
    decorator = spec.decorator_list[0]
    assert isinstance(decorator, ast.Call) and any(key.arg == "frozen" and ast.literal_eval(key.value) is True for key in decorator.keywords)
    method = next(node for node in spec.body if isinstance(node, ast.FunctionDef) and node.name == "record")
    mapping = method.body[0].value
    record = {ast.literal_eval(key): ast.literal_eval(value) for key, value in zip(mapping.keys, mapping.values)
              if not isinstance(value, ast.Attribute)}
    expected = {"prediction_velocity_ratio_max": .8, "body_tracking_mean_improvement_min": .20,
        "exploration_prediction_ratio_max": .8, "exploration_tracking_mean_improvement_min": .20,
        "exploration_actual_effort_ratio_max": 1.05, "pd_tracking_joint_mean_improvement_min": .05,
        "pd_actual_effort_ratio_max": 1.05, "minimum_calibration_nonzero_start_G_intervals_per_axis": 1,
        "minimum_calibration_actual_absolute_effort_positive_per_axis": True,
        "minimum_prediction_nonzero_start_G_intervals_per_axis": 1}
    assert all(record[key] == value and type(record[key]) is type(value) for key, value in expected.items())
    protocol = "".join(blobs[PROTOCOL].decode("utf-8").split())
    for text in ("每seed每axisvelocityRMSE<=.8nominal", "每seed每axisprediction<=.8sparse",
                 "各<=1.05sparse", "joint均值改善>=5%", "各<=1.05PD", "不加rank阈值",
                 "控制期没有explorationveto", "校准完整区间至少一条非零start-G"):
        assert text in protocol, text
    assert protocol.count("改善>=20%") >= 2
    records.append({"name": "immutable_auditor_and_protocol_keep_strict_scientific_gates", "passed": True,
                    "gate_constants": expected, "scientific_gate_execution": 0})


def check_core(blobs, trees, records):
    assert hashlib.sha256(blobs[CORE]).hexdigest() == EXPECTED[CORE]
    assert (ROOT / TESTS).read_bytes() == (STAGE / "test_guard_exploration_development.py").read_bytes()
    records.append({"name": "protected_coupled_core_and_promoted_tests_original_bytes", "passed": True,
                    "core_sha256": EXPECTED[CORE], "test_matrix_reexecuted": False})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    output = parser.parse_args().output.resolve()
    if not output.is_relative_to(STAGE) or output.exists():
        raise ValueError("new exclusive evidence directory within this C staging required")
    started, cpu_started = time.perf_counter(), time.process_time()
    output.mkdir(parents=True)
    blobs = {name: (ROOT/name).read_bytes() for name in EXPECTED}
    trees = {name: ast.parse(blob, filename=name) for name, blob in blobs.items() if name.endswith(".py")}
    checks, error = [], None
    try:
        for callback in (check_files, check_self_contained, check_guard_order, check_draft_refusal, check_frozen_gates, check_core):
            callback(blobs, trees, checks)
    except BaseException as exc:
        error = {"type": type(exc).__name__, "message": str(exc)}
    report = {"scope": "six production AST/source/guard checks only", "passed_checks": len(checks),
        "failed_checks": int(error is not None), "checks": checks, "error": error,
        "input_sha256": {name: hashlib.sha256(blob).hexdigest() for name, blob in blobs.items()},
        "real_physical_calls": 0, "fake_environment_calls": 0, "physics_substeps": 0,
        "model_predictions": 0, "RLS_updates": 0, "MPC_selects": 0, "real_git_calls": 0,
        "real_A_B_PD_raw_reads": 0, "production_modules_imported": 0,
        "wall_seconds": time.perf_counter()-started, "cpu_seconds": time.process_time()-cpu_started}
    (output / "result.json").write_text(json.dumps(report, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")
    (output / "checker_source.py").write_bytes(Path(__file__).read_bytes())
    print(json.dumps(report, indent=2, ensure_ascii=False))
    if error is not None:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
