# 生产路径最小验收

只新增本检查文件与证据目录；生产源码、既有草稿/测试/原档/DELIVERY/INTEGRITY
均未修改。无实际 Git、环境构造/积分、数学预测、RLS、MPC、旧真实raw读取。
未重跑29合成矩阵，未collect假环境整档。使用Python3.10标准库AST和哈希。

`production_preflight_01/`保留首次检查器源码与result：前4项通过，第5项把
SOURCE变量引用交给literal_eval报ValueError，第6项未运行。只有检查器修正
跳过非literal，生产输入字节没有改动。

`production_preflight_02/`保存修正后的checker_source.py和result.json：6项
全部通过、0失败，wall0.0428740999s/CPU0.046875s。费用字段全部0。

1. 生产正式flag=True、SOURCE/PROTOCOL/AUDITOR规范路径及预告字节精确匹配。
2. 八个内部import和四个独立数学support在生产目录自包含，未import模块。
3. AST确认draft guard先于依赖，formal来源验证先于I/O/trial，clean status
   检查先于PD/字节读取。
4. 只隔离编译entry函数AST，设draft flag False，1次调用即RuntimeError拒绝；
   命名空间未提供任何Path、环境、模型或Git，函数没有进入这些依赖。
5. auditor frozen dataclass原始.8/20%/1.05/PD5%与最低激励常量、协议条文
   精确匹配；没有执行科研门或重放审计。
6. protected coupled core与提升后的原tests字节一致。

核验输入SHA：

- runner：9ad08faaa663f3d86d7d0a0947b0b24c16ebabe07dd98402a3c213e7314f64af
- protocol：b3632387938dbb2ec018599e4168815119836f17843be6c8d6038067da573038
- auditor：962a928b5d643ed2a3d4da20da2940a9a4e17932818c859beb204f11bf59ffa3
- tests：1132c0c77732b2ff0ce2194a72399b0afafaba232d5b29271519fe1e762442fe
- core：7f234760e8f3d5b9cc799c871e84e7adfebecdf92e11f315735fad8b38ad78ed

这是生产接线、字节与拒绝路径检查；正式clean Git/PD身份核验仍由首次正式
collector在任何物理之前执行。此记录不增加科研通过或物理费用。
