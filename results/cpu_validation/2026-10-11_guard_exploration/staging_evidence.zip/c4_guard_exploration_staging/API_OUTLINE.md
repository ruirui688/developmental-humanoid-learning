# C 最小 runner / 独立 audit 接口

实现文件 `guard_exploration_development.py`；未来提升至
`src/developmental_physics/guard_exploration_development.py`。正式 flag False。
协议未来 `docs/GUARD_EXPLORATION_DEVELOPMENT_PROTOCOL.md`；独立 auditor
`scripts/audit_guard_exploration_development.py`，不由runner判科学门。

- `exploration_command(kind, active, directions, native_q, native_v, qref)`：
  返回 planned[8]、requested[8]、exploration_diagnostics；kind仅两cal与
  prediction。diagnostics 固定schema/rule/active_index/block_index/slot_index/
  amplitude_nm/shape/native_q_rad/native_v_rad_s/qref_rad/planned_nm[2]/
  requested_nm[2]/planned_nonzero[2]/velocity_veto[2]/position_veto[2]/
  command_vetoed[2]/velocity_threshold_rad_s/position_threshold_rad/comparison/
  physical_queries=0/future_actual_input=False/learned_gate=False。
- `run_trial(seed_result, models, episode, writer, pd)`：统一fresh prefix；
  两cal各独立cold，pred评分全部available，五控制按自身依赖。models只放
  已冻结nominal与成功learned，不放失败部分模型。返回/写失败原件遵循B。
- `run_guard_exploration_development(output, *, protocol_path, synthetic=False,
  synthetic_source_bytes=None, synthetic_pd_binding=None)`：24计划和checkpoint。
  synthetic必须显式替换environment、供人工source和PD，没有Git/真实来源fallback。

kind固定 `calibration_sparse/calibration_continuation/prediction/nominal_guard/
learned_sparse/learned_continuation/PDselected/zero`。phase固定
`prefix/calibration/prediction/control`，所有共同 native物理row在一个gzip。

row沿A/B：trial_id/seed/kind/shared_transition_id/step_index/phase/joint_indices/
observation_before/after/requested_torque/target_q/raw_pd_torque_nm/diagnostics/
qpos/qvel/study_abort/planner_decision/model_input_diagnostics/predicted_next_qv/
partial_interval_target_error_rad；新增planned_torque/exploration_diagnostics。
cal row `model_update` 是该组单模型原子dict，`model_snapshot_after` 为当前
publish（prefix None）；prediction row `available_models` 是固定排序，只有
available模型和persistence预测，参数fingerprints明确保存。控制无exploration。
异常row沿B failure_accounting/returned_step_diagnostics/diagnostic_prediction_accounting/
rls_prediction_accounting/model_snapshot_after/frozen_model_snapshot。

seed_result：seed/reset_seed、reference_trial_id/reference_q/native_prefix_velocity/
direction/selection_records/public_joint_ranges/environment_fingerprint_before/
native_prefix_observation；`fresh_prefix_bindings[kind]`保存全部fresh绑定；
`nominal_model`、`learned_models[learned_sparse/learned_continuation]`、
`calibrations[sparse/continuation]`保存initial_model/model_snapshot/frozen_model/
attempted_vector_updates/committed_vector_updates/committed_scalar_updates/
rls_prediction_accounting/completed/status/reason；`evaluations[kind]`沿B metric、
effort、planning/diagnostic账。`evaluations[prediction]`另含available_models及
明确availability映射。cal/predupdate原RMSE只诊断、不另predict。

episode沿B phase_budgets、status/completed/stop、paid attempted/control/physics、
returned/written/unreturned、risk completeness和plant fingerprints。控制evaluation
保留B models_before/after/model_fingerprint_before/after、planner_spec、model_updates0。
PD/zero不调用身体predict。cal剂量另存完整区间planned/final/start-G绝对及平方、
非零start-G条数/veto数，actual由合法substep_history积分，缺失actual保留下界。

最低激励资格、严格20%探索门加1.05努力、5%PD门均在协议预冻结；auditor
独立从trace重算，runner只保存材料。
