# C4 C 最小探索对照交付

仅本 ignored 目录实现，未修改 tracked/Core/旧archives，未执行实际 Git、
MuJoCo 构造/积分、真实 A/B/PD 原档读取。正式开关仍 False。root 负责审阅、
提升、冻结、提交推送和正式执行；本交付只提供准备材料，不是科学结果。

## 提升映射

- `guard_exploration_development.py` → `src/developmental_physics/guard_exploration_development.py`
- `GUARD_EXPLORATION_DEVELOPMENT_PROTOCOL.md` → `docs/GUARD_EXPLORATION_DEVELOPMENT_PROTOCOL.md`
- `test_guard_exploration_development.py` → `tests/test_guard_exploration_development.py`
- 独立审计来自另一个任务的 `external/c4_guard_exploration_audit_staging/`；
  本任务没有改写或运行 auditor。其正式位置为
  `scripts/audit_guard_exploration_development.py`。

测试优先加载正式 src runner，否则加载本目录草稿；提升后普通回归不依赖
ignored 文件。永久工程原档 case 仅在显式设置专用环境变量时执行；正式
source/PD fixtures 由 root 提供，不能用单元测试人工 PD 代替正式身份绑定。

## 已固定的实现

两个独立 fresh cold coupled9 校准：sparse 1/9，continuation 2/8+当前原生
q/v逐轴veto。每校准100prefix+400active，原双head原子RLS。单组失败只阻塞
自己的learning控制；另一校准、可用集合共同prediction和独立基线继续。
共同prediction100prefix+100active，continuation/veto，所有可用frozen先
predict再step，persistence另评分，零fit。五控制各100prefix+200active，
三原FixedPairMPC、原选定PD和zero，控制不veto，不减权限或改停止/任务。

模型输入只有原生q/v、最终已知请求和公开范围的start-G，计划请求/veto/
未来实际力矩均不加入9维features。校准报告复用update返回的preupdate预测，
不添加预测调用。完整terminal可update/score但不publish或completed；partial
不更新、不混RMSE。付费未返回、返回未写、原子失败/提交后中断、未知planner
费用和actual未知下界分别保留。IO/中断/trace失败fatal，不补跑。

科学门已在协议记录root严格规则：各学习组自身.8nominal/各axis与joint均值
20%；探索.8sparse/逐seed严格tracking/各axis与joint均值20%/实际joint努力
1.05；PD5%/1.05。每axis校准非零start-G且actual>0、共同prediction非零
start-G为事前资格；不加rank。runner不计算科研门，synthetic永不validate。

## 测试与失败保留

`attempt_01`：14passed/15failed，根因是人工FakeEnv误把XML的default无range
joint当实体；失败/source/stdout/cost和零动作原档保留。环境构造失败发生在
任何动作/数学之前：fakecalls、physics、prediction、RLS、Git和真实raw全部0。
只修人工夹具过滤八个命名joint，runner/protocol/Core均未变。

`attempt_02`：29passed，37.83s。包含精确脉冲与等号逐轴veto、自然零slot、
24完整FakePlanner矩阵、单/双cal失败依赖、partial与完整terminal、控制原权限、
真实原MPC候选计数、原子head1失败、提交后中断、付费未返回、写失败后保留
预测、原生getter/actual未知及prefix一致性。FakePlanner每次只实际predict一次
并计1，不声称81×15。未重跑既有数学Core完整测试。

整轮实际合成计账：30421fake calls/304196fake substeps；9205 vector update
尝试，9204原子publish/18408 scalar；34169pair/68338scalar预测；10次原MPC，
4801次FakePlanner。真实物理/Git/真实A/B/PD读取全部0。

## 一次固定工程假原档

路径：`attempt_02/engineering/fixture/raw`；当前C auditor原字节冻结SHA
`232f54f82e93da015fdd2c4377013d366eae92369165d74d1d23006e47b14224`，
四份独立数学support和当前源码/公开asset/协议同ZIP。XML degree→rad精确公开
范围，人工PD candidate2 Kp64/64、Kd0/4；没有PD真实五来源读取。

24预定计划中15完整、九MPC在首active v==1合法研究停止。6309fake calls/
63090fake substeps、2400vector/4800scalar RLS；14244pair/28488scalar实际
数学预测=2400RLS内部+900共同prediction+9控制诊断+10935MPC；9原MPC，
0FakePlanner。此成本是整test成本的子集，不重复相加。原档无二次collect。

独立审计任务已报告：首次5400项schema失败，来自auditor预期shape的int/
float类型；只修auditor两处shape期望为float，保留首次结果并只读同原件，
复核2704019项检查、0失败，6309/63090/4800scalar精确一致；validated全部
False。最终auditor SHA
`962a928b5d643ed2a3d4da20da2940a9a4e17932818c859beb204f11bf59ffa3`；
工程原ZIP仍保留首次冻结的232f字节，没有改档或二次collect。审计细节与
9项独立人工tests由另一任务的DELIVERY/INTEGRITY记录，root负责统一采用。

`INTEGRITY.json`记录最终交付字节及各attempt原档manifest、源码/结果身份。
protected coupled core保持原SHA
`7f234760e8f3d5b9cc799c871e84e7adfebecdf92e11f315735fad8b38ad78ed`。
