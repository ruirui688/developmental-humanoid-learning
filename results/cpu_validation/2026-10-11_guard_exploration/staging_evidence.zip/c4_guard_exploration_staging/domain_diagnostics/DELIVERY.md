# C 保存域只读诊断交付

只写本 ignored 子目录；原C六文件、首audit、summary和生产源码均未修改。
4项人工最小schema检查通过，0原C数据读取/模型/物理/Git费用；未跑大矩阵。
root确认首audit后，一次工具读取成功，输出在 `actual_C_readonly_01/`。

工具仅标准库，原六文件hash逐项匹配首audit archive.input_hashes，并绑定
commit5ea8df42b09588845760daf0dc1f270aef2a87f1与auditor962a...；不导入模型、
拟合、新predict、MPC、audit重放或Git，不重算科学门、不排名截短控制。
未来native端点仅作离线诊断标签。

读取8文件共11,473,237bytes，解析7230原行；wall1.6266416s/CPU1.625s，
新增物理/模型/预测/RLS/MPC/审计重放/科学门/Git全部0。此前为接口适配做
少量schema只读：初次summary目录误带first，FileNotFoundError保留于工具
聊天输出；定位正确summary路径后确认schema。预备读取不计入这一次工具
wall/CPU，无物理、模型或原档改变。

两cal每seed400完整原生起点，JSON报告q−qref/v/request/start-G范围及原保存
九feature列的范围、精确unique/恒定性；除设计bias以外的列均非恒定。
G1仅非负（sparse15/400、continuation29/400非零；seed0），没有rank/
Gram计算，不能用列非恒定断言可辨识。

seed0 sparse q−qref肩[-.00708486,.00115094]、肘[-.00311894,.0141041]rad；
continuation肩[-.0123909,.00147965]、肘[-.00394922,.0240439]rad。速度范围
sparse肩[-.302167,.212726]、肘[-.430539,.615813]；continuation肩[-.348071,
.298767]、肘[-.570199,.666024]rad/s。其余两seed完整保留，趋势一致。

只对保存选中H15作本组cal边界比较：sparse原起点97.2%、选中首步98.1%、
整个H15约99.7–99.8%域外；continuation50%/50%/91.7–93.3%。所选预测轨迹
域外主要为q（这些记录的保存预测v均落在cal速度范围）；箱内不证明充分
识别或预测准确。seed0 continuation第一步起点/预测都在箱内，肘预测/实测
仍为.298/.472，后续.523/.817、.574/.988、.528/1.170；因此不能把失败
单独归因于域外或连续长度。

联合any非零请求与实际力矩最长分别20ms sparse calibration、40ms
continuation calibration，对控制sparse2.12s、continuation80ms。JSON分开
per-axis/joint_any/joint_both，known按控制调用、actual按保存2ms子步；
零/未知/断档结束run。时间结构差仍在，但只是诊断，不分离因果。

330条保存控制端点：sparse3×106=318、continuation3×4=12。每条都有原生
pre-step q/v、已知u/start-G、保存next prediction、实测、选中H15 q/v。
sparse观察到目标切换后6条（100–105），continuation切换窗口未观测；
停止原因、末步误差和各固定切换窗口明确报告，不拿短序列RMSE排名。

原文件SHA完整在diagnostics.json，输出与工具SHA在manifest.json。
diagnostics.json SHA7e6591d421490226414a981c0abc89245b21b075a9186a2d9f30728ce9c4ade3；
DIAGNOSTICS.md SHA42640d83f01e1f9b6848e2a1f364aca43ef5b4a2f096f886aab5c8de0be0f4f1；
工具SHA64124c6729b9794eae5b6ab7f15ee94f02628f4411bf4993bf784eed9818558a。

工具和结果均保持本次exclusive原件；此交付不推荐或采用下一模型候选。
