"""Four artificial schema checks; zero C archive/model/physics/Git access."""
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("saved_domain_tool", HERE/"diagnose_saved_domain.py")
tool = importlib.util.module_from_spec(spec); spec.loader.exec_module(tool)

runs = tool.Runs("fixture", .02)
for index, value in enumerate(((1., 0.), (1., 1.), (0., 0.), (0., 1.), (0., 1.))):
    runs.observe(index, value)
record = runs.report()["run_length_distributions"]
assert record["joint_any"]["histogram"] == {2: 2}
assert record["joint_both"]["histogram"] == {1: 1}

runs = tool.Runs("fixture", .002)
runs.observe(0, (1., 1.)); runs.observe(2, (1., 1.)); runs.observe(3, None); runs.observe(4, (1., 1.))
record = runs.report()
assert record["run_length_distributions"]["joint_any"]["histogram"] == {1: 3}
assert record["gap_boundaries"] == 1 and record["unknown_samples"] == 1

cal = tool.new_calibration()
for axis in cal["native_start_axes"]:
    for value in (-.1, .1): axis["q_minus_qref_rad"].add(value)
    for value in (-.5, .5): axis["velocity_rad_s"].add(value)
record = tool.outside([([-.1, .1], [-.5, .5]), ([.11, 0.], [0., .6])], (0., 0.), tool.bounds(cal))
assert record["outside_any_q_or_v_fraction"] == .5
assert record["per_axis"][0]["q_outside_count"] == 1 and record["per_axis"][1]["v_outside_count"] == 1

record = tool.errors([])
assert record["complete_endpoint_count"] == 0 and record["target_error_rmse_joint_rad"] is None

output = HERE/"selfcheck_01.json"
if output.exists(): raise FileExistsError(output)
output.write_text(json.dumps({"passed_checks":4,"artificial_scalar_operations_only":True,
    "real_C_archive_reads":0,"physical_calls":0,"model_imports":0,"model_predictions":0,
    "RLS_updates":0,"MPC_selects":0,"audit_replays":0,"scientific_gate_recomputations":0,"git_calls":0},indent=2)+"\n",encoding="utf-8")
print("4 artificial schema checks passed; all model/physics/archive costs zero")
