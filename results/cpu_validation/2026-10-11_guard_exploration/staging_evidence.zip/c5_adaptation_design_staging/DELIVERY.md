# C5 科学适应设计交付

- 主文档：`C5_ADAPTATION_PROSPECTIVE_PROTOCOL.md`，工程草稿，无真实执行入口。
- 限定读取：现有C5工程协议/结果、perturbed_environment源和C当前探索协议；未读取C未知真实数据。
- 唯一矩阵：3 development seed ×3条件(identity/gain_half/armature_double) ×3 actor(frozen MPC/online MPC/selected PD)，另3份共同新校准。
- 事件表只在evaluator；模型初始化完整克隆，在线连续更新，不收到事件重置信号；权限、任务与物理机会相同。
- 上限9600控制/96000子步，6000 scalar RLS，MPC4374000 pair预测，其他预测和失败成本分别计账。
- C continuation贡献门未validated前不执行科学物理；预测、控制、真实努力、失败和恢复分别验收，不能只凭预测改善声称算法完成。
- 本次仅文档准备；未执行测试/模型/物理/Git，也未改tracked文件。root负责提升、正式冻结、执行与提交推送。
