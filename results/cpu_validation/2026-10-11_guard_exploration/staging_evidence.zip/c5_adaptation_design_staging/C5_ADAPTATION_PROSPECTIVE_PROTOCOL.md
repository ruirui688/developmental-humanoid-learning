# C5 科学适应：有限、隐藏时刻的身体模型对照

**工程草稿，尚未冻结、未实现、未运行。** 本轮只准备协议。C5 零学习工程结果已验证包装器事件；这不代表适应收益。C 当前独立科学门尚未在本设计中读取或判定，C 的 `learned_continuation` 自身贡献门未通过时，本矩阵全部科学物理保持 blocked，不以 C5 变化救援 C 的结论。

唯一问题：已有局部肩—肘控制起点下，利用控制期间原生反馈的在线身体模型更新，能否比同初始化冻结模型更快适应隐藏的输入增益或 armature 变化？这是 warm-start 适应，不是从零技能获得，也不评价 PPO、成熟门控、行走、真机或安全。

## 1. 依赖和唯一候选

固定依赖是 `docs/C5_ENGINEERING_PROTOCOL.md`、`docs/C5_ENGINEERING_RESULTS.md`、`src/developmental_physics/perturbed_environment.py` 与 C 当前 `GUARD_EXPLORATION_DEVELOPMENT_PROTOCOL.md`。本设计只读取这些协议/工程结果/包装器，不读取真实 C 原始数据。C 的模型、MPC、continuation 校准规则和已选 PD 身份由 root 提升后的精确提交及哈希绑定；本草稿不会从观察到的 C5 结果选参数。

启动前必须同时满足：C 在其原 .04/.08 完整任务中的 continuation 自身贡献门真实 validated；C5 工程 complete/identity/event/成本门通过；本协议、runner、独立标准库 auditor 和必要源码绑定从 clean commit 冻结；actor 信息边界、克隆、因果更新、事件与失败账在合成 fixture 中检查。缺任何一项不启动真实 factory。若 C 未通过，保留此准备工件，并先查 C 机制失败。C 对强 selected PD 的原比较结果（包括负结果）保持公开；C5 不替换或删除该结论。

模型沿用 C 的 `GuardCoupledPairBodyModel`，9 维 features、cold prior、P=100I9、lambda=1、hinge=.25、Euler=.02、原子双 head 发布不变。MPC 沿用 H15、81 个常向量候选、原成本、约束、tie/fallback。PD 使用 C 已绑定的原 selected PD，冻结原 gain，不再搜索或按条件调参。这里不增加遗忘因子、额外探索、事件检测器、模型重置或控制权限退级。

## 2. 共同环境、任务与信息边界

仅 supine、baseline 接触、原生肩 j0/肘 j1，其余六轴请求零；development seed 0/1/2 对应 reset seed 3757552657/1641411168/2001025171。公开 ±.5 N m、20 ms 控制周期、10×2 ms 子步、原 .03 rad 角度 guard 和所有环境保护保持。每 fresh trial 自付 100 次零输入前缀。首份完整前缀确定 qref、方向和范围；其后前缀必须精确一致，不裁剪 qref、不隐藏额外复位、不插入等待。

每控制 trial 固定 200 active，目标始终是 `qref+s*.04 rad`，不同时改变目标。这是隐藏动力学适应的局部机制任务，不是 C 的 .04/.08 完整任务，也不是新技能获得；固定小目标不能用来替代 C 依赖门。终点任一轴 `abs(q-qref)>=.12` 或 `abs(v)>=1` 时原 StudyAbort 生效，等号触发；prefix 只用环境保护。该小幅目标、公开方向、底层 guard、模型结构和先前校准都是已披露的先验。

actor 可获得原生 joint position/velocity/actuator torque/previous command、IMU，以及共同公开目标、范围与固定控制器参数。模型仍只使用 C 声明的 native q/v、已知最终公开请求与 start/predicted-q guard；不添加隐藏缩放、接触、质量矩阵、子步平均力矩或未来感觉作为 features。previous_command 表示公开 clip 后请求；native actuator torque 表示过去作用结果，可观察但本候选不新增相关 feature。

evaluator 独立持有 condition、reset seed、事件表及隐藏参数；actor 不接收这些值、变化标志、plant fingerprint 或 privileged diagnostics。actor 可有普通调用计数，但不能访问事件表，也没有按事件清空 P/重建模型的逻辑。各 trial 新 actor，无跨条件记忆。事件后的原生感觉可重新采样；不能据此禁止自然反馈推断变化。

## 3. 同初始化、同物理预算的矩阵

每 seed 首先在 fresh nominal wrapper 上仅执行一次新的共同 continuation 校准：100 prefix +400 active，完全沿用 C 的 20-block 2/8 脉冲与逐轴 native veto；公共阈值 abs(v)>=.5 或 abs(q-qref)>=.06 不改。400 次完整 vector update 后封存 theta、P、count、全部模型状态及 hash。该新校准的数据一致性/完整性/最低激励门必须独立核验；它与已有 C 完整贡献门是两个前置条件，不能互相替代。它是本矩阵新付费校准，不能读取或重放 C 的标签替代。

随后按 condition `identity / gain_half / armature_double`，每条件按 `frozen_MPC / online_MPC / PDselected` 顺序 fresh 执行。共三 seed、27 控制 trial，加三共同校准，共 **30 fresh trial**。每个 learned actor 从同 seed 校准封存件独立克隆完整 theta/P/count及其他状态；不只克隆系数。模型不得在 seed、condition 或 actor 间连续继承。控制期新增 updates 按该 trial 开始与结束计数器差记账，不能把每份继承的400次校准再次计为新更新。

frozen_MPC 在整个控制期不更新。online_MPC 在每个完整返回端点之后才原子更新一次，包括事件前，lambda=1 不变；没有额外请求、等待或复位。两者都获得相同计划的 100 prefix+200 active 机会，控制时的零动作、失败与恢复均收费。PD 不读身体模型用于动作，也没有更新，权限、任务、前缀、事件与停止完全相同。

物理实验账只计一次共同校准；方法预算表中冻结与在线各承担完整共同校准成本，不能把已取得模型称为免费。在线额外参数计算与 paired shadow 数学分别单列。identity 条件中在线相对冻结的正常跟踪、真实努力与计算差也是代价指标，单列公开。不同 actor 轨迹不同，因此其各自 on-policy 预测误差仅描述；第 5 节另提供同输入 paired 预测以检验更新机制。

## 4. evaluator-only 边界事件

事件发生在本 trial 完成 active 80/100/120 后、下一 active 请求之前，分别对应 development seed 0/1/2；同 seed 的所有 condition/actor 使用同边界。最迟事件仍留 80 次后续 active。事件表在运行前固定，不按行为或失败更换时刻；actor 实现不导入此表。条件名和 seed 不传入 actor。

| condition | evaluator 在边界执行 | 初始参数 |
|---|---|---|
| identity | 同包装器执行 gains 全1的 sham事件 | gains 全1，资产 armature |
| gain_half | j0/j1 hidden channel gains 改为 .5，其余1 | gains 全1，资产 armature |
| armature_double | native lookup 将 j0/j1 armature 从 .01 改为 .02 | gains 全1，资产 armature |

复用工程事件语义：事件不积分、不重置、不插入等待；q/v/time/counter/公开 previous command 和 held ctrl 不变，hidden gain 从下一请求生效。armature 的 live mj_forward 是非积分操作，派生 native sensor 可变。完整 before/after 与实际子步仪器仅交 evaluator/auditor；质量矩阵 scratch 诊断如保留则只做同 q 核验，不进 actor、不计物理调用，计算另列。发生普通停止而未到事件，记录 event_unreached，不补跑。

## 5. 事前窗口、因果预测与恢复

所有窗口以 evaluator 的事件边界 E 对齐，索引为下一步请求：pre 为 `[E-40,E)`，early 为 `[E,E+20)`，late 为 `[E+60,E+80)`，post_common 为 `[E,E+80)`。两变化和 identity 完全相同。还保存全部 200 active，不能用较短存活段代替窗口。

每个 learned trial，在物理请求前保存本 actor 当前模型对选定请求的 one-step q/v 预测。online trial 同时用其**未变化的初始模型 shadow** 对相同 native state/最终请求做一份预测；shadow 永不更新且不控制动作。这对预测共用同一真实端点，作为更新收益的主比较。PD trial 可用冻结初始模型记录同类诊断，绝不反馈给 PD。前缀不预测/更新。

online 端点回传后原模型 update 的内置 preupdate prediction 仍保存并计费，独立 auditor 核对它与前请求预测一致；不把这次计算伪装成零成本，也不增加另一份报告 replay。所有 forecast 的 theta/P版本、state、公开最终请求、start-G和时间关系可复核。未来端点只作标签，终端完整区间可记录/update但 trial 不完整；partial 不更新、不进入完整窗口分数。

报告每轴与 joint 的 velocity RMSE、one-step position RMSE、目标 tracking RMSE、真实请求和 actual torque 的绝对/平方积分、veto/guard剂量、stop、异常及 unknown kernel attempt。one-step position 为辅助，不声称其独立于 velocity；MPC 常向量 H15预测不能与未来改变动作的真实轨迹混算成 H15监督分数。

恢复定义事前固定：事件后首个连续10个完整端点都满足两轴 `abs(q-target)<=.025 rad` 且 `abs(v)<=.25 rad/s` 的窗口，恢复成本计到第10个端点，包括其所有真实调用、子步和 actual effort。若事件时已满足，仍需这10步确认，另标 already_in_envelope；没有性能扰动时只称“事件后保持/进入包络”，不宣称从失败恢复。仅在 post_common 的80请求机会内判定；未达到为右删失，停止另标 failure，预算不足/异常为 unavailable，不填无限值参与普通均值。

## 6. 最小科学验收，先完整后排名

独立 auditor 分开给出数据一致性、matrix_complete 和科学门；synthetic 不可 validated。所有必要三 seed校准、相关控制 trial和完整窗口可用，且 unknown=0，才进入对应比较。校准/在线每轴至少一条非零 start-G且 actual绝对努力>0，才具最低输入资格；这不证明充分激励或可辨识。

1. **更新机制门**：gain_half 和 armature_double 分别在 online 实际轨迹的 late 窗口检验。每 seed每轴 paired velocity RMSE严格低于 frozen shadow；三 seed每轴及 joint均值各至少改善20%。分母为0时不能证明改善；零/零只报告相同。必须保存 pre/early、identity与全部不利指标，不能挑变化或轴。
2. **控制适应门**：两类变化分别要求 post_common 每 seed各轴及 joint tracking不劣于 frozen_MPC，三 seed各轴/joint均值各改善>=10%；post_common joint actual绝对/平方努力均值分别<=1.05 frozen。事件前及identity 的 online三seed各轴/joint tracking均值<=1.05 frozen，防止用共同条件损害换取变化收益。预测门通过但控制门未通过时，仅保留身体预测证据。
3. **恢复报告**：逐 seed报告80步内成功/右删失/失败、确认调用和实际努力；只有两组同必要窗口完整才比较成本。若 frozen本已保持包络，不把online较快10步确认称为新恢复能力。恢复不给模型门缺失时作替代证据。
4. **PD对照门**：先 online 自身更新和控制适应门通过。两变化中 each seed各轴/joint post_common tracking不劣于 selected PD，三seedjoint均值改善>=5%，joint actual绝对/平方努力均值各<=1.05 PD。PD对照未通过不能声称比经典控制更好；identity/事件前同样公开。

本轮最低有效结论是“一次事前冻结的两变化适应对照得到完整、可审计结果”。初步算法适应验证还需同时通过前两门；若失败则明确失败，不追加seed/时间/forgetting或降低停止阈值救门。停止的truncated RMSE不排名；降低增益造成较低实际努力不归因于算法。

## 7. 有限成本、失败依赖与交付

完整上限：共同校准3×500=1500 calls，控制27×300=8100 calls，共 **9600 calls /96000子步**。vector RLS为校准1200+在线1800=3000，scalar=6000；其内置preupdate为3000 pair/6000 scalar预测。显式one-step为 frozen actor1800、online actor1800、online frozen shadow1800、PD诊断1800，共7200 pair/14400 scalar；合计10200 pair/20400 scalar（不含MPC）。MPC上限18×200×81×15=4374000 pair/8748000 scalar。事件/克隆/校验无新积分，壁钟CPU另列，GPU=None、策略更新/教师调用=0。

共同校准停止或数学失败时，该seed冻结/在线控制blocked，PD按原计划仍可执行；不得用prior假装校准模型或用其他seed模型替代。控制普通停止/模型原子失败保留本trial，后续独立fresh计划继续，比较门不通过。资产/事件/仪器/非有限native观测/IO/中断等为fatal，后续blocked，不重试、不回滚事件、不补采。计账沿用C5工程 independent-returned原kernel、partial、unknown与已知下界规则，不以trace行数替代费用。

首轮排他保存配置、source commit/ZIP/hash、依赖、原生before/after、完整子步actual、事件、请求/guard、模型版本/更新、预测、前缀和克隆身份、逐seed窗口与恢复事实、失败/blocked与真实费用。首次独立audit负责重算窗口/努力/门，独立once-summary只描述；归档不能重新运行物理、更新、预测或audit。共同校准、前缀、失败及事件后全部交互加入持续账本；此前C和C5工程成本保持独立可追溯。

## 8. 本次准备的边界

本文件是单一 bounded 候选，不包含执行结果。没有读取未知 C 证据、没有新物理、模型调用、RLS、测试或Git。本草稿待root确认依赖满足后提升与冻结；任何执行前修订留下独立版本，执行后不重写本轮门。若当前模型lambda=1不能适应，先把失败作为这一候选的证据；后续改变遗忘、激励或模型属于新协议和新预算。
