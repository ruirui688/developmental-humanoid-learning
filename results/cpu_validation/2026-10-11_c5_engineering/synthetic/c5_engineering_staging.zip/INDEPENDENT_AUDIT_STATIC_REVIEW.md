# C5 独立 audit 静态审读

仅阅读 `external/c5_audit_staging/audit_c5_engineering.py` 与已交付 runner。没有执行 audit、真实物理、拟合、Git 或新 runner 测试；没有修改 root auditor。以下结论是源码静态分析，不能当成审计结果。

## 需要先补的正确性边界

1. **setup/reset failure 的总账不能被 KeyError 截断。** Runner 在 reset 成功且计数为零之后才写 `initial_native_mapping`，因此 bad asset、bad reset、reset throw 和 fresh factory throw 可能没有该字段；env=None 时没有 `final_live_state`。当前 auditor 直接索引这两个字段会提前结束，`reconstructed=None`。建议先独立汇总四个 outcome 的非负整数成本，并从可用 live counters / returned partial facts重建下界；缺 mapping 的 setup failure 不做 guard/asset检查，仍保留该trial预算和其余blocked。重置异常 paid7 是合法已付费下界，不能变成0或忽略。

2. **qref 检查只适用于实际进入 active。** `len(rows)>=100` 不充分：环境在 prefix index99 停止时没有 boundary/qref；boundary event失败时 runner已取局部 reference，但 outcome最后持久化的 reference仍可能None。只在存在active row时要求 outcome reference=prefix row99 q[:2]；失败事件如有 `before_live.qpos`，另按mapping与prefix终点比对，不制造未执行active的qref。

3. **完整组严格核验独立事实与预算非负。** 当前只检查完整组returned=1200，不强制每rowrecord attempted=True/force_available=True，不检查 complete unknown=0。理论上将所有 attempted改False、unknown改负值且metadata总账一致，仍可能通过现有完整门。建议 complete必须 attempts=returned=known paid=known force=1200、unknown=0；每完整record attempted/returned/force_available都True，且报告的guard_actual_match/unit_motor_force_match与独立重算一致。所有预算 type=int（不接受bool）、≥0，unknown≤attempts；blocked成本与trace/partial必须全0。

4. **identity按runner定义核验完整actual history。** Runner比较 `observation_before/after、qpos/qvel、actual_substep_history`；auditor当前比较的history仅 `diagnostics.applied_torque_history`。独立比较runner原生fields及完整actual_substep_history，求完整所有numeric leaves的最大差、比较数、exact canonical serialization、共同rows和完整120标记；对metadata对应字段逐一比对。避免只核验两个bool而接受伪造max/exact/数量。

## 异常与trace去重

当前 partial 与最后一行 `step_index == failed_step` 时不重复extend，是正确方向：trace.write/flush失败时，同一末行可能已经进入gzip文件，但runner未append到内存 rows，outcome仍保存整条 partial instrumentation。独立审计应从磁盘可读末行与partial的record逐项匹配，只计一次；相同步号但history不同应违反一致性，不能任择一方。若末行没写入，直接计partial。事件失败phase=event不调用step，partial常空且failed_request None；不能凭step_index100多算一次active。

partial需要支持三种事实：pre读取失败（attemptedFalse/returnedFalse，可能缺angle/ctrl），原kernel未返回（attemptedTrue/returnedFalse，未知额外积分）、kernel返回但force读取失败（returnedTrue/force_availableFalse，envcounter尚未+1）。已正常返回kernel是可计费的确定下界，力矩努力只计known force；未知attempt不是0积分。不要要求所有失败partial都有after_force字段。对可用字段单独重算guard/scaling和报告flags；预期故障导致的guard/force不匹配是工程失效，要保留，而不是导致整个预算重建停止。

如果trace gzip/末行损坏，当前读trace的一个异常会结束全部审计。建议标记 trace不完整，逐行保留此前可读rows，继续用outcome partial/final counters建立明确下界；完整engineering_pass必须False。无法从损坏trace恢复完整历史不等于预算0。

## 来源与参数协议

`verify_sources` 应独立检查 binding schema_version=1、plan精确匹配完整事前PLAN、binding path固定、source列表排除自身hash；metadata.fixed_plan与binding.plan同时核对。当前部分顶层fields有检查，但binding.plan/schema、metadata.fixed_plan没有。继续使用Git show runtime记录commit核验ZIP原字节是合理的，不能用当前未来HEAD替换当时来源。

asset固定ID/qpos/dof硬编码在当前自建资产上可以成立，但它是资产-specific检查；若synthetic fixture使用runner的shuffled lookup，应依fixture模型明确处理，不能把fake失败解释成真实mapping失败。建议从已验证asset bytes的关节名称/树顺序解释固定表，至少记录为什么canonical real IDs1..8/qpos7..14/DOF6..13。对新字段 motor_ctrlrange_nm、motor_ctrl_limited、motor_force_limited应核对 .5/true/false，不只信任unit_gain_gear_bias_verified bool。

质量矩阵 before/after的元素差重算已覆盖。补查矩阵外层n×n、所有qpos有限、report.expected_selected_diagonal_delta/tolerance/diagnostic_only及scratch scope/0 integrated step，参数事件status与kind对应，prefix完全后boundary100、live step_id100/physics_steps1000/time2s，fresh trial参数复原。armature原事件中允许derivedforce/sensordata改变，q/v/ctrl/time/counters/lastcommand必须保持。base/wrapper/gain的完整armature不变。

## 原生endpoint与最终工件

完整返回row的 observation_after.previous_command应等于公开接受请求（.25<.5无需额外clip差异），不能只检查连续性；actuator_torque可与末个已知unit-force核对。trace.phase应按index为prefix或active。ordinary stop后不能有下一row；study triggers还需比较values/reference/step_index/active_step_index/thresholds，不只比较trigger(axis,signal)。

`control_calls_attempted/control_steps/returned_endpoints` 当前只从outcome相加，未独立验证来源；至少检查calls≤120，steps与final live step_id一致，returned endpoints≤calls，persisted rows≤returned endpoints，并结合failed phase/request/index检查一次缺失row的合法情况。trace读损坏时只能给下界，不能硬补完整。后续若需严格区分native endpoint通过但写盘失败与native endpoint未通过，可新增明确采集事实字段；本轮不为审计补造原件。

最终 all_four_complete还应要求fatal None、artifact_failures为空、完整manifest以及无storage_failure_record。Runner在manifest写盘失败后可能已有此前 `metadata_final.json`，但stdout/新 `storage_failure_record.json`明确失败；原件不能改写成成功。auditor宜读取存在的storage_failure_record并强制engineering_pass False，保留确切费用。CLI当前以failed count作为exit，partial完整性不足但一致性0failure可能返回0；建议返回 `not engineering_pass`，并保持report区分“账目一致”与“工程门完成”。

建议root按优先项做最小修复，再用独立pure fixture检查完整/partial/setup/write-overlap/unknown与post-force几类，不运行真实物理来补这些工程细节。本审读没有重跑任何实验。
