# C5 工程 runner 草稿交付

只修改 ignored `external/c5_engineering_staging/`；没有真实环境构造、真实物理采样、拟合、audit/summary 运行或真实 Git 调用。tracked 提升、正式协议冻结、独立 audit、提交/推送和真实执行由 root 统一。

最新代码保持 **DRAFT=True**。real guard 在 optional imports/factory/output 前拒绝真实执行；草稿 binding 不能启用 real。正式 tracked source binding 必含七项，runtime clean HEAD/各 HEAD blob/hash 核验，binding 排除自身期望 hash且不 hardcode HEAD，运行时把实际 HEAD/binding hash记入metadata。独立 audit 源由 root 提供，草稿 binding 中该 hash 为 null，必须重生成正式 binding，不能直接改 draft=false使用。

## 最新可提升文件

| 草稿源 | 正式路径 | 最新 SHA256 |
|---|---|---|
| engineering_runner.py | src/developmental_physics/c5_engineering.py | d3971fd2a00720d0c3924d3bd5457e05bbdf1f3f6b15653ca52ea8d9f65138ce |
| test_engineering_runner.py | tests/test_c5_engineering.py | f242119d8cc6952a44a9cce2594904327ba1a2d696466414f4f30d2072a294b0 |
| ENGINEERING_PROTOCOL_DRAFT.md | docs/C5_ENGINEERING_PROTOCOL.md | 3021caefd483a87c319c57e716a8e9660b3663bc1fe09512aa5211f1908d9a81 |
| C5_ENGINEERING_BINDING_DRAFT_REV03.json | 只供正式 binding 的结构参考 | 807626d23cd895a48edecdb439137aba3ab5841a53d268a024509100e4cc993b |

RealBackend 已实现，无 ignored sibling 依赖：freeze通过后才 lazy import MuJoCo/NumPy/两个正式 package 类，并核验实际 imported module 路径来自本 clone；base 使用 GroundBodyEnv，其余使用 PerturbedGroundBodyEnv。CLI 已实现：`python -m developmental_physics.c5_engineering --project-root <root> --output <new>`。只有四组完整与完整 identity 通过、无 fatal 才返回 0。普通停止终止本trial并继续fresh下一组，最后不声称完整验收成功。tests 在 tracked 路径直接 import 正式 package；draft-guard test 显式 monkeypatch True，提升 DRAFT=False 后也不会触发真实 Git。

四trial固定480calls/4800sub/0updates、100zero+20active、.25共同探针、seed/resetseed、100边界事件、.12/1 study阈值全部按root计划，不因合成结果改变。

## 合成验收原件

四个 exclusive attempt 全部保留 `executed_sources/`、stdout、attempt/execution 和完整 pytest_work synthetic数据，不覆盖。

| Attempt | pytest | wrapper wall s | 同Python process CPU s |
|---|---|---:|---:|
| synthetic_attempt_01 | 50 passed / 8.00 s | 8.2269691999536 | 6.453125 |
| synthetic_attempt_02 | 56 passed / 7.64 s | 7.879198900191113 | 6.4375 |
| synthetic_attempt_03 | 58 passed | 7.553474700078368 | 6.28125 |
| synthetic_attempt_04 | 58 passed | 8.064960499992594 | 6.578125 |

以上都 **0真实控制调用 / 0真实物理子步 / 0参数更新 / 0真实Git**。CPU计时包含pytest import，同进程，不用子进程 CPU 对父进程采样。

首轮50pass之后，read-only静态检查本机 MuJoCo 3.15.0 installed introspect声明发现真实 `mj_fullM(model,data,dst)` 与初版旧签名不同；已修复adapter及fake签名并另建attempt02。首轮通过不能当成真实API兼容或物理验证，旧attempt原件保留。`STATIC_API_REVIEW_02.json`保存已安装声明路径/hash，未调用真实API。最早 source-copy attempt00 由于缺少 parent目录而失败、没有执行测试或覆盖文件，记录在 revisions/pre_completion_01/pre_completion_00_failed.txt；后续排他目录正常创建。

## 覆盖的实质边界

- fresh4、固定480/4800完整行、base/wrapper完整identity精确/1e-12、全部numeric叶比较不短路；source ZIP及工件hash。
- 非identity原生joint/qpos/DOF lookup，motor unit gain/gear/bias、固定.5 ctrl权限、无额外force limiter、public guard×scaled request与实际unit force；六类finite原生observations拒绝hidden。
- boundary前后ctrl保持、独立非零held-ctrl事件语义、armature只改变lookup两个DOF；same-q scratch mj_forward/fullM的指定对角+.01、其他矩阵项保持；scratch不修改live或增加step。
- ordinary study/env stop后继续fresh；exact .12/1阈值，prefix无study；任何资产/事件/仪器/观测/存储异常fatal、剩余blocked、不补跑。
- 原kernel未返回记录unknown attempt；原kernel返回后force读取失败仍paid1，即使env counter0；API恢复、partial原件、坏reset已付费、trace/outcome/final存储失败保留成本与stdout。
- fixture binding只stub subprocess，拒绝dirty/source/HEAD bytes/hash/plan/draft/protocol/selfhash/逃逸source/实际runner路径污染；real freeze guard不能被fake标签绕过。

## root 后续职责

提升最新源码/测试、包装器和正式协议；完成 `scripts/audit_c5_engineering.py`；检查实际依赖与源映射、必要时修正源码文字；设置 DRAFT=False 后重算7个正式tracked字节hash，生成schema1/draftfalse binding（无自hash/commit环），完成检查并提交。正式入口再独立核验clean HEAD和binding，root执行一次固定真实工程采集，再独立audit。任何异常保留已付费与原始工件，不重复采集。工程通过只证明事件/仪器可用，不能称适应或学习优势。
