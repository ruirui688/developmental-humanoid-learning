"""Four hand-calculated in-memory cases; no real collection reads."""
from copy import deepcopy
import importlib.util
from pathlib import Path

import pytest

spec=importlib.util.spec_from_file_location('c5_summary',Path(__file__).with_name('summarize_c5_engineering.py'))
core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)


def fixture():
    outcomes=[];events=[]
    for kind in core.KINDS:
        req=[{'absolute_nm_s':.05 if i<2 else 0.,'squared_nm2_s':.0125 if i<2 else 0.} for i in range(8)]
        act=[{'absolute_nm_s':(.025 if kind=='gain_half' else .05) if i<2 else 0.,
              'squared_nm2_s':(.003125 if kind=='gain_half' else .0125) if i<2 else 0.} for i in range(8)]
        outcomes.append({'kind':kind,'status':'completed','control_calls_attempted':120,'control_steps':120,
            'known_physics_substeps_lower_bound':1200,'unknown_original_step_attempts':0,'returned_endpoints':120,
            'known_actual_force_substeps':1200,'known_requested_effort_by_joint':req,'known_actual_force_effort_by_joint':act})
        before={'qpos':[0.]*15,'qvel':[0.]*14,'ctrl':[0.]*8,'last_command':[0.]*8,'time':2.,'step_id':100,
            'physics_steps':1000,'armature':[.01]*14,'plant_fingerprint':'same','base_fingerprint':'same'}
        events.append({'kind':kind,'status':'not_applicable' if kind=='base_identity' else 'applied',
            'step_boundary':100,'before_live':before,'after_live':deepcopy(before),'mass_matrix_change':{'physics_substeps_added':0}})
    budget={key:sum(o[key] for o in outcomes) for key in core.BUDGET_KEYS};budget['model_parameter_updates']=0
    metadata={'actual_budget':budget,'outcome_counts':{'completed':4},'model_parameter_updates':0,
        'policy_updates':0,'teacher_calls':0,'all_four_complete':True,'identity_check':{'validated_identity':True},
        'source_binding':{'source_commit':'a'*40}}
    archive={'budget':deepcopy(budget),'outcome_counts':{'completed':4},'all_four_complete':True,
        'identity_rows_complete':True,'identity_match':True,
        'effort':{o['kind']:{'requested':deepcopy(o['known_requested_effort_by_joint']),
            'actual':deepcopy(o['known_actual_force_effort_by_joint'])} for o in outcomes}}
    audit={'archive':archive,'engineering_pass':True,'checks':10,'failed':0,'synthetic_fixture':False,
        'learning_or_adaptation_validated':False}
    return metadata,outcomes,events,audit


def test_complete_manual_budget_and_effort():
    result=core.build_summary(*fixture())
    assert result['summary_consistency']['failed']==0
    assert result['actual_budget']['control_calls_attempted']==480
    assert result['actual_budget']['known_physics_substeps_lower_bound']==4800
    totals=result['effort_totals_by_native_joint']
    assert totals['known_requested'][0]['absolute_nm_s']==pytest.approx(.2)
    assert totals['known_actual_force'][0]['absolute_nm_s']==pytest.approx(.175)
    assert totals['known_actual_force'][0]['squared_nm2_s']==pytest.approx(.040625)
    assert result['model_parameter_updates']==0 and result['learning_or_adaptation_validated'] is False


def test_unknown_original_attempt_partial_preserves_lower_bound():
    metadata,outcomes,_,audit=fixture()
    outcomes=[{'kind':kind,'status':'exception' if index==0 else 'blocked',
        'control_calls_attempted':1 if index==0 else 0,'control_steps':0,
        'known_physics_substeps_lower_bound':0,'unknown_original_step_attempts':1 if index==0 else 0,
        'returned_endpoints':0,'actual_budget_is_lower_bound':index==0} for index,kind in enumerate(core.KINDS)]
    budget={key:sum(o[key] for o in outcomes) for key in core.BUDGET_KEYS};budget['model_parameter_updates']=0
    counts={'exception':1,'blocked':3}
    metadata.update(actual_budget=budget,outcome_counts=counts,all_four_complete=False,identity_check={'validated_identity':False})
    audit['archive'].update(budget=budget,outcome_counts=counts,all_four_complete=False,identity_rows_complete=False,effort={})
    audit['engineering_pass']=False
    result=core.build_summary(metadata,outcomes,[],audit)
    assert result['summary_consistency']['failed']==0
    assert result['actual_budget']['unknown_original_step_attempts']==1
    assert result['actual_budget_is_lower_bound'] and not result['engineering_pass_from_independent_audit']


def test_wrong_recorded_total_is_visible():
    metadata,outcomes,events,audit=fixture();metadata['actual_budget']['known_physics_substeps_lower_bound']=4801
    result=core.build_summary(metadata,outcomes,events,audit)
    assert 'metadata_total_budget' in result['summary_consistency']['violations']
    assert result['engineering_report_consistent'] is False


def test_nonfinite_effort_rejected():
    metadata,outcomes,events,audit=fixture();outcomes[0]['known_actual_force_effort_by_joint'][0]['absolute_nm_s']=float('nan')
    with pytest.raises(ValueError,match='finite'): core.build_summary(metadata,outcomes,events,audit)
