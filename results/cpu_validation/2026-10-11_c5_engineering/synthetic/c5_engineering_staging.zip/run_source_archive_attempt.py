"""Exclusive stdlib source-audit fixture snapshot. Never imports collector/physics."""
import argparse
from contextlib import redirect_stderr,redirect_stdout
import hashlib
import json
from pathlib import Path
import sys
import time


def write_once(path,value):
    with path.open('x',encoding='utf-8') as stream:
        json.dump(value,stream,indent=2);stream.write('\n')


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--attempt',required=True)
    args=parser.parse_args();output=Path(args.attempt);output.mkdir(parents=True,exist_ok=False)
    source=output/'executed_sources';source.mkdir(exist_ok=False)
    pairs={'audit_c5_engineering.py':Path('scripts/audit_c5_engineering.py'),
        'test_audit_source_archive.py':Path(__file__).with_name('test_audit_source_archive.py'),
        'run_source_archive_attempt.py':Path(__file__)}
    hashes={}
    for name,path in pairs.items():
        value=path.read_bytes()
        with (source/name).open('xb') as stream: stream.write(value)
        hashes[name]=hashlib.sha256(value).hexdigest()
    write_once(output/'attempt.json',{'scope':'Source ZIP/binding helpers only; inert bytes, all Git stubbed',
        'source_sha256':hashes,'physical_calls':0,'parameter_updates':0,'real_git_calls':0,
        'collector_imports':0,'python':sys.version,'executable':sys.executable})
    wall,cpu=time.perf_counter(),time.process_time();failure=None
    with (output/'stdout.txt').open('x',encoding='utf-8') as stream,redirect_stdout(stream),redirect_stderr(stream):
        try:
            import pytest
            status=int(pytest.main(['-q',str(source/'test_audit_source_archive.py'),
                '--confcutdir',str(source),'--basetemp',str(output/'pytest_work')]))
        except BaseException as exc:
            import traceback
            traceback.print_exc();status=1;failure={'type':type(exc).__name__,'message':str(exc)}
    record={'exit_code':status,'failure':failure,'wall_seconds':time.perf_counter()-wall,
        'same_process_cpu_seconds_including_pytest_import':time.process_time()-cpu,
        'physical_calls':0,'parameter_updates':0,'real_git_calls':0,'collector_imports':0,
        'source_sha256':hashes,'stdout_sha256':hashlib.sha256((output/'stdout.txt').read_bytes()).hexdigest()}
    write_once(output/'execution.json',record);print(json.dumps(record));return status


if __name__=='__main__': raise SystemExit(main())
