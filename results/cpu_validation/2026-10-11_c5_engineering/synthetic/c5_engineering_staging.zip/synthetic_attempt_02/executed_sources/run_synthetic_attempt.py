"""Exclusive executed-source snapshot and same-process CPU/pytest record; no physics."""
import argparse
from contextlib import redirect_stderr,redirect_stdout
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import platform
import sys
import time


def json_once(path,value):
    with path.open('x',encoding='utf-8') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--attempt',required=True)
    args=parser.parse_args();attempt=Path(args.attempt)
    attempt.mkdir(parents=True,exist_ok=False)
    source=attempt/'executed_sources';source.mkdir(exist_ok=False)
    names=('engineering_runner.py','test_engineering_runner.py','ENGINEERING_PROTOCOL_DRAFT.md',
           'C5_ENGINEERING_BINDING_DRAFT.json','C5_ENGINEERING_BINDING_DRAFT_REV02.json',
           'STATIC_API_REVIEW_02.json','run_synthetic_attempt.py')
    original=Path(__file__).resolve().parent
    hashes={}
    for name in names:
        value=(original/name).read_bytes()
        with (source/name).open('xb') as stream: stream.write(value)
        hashes[name]=hashlib.sha256(value).hexdigest()
    json_once(attempt/'attempt.json',{'created_at_utc':datetime.now(timezone.utc).isoformat(),
        'scope':'Pure synthetic fixtures only: 0 real physics calls, 0 parameter fitting, 0 real Git calls',
        'physical_control_calls':0,'physical_substeps':0,'parameter_updates':0,
        'source_sha256':hashes,'python':sys.version,'executable':sys.executable,'platform':platform.platform()})
    sys.dont_write_bytecode=True
    wall,cpu=time.perf_counter(),time.process_time();exit_code=None;failure=None
    with (attempt/'stdout.txt').open('x',encoding='utf-8') as log,redirect_stdout(log),redirect_stderr(log):
        try:
            import pytest
            exit_code=int(pytest.main(['-q',str(source/'test_engineering_runner.py'),
                '--confcutdir',str(source),'--basetemp',str(attempt/'pytest_work')]))
        except BaseException as exc:
            import traceback
            traceback.print_exc();failure={'type':type(exc).__name__,'message':str(exc)};exit_code=1
    execution={'exit_code':exit_code,'failure':failure,'wall_seconds':time.perf_counter()-wall,
        'same_python_process_cpu_seconds_including_pytest_import':time.process_time()-cpu,
        'physical_control_calls':0,'physical_substeps':0,'parameter_updates':0,'real_git_calls':0,
        'stdout_sha256':hashlib.sha256((attempt/'stdout.txt').read_bytes()).hexdigest(),
        'executed_source_sha256':hashes}
    json_once(attempt/'execution.json',execution)
    print(json.dumps(execution,ensure_ascii=False));return exit_code


if __name__=='__main__': raise SystemExit(main())
