"""C5 draft channel/event accounting tests with no physical integration."""
import importlib.util
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest

pytest.importorskip("mujoco")
spec = importlib.util.spec_from_file_location("c5_env_draft", Path(__file__).with_name("perturbed_environment.py"))
core = importlib.util.module_from_spec(spec)
spec.loader.exec_module(core)


@pytest.fixture
def env(monkeypatch):
    instance = object.__new__(core.PerturbedGroundBodyEnv)
    instance._channel_gains = core._gains(np.ones(8))
    instance._reset_done, instance.terminated = True, False
    instance.action_limits = np.ones(8)*.5
    instance.last_command = np.zeros(8)
    instance.physics_steps, instance.step_id = 30, 3
    instance._joint_ids = np.arange(8)
    instance.model = SimpleNamespace(dof_armature=np.ones(14)*.01, jnt_dofadr=np.arange(8)+6)
    instance.data = SimpleNamespace(qpos=np.arange(15, dtype=float), qvel=np.arange(14, dtype=float), time=.06)
    monkeypatch.setattr(instance, "_stop_reason", lambda: None)
    monkeypatch.setattr(core.GroundBodyEnv, "parameter_fingerprint", lambda self: self.model.dof_armature.tobytes().hex())
    monkeypatch.setattr(core.mujoco, "mj_forward", lambda model, data: None)
    return instance


@pytest.mark.parametrize("gain", [1., .5])
def test_channel_scales_after_public_clip_preserves_native_previous_and_actual_history(env, monkeypatch, gain):
    original = np.array([2., -.4]+[0.]*6)
    gains = np.array([gain]*2+[1.]*6)
    env.set_channel_gains(gains)
    received = []
    def paid_backend(self, torque):
        received.append(torque.copy())
        self.last_command[:] = torque
        self.physics_steps += 10
        self.step_id += 1
        return SimpleNamespace(observation={"previous_command": torque.copy(), "actuator_torque": torque.copy()},
            diagnostics={"requested_torque": torque.tolist(), "accepted_torque": torque.tolist(),
                "executed_substeps": 10, "applied_torque_history": [torque.tolist()]*10})
    monkeypatch.setattr(core.GroundBodyEnv, "step", paid_backend)
    result = env.step(original)
    accepted = np.clip(original, -.5, .5)
    np.testing.assert_array_equal(received[0], accepted*gains)
    np.testing.assert_array_equal(result.observation["previous_command"], accepted)
    np.testing.assert_array_equal(result.observation["actuator_torque"], accepted*gains)
    assert result.diagnostics["requested_torque"] == original.tolist()
    assert result.diagnostics["accepted_torque"] == accepted.tolist()
    assert result.diagnostics["applied_torque_history"] == [(accepted*gains).tolist()]*10
    assert (env.physics_steps, env.step_id) == (40, 4)


def test_mid_step_interrupt_keeps_paid_counts_and_original_accepted_history(env, monkeypatch):
    env.set_channel_gains([.5]*8)
    def fail(self, torque):
        self.last_command[:] = torque
        self.physics_steps += 3
        raise KeyboardInterrupt()
    monkeypatch.setattr(core.GroundBodyEnv, "step", fail)
    with pytest.raises(KeyboardInterrupt):
        env.step(np.ones(8)*.4)
    assert env.physics_steps == 33 and env.step_id == 3
    np.testing.assert_array_equal(env.last_command, np.ones(8)*.4)


def test_preexisting_stop_does_not_forge_command_acceptance(env, monkeypatch):
    monkeypatch.setattr(env, "_stop_reason", lambda: "already unsafe")
    env.last_command[:] = .1
    monkeypatch.setattr(core.GroundBodyEnv, "step", lambda self, torque: SimpleNamespace(
        observation={"previous_command": self.last_command.copy()},
        diagnostics={"executed_substeps": 0, "applied_torque_history": []}))
    result = env.step(np.ones(8)*.4)
    np.testing.assert_array_equal(result.observation["previous_command"], np.ones(8)*.1)
    assert env.physics_steps == 30


@pytest.mark.parametrize("gains", [[.5]*7, [0.]*8, [1.1]*8, [float("nan")]*8])
def test_invalid_gain_proposal_cannot_change_published_parameters(env, gains):
    before = env.plant_fingerprint()
    with pytest.raises(ValueError):
        env.set_channel_gains(gains)
    assert env.plant_fingerprint() == before


def test_gain_fingerprint_tracks_wrapper_parameters_and_is_immutable(env):
    before = env.plant_fingerprint()
    env.set_channel_gains([.5]*8)
    assert env.plant_fingerprint() != before
    with pytest.raises(ValueError):
        env._channel_gains[0] = 1.


def test_armature_event_maps_native_dofs_without_reset_or_free_steps(env):
    before_q, before_v = env.data.qpos.copy(), env.data.qvel.copy()
    record = env.change_armature((0, 1), (.03, .04))
    assert record["status"] == "applied" and record["dof_indices"] == [6, 7]
    assert record["confirmed_physics_substeps_added"] == 0
    assert env.model.dof_armature[6:8].tolist() == [.03, .04]
    np.testing.assert_array_equal(env.data.qpos, before_q)
    np.testing.assert_array_equal(env.data.qvel, before_v)
    assert (env.physics_steps, env.step_id, env.data.time) == (30, 3, .06)


@pytest.mark.parametrize("mutation", ["qvel", "time", "interrupt"])
def test_armature_forward_failure_preserves_parameter_change_without_rollback(env, monkeypatch, mutation):
    def failed_forward(model, data):
        if mutation == "interrupt":
            raise KeyboardInterrupt()
        if mutation == "qvel": data.qvel[0] += 1.
        else: data.time += .002
    monkeypatch.setattr(core.mujoco, "mj_forward", failed_forward)
    with pytest.raises((KeyboardInterrupt, RuntimeError)) as failure:
        env.change_armature((1,), (.04,))
    record = failure.value.parameter_event_record
    assert record["status"] == "failed" and record["parameter_assignment_completed"]
    assert env.model.dof_armature[7] == .04 and record["after_armature"][7] == .04
    assert record["confirmed_physics_substeps_added"] == 0


@pytest.mark.parametrize("indices,values", [([1], [.04]), ((True,), [.04]), ((1, 1), [.04, .04]), ((1,), [-.01])])
def test_invalid_armature_event_is_rejected_before_parameter_mutation(env, indices, values):
    before = env.plant_fingerprint()
    with pytest.raises(ValueError):
        env.change_armature(indices, values)
    assert env.plant_fingerprint() == before
