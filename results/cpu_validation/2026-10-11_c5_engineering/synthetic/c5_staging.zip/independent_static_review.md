# C5 hidden-channel / armature draft static review

Reviewed copies are stored in this ignored staging directory. No C5 physical integration, project import, test rerun, research-gate change or code modification was performed. The original test stdout reports 17 passed in 0.26 s; this review does not independently rerun that result and does not promote it to physical validation.

| Reviewed input | SHA256 |
|---|---|
| reviewed_perturbed_environment.py | 075293eaa7bd47a9d629e1c6a5b9b6731e5a5e49ce938fec2eddac6db8789f86 |
| reviewed_test_perturbed_environment.py | d345a55c18c5a43288aa5d9481eeca064ef63d30f4da9536f14fc87ca1012dec |
| reviewed_synthetic_tests_stdout.txt | a9c6be8b86d3128134a5e5f59331fc4b9c135bedb9f8abd988a6f020d7bda926 |

`independent_static_review_sources.json` records original absolute paths, copy paths and hashes. Findings below refer to the reviewed draft, not later root edits.

The current native mapping at draft line 99 follows `joint_indices -> _joint_ids -> model.jnt_dofadr`, matching the base environment's `_joint_dof` construction and preserving native j1 without remapping the eight-element actor arrays. This is the correct indexing route. The synthetic fixture uses identity `_joint_ids`; a nonidentity joint-ID fixture would catch accidental replacement by `6+i` or indexing `jnt_dofadr[i]` directly.

The command order at lines 60–78 is public clipping, hidden positive gain, current-angle guard and unchanged unit motor. Positive gains no larger than one preserve guard direction and ensure the superclass clipping cannot expand the accepted request. `last_command` is restored to the actor's accepted request in `finally`, including a partially paid step that raises; endpoint actuator torque and applied history retain the physical command. Preexisting stop leaves previous accepted history unchanged. This is consistent with learning from native signals and a command known at step start. Hidden gains belong only to audit diagnostics and event records.

Armature mutation selects runtime dofs and calls `mj_forward`; the draft does not call `mj_step`, reset or a settling loop. It checks qpos, qvel, last_command, time and both paid counters for equality. Under normal MuJoCo semantics, forward recomputes derived state and sensors without integrating time. Synthetic stubs verify bookkeeping only. The existing asset declares eight ordinary motors; a future asset/backend change still requires unit gain/gear and encoder/action mapping smoke checks before interpreting ctrl history as torque.

Three boundaries should be hardened or explicitly handled before a formal C5 collection:

1. **The inherited physical fingerprint omits channel gains.** `parameter_record`/`plant_fingerprint` include them, but inherited `parameter_fingerprint` does not. Old runner/audit code that reads only the latter will miss a channel-gain event. A new protocol and collector should freeze and audit `plant_fingerprint` plus the separate accepted/scaled/actual signals. This is an integration requirement, not a defect in the separate fingerprint design.
2. **A diagnostic exception in `change_armature` finally can replace the original failure.** At reviewed lines 121–122, reading `after_armature` or computing `after_plant` can raise while an original `mj_forward` exception is pending. The surfaced exception then lacks `parameter_event_record`, although armature assignment may already be committed. Preserve the original exception and attach a best-effort after snapshot with any diagnostic failure separately recorded. Save after qpos/qvel/time/last_command/counters as well as after armature, so the tested forward state-mutation failure can be audited without depending on another collector snapshot. An assignment-completed flag is useful; no rollback, retry or additional integration should be hidden.
3. **A channel assignment followed by record failure lacks a failure event record.** `set_channel_gains` line 48 commits before the `after` parameter record at line 49. If that record fails, the caller gets an exception without an event payload. Use the same attempted/applied/failed and before/after semantics for channel events, preserving the committed gain values and any record failure. This can be tested with a pure stub whose fingerprint succeeds before assignment and fails afterward.

Suggested finite synthetic additions are a shuffled native mapping, an armature-forward original exception combined with an after-fingerprint exception, and a gain after-record failure. The existing interrupted-step test confirms paid physics counter and accepted last_command, but no transformed diagnostics are returned on an exception; a new collector must preserve the requested/accepted command, current gain-event lineage and actual paid partial history or its explicit lower bound in its exception archive. Do not manufacture ten complete substeps from an exception.

Inherited reset resets body data and counters but does not restore wrapper gains or `model.dof_armature`. Formal trials should use fresh environments or explicit logged initialization for all parameter conditions. Parameter changes before reset/after termination are currently allowed by these setters; event timing and eligibility must be frozen by the caller protocol. The draft itself declares no event schedule or research gate, and should remain an engineering draft until those are defined.

This review does not infer that adding coupled features, armature changes or hidden-gain tests will fix the failed elbow model. The body failure archive supplies hypotheses about limited condition support and recovery predictions; C5 requires its own identical-budget, frozen/online comparison and independent classical baseline.
