# C5 staging delivery: UNFROZEN

Current source is an engineering candidate only. No parameter choice, event timing preregistration, physical collection or scientific gate has been frozen. Body-learning summary and C5 synthetic costs are separate.

Fixes: native 8D mapping preserved; standard parameter_fingerprint includes wrapper gains with separate base_model_fingerprint; gain/armature events record attempted/applied/failed, before/after live state, assignment fact and best-effort after errors; primary forward/report exceptions survive field capture failure; step/event/reset reentry is rejected; reset retains current gains and armature.

Original 17-test stdout and original static review/copies are untouched. Repair 02 used default D:/Python3.10/python.exe: MuJoCo unavailable, 1 skipped, exit5, wall .7839480999391526 s and process CPU .65625 s; no physical calls. Repair 03 wrapper copied the wrong prefix and refused existing exclusive snapshots before pytest or any physics; the script is retained, no overwrite occurred. An earlier shell quoting syntax error also did not create or execute a test wrapper.

Repair 04 used existing external/cpu_physics_env/Scripts/python.exe: 29 passed in .29s, wrapper wall .5547778999898583 s, Python process CPU .484375 s. CPU includes pytest import and complete finite tests in the same process. Actual environments are not constructed by the stub tests; mj_forward and GroundBodyEnv.step are monkeypatched. Physical calls0, real updates0, no original body/audit summary rerun.

Repair 04 source SHA5057dbe2b72d779463c58f426014182c09b49a030b1d03a789b084ced2e29df1; tests SHAb7f12e08d632407f794ea253267940653e44cd4490497ab2d7ea2649af47bd4e. Executed snapshots, attempt, stdout and execution json retained. No source edits after successful repair04 tests.

C5_ENGINEERING_PROTOCOL_DRAFT.md is explicitly unfrozen and has no gain/armature values, seeds, commands, event timing or budget selected. Root must freeze a concrete protocol and clean source before any physical engineering check. No causal claim that coupled models will fix elbow failure.

| Absolute file | SHA256 |
|---|---|
| D:\Codex_ws\robot_rl\external\c5_staging\C5_ENGINEERING_PROTOCOL_DRAFT.md | 989b131939747cf3d429394ce287a42e4e1e31863dc73a934b64116365efdf8a |
| D:\Codex_ws\robot_rl\external\c5_staging\independent_static_review.md | 38eb49a165b20742404e59771b5847ebae0f2d52a63e54da6c2f376dc9368e11 |
| D:\Codex_ws\robot_rl\external\c5_staging\independent_static_review_sources.json | be65885c074045252cb90d4e73741f66cf39a95515279cb28eabb40d160e7a1e |
| D:\Codex_ws\robot_rl\external\c5_staging\perturbed_environment.py | 5057dbe2b72d779463c58f426014182c09b49a030b1d03a789b084ced2e29df1 |
| D:\Codex_ws\robot_rl\external\c5_staging\repair_02_attempt.json | 076e2613eb351ce40edc201993b6f302ce5a7fa7f656a1e56b4e2f93452d1f94 |
| D:\Codex_ws\robot_rl\external\c5_staging\repair_02_execution.json | f25190556336947f92adfeba0f59395162837cf33305ab9a937f545a0ebc4aa4 |
| D:\Codex_ws\robot_rl\external\c5_staging\repair_02_perturbed_environment.py | 5057dbe2b72d779463c58f426014182c09b49a030b1d03a789b084ced2e29df1 |
| D:\Codex_ws\robot_rl\external\c5_staging\repair_02_run_repair_synthetic_02.py | a831778d01ed0eee99ec8164f70319a3cf9d9988ccdd3598e1c464160bafc5a8 |
| D:\Codex_ws\robot_rl\external\c5_staging\repair_02_stdout.txt | 8ff7f2e08c66a758c46170841d3a225a511acece8a36332dd6821ddb11a3a7de |
| D:\Codex_ws\robot_rl\external\c5_staging\repair_02_test_perturbed_environment.py | b7f12e08d632407f794ea253267940653e44cd4490497ab2d7ea2649af47bd4e |
| D:\Codex_ws\robot_rl\external\c5_staging\repair_04_attempt.json | 8339d3aa3aaa8105b46ecf0aa12fca8464df5e62c9d5926d90d28a8d6c24906a |
| D:\Codex_ws\robot_rl\external\c5_staging\repair_04_execution.json | 7b142f90e0f7c6833d3beb104b287cbe61b4d3805f2baadfdfd2696b67ab7530 |
| D:\Codex_ws\robot_rl\external\c5_staging\repair_04_perturbed_environment.py | 5057dbe2b72d779463c58f426014182c09b49a030b1d03a789b084ced2e29df1 |
| D:\Codex_ws\robot_rl\external\c5_staging\repair_04_run_repair_synthetic_04.py | c9e194f9f237895d0be9ab1af7e5b685a876541751a46c682a929cb426c4808c |
| D:\Codex_ws\robot_rl\external\c5_staging\repair_04_stdout.txt | 27fd668a593127e9a420b1d066f0cddb069d82f3ab1c9520075369e6ae55ca10 |
| D:\Codex_ws\robot_rl\external\c5_staging\repair_04_test_perturbed_environment.py | b7f12e08d632407f794ea253267940653e44cd4490497ab2d7ea2649af47bd4e |
| D:\Codex_ws\robot_rl\external\c5_staging\reviewed_perturbed_environment.py | 075293eaa7bd47a9d629e1c6a5b9b6731e5a5e49ce938fec2eddac6db8789f86 |
| D:\Codex_ws\robot_rl\external\c5_staging\reviewed_synthetic_tests_stdout.txt | a9c6be8b86d3128134a5e5f59331fc4b9c135bedb9f8abd988a6f020d7bda926 |
| D:\Codex_ws\robot_rl\external\c5_staging\reviewed_test_perturbed_environment.py | d345a55c18c5a43288aa5d9481eeca064ef63d30f4da9536f14fc87ca1012dec |
| D:\Codex_ws\robot_rl\external\c5_staging\run_repair_synthetic_02.py | a831778d01ed0eee99ec8164f70319a3cf9d9988ccdd3598e1c464160bafc5a8 |
| D:\Codex_ws\robot_rl\external\c5_staging\run_repair_synthetic_03.py | a831778d01ed0eee99ec8164f70319a3cf9d9988ccdd3598e1c464160bafc5a8 |
| D:\Codex_ws\robot_rl\external\c5_staging\run_repair_synthetic_04.py | c9e194f9f237895d0be9ab1af7e5b685a876541751a46c682a929cb426c4808c |
| D:\Codex_ws\robot_rl\external\c5_staging\synthetic_tests_stdout.txt | a9c6be8b86d3128134a5e5f59331fc4b9c135bedb9f8abd988a6f020d7bda926 |
| D:\Codex_ws\robot_rl\external\c5_staging\test_perturbed_environment.py | b7f12e08d632407f794ea253267940653e44cd4490497ab2d7ea2649af47bd4e |
