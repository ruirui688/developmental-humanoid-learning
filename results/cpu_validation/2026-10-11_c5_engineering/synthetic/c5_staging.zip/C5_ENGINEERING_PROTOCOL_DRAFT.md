# C5 工程验证协议草稿（未冻结，不可执行物理）

这是 hidden command gain / runtime armature 包装环境的工程验收草稿。当前只有静态审读与29项纯合成检查，没有真实 MuJoCo 步进、身体学习、参数选择、扰动时序预注册或算法优势结论。root 复核并以明确源码提交和冻结协议替换本草稿后，才能单次执行相应物理检查。

## 尚未冻结的字段

| 字段 | 当前值 |
|---|---|
| 正式 source commit / clean 状态 | 未冻结 |
| 关节组合、seed、姿态 | 未冻结 |
| hidden gain 值、运行时 armature 值 | 未选择 |
| 参数事件发生的控制步边界 | 未预注册 |
| 固定零/非零命令序列 | 未选择 |
| prefix / active 调用及子步预算 | 未冻结 |
| 允许的研究停止包络及完整性门 | 未冻结 |
| raw / stdout / audit / execution 文件前缀 | 未冻结 |

草稿候选 source 与测试可由 `repair_04_execution.json` 的 SHA256 定位；它们不是已冻结研究配置。不能根据物理结果回来填参数或时序。

## 工程问题

验证原生8维映射、public request/accepted request/hidden scaling/angle guard/actual substep history 的顺序，以及参数事件不偷偷 reset、积分或增加未计账交互。gain 和 armature 是模拟环境条件变化，不是学习算法更新；不能将环境变化带来的改善称为模型学习或能力成熟。

每个 trial 使用新的环境对象，记录 asset hash、MuJoCo版本、配置、单位motor gain/gear、实际 `_joint_ids/_joint_qpos/_joint_dof` 和公开限位。构造时 gains=1、armature来自asset；`reset`保持当前gain/armature，不静默恢复。配对组若需重新使用对象，显式恢复事件本身及其失败也必须记账；默认建议 fresh env。

事件只允许完整控制调用之间的边界。不得在 `mj_step` 子步内改变参数，不进行隐含等待、复位或重试。记录事件前后qpos、qvel、time、last_command、physics_steps、step_id、armature、gain、base/plant fingerprint。参数赋值成功但报告失败或forward失败时仍保留assignment事实，失败向上抛出并终止该trial。

## 准备的最小验收

1. 原生关节索引经joint ID查表到dof，不假设编号就是 `6+i`；qpos/qvel及actor8维均保持原顺序。
2. actor只收到原生观测和自己已知的accepted command history。gain、armature和plant fingerprint保留在审计日志，不能作为隐藏参数标签进入模型/控制器。
3. gains=1工程配对可与原GroundBodyEnv执行同一冻结命令检查原生轨迹与实际历史一致；这是日志/包装一致性，不是方法优势。
4. gains变化后，public clip仍使用原权限，scaled command应等于accepted×gain，actual history还须按每个子步当时角度的guard判断。记录实际torque feedback，不能仅用scaled request替代实际执行。
5. runtime armature仅修改指定原生dof。`mj_forward`重算派生量而不积分；qpos/qvel/time/command/counters不变，derived sensors可变化。记录真实after数组，不以零counter差代替异常状态证据。
6. gain/armature事件使plant fingerprint按预期变化；base fingerprint保持独立且仅跟踪底座实际参数。下游 collector 的常用 `parameter_fingerprint` 已返回完整plant指纹，不漏wrapper gain。
7. 完整、环境停止、研究停止、异常、部分子步分别计账。异常可能留actual effort/history下界，不伪造完整20ms端点。事件自身没有物理步并不免除其前后控制交互预算。

正式检查只允许少量已冻结命令，不更新RLS、神经网络、策略、增益或门控阈值。冻结版本需要预先明确以上每项的数值容差、失败处理、重复次数、预算和单次写盘前缀；本草稿没有这些值，所以现在不得执行。

## 后续研究边界

工程验收不能解决或证明左肘恢复预测失配。真正C5扰动适应实验需要单独冻结相同初始化/同权限/同预算的冻结模型、在线模型及经典控制组，已知/未知参数信息的披露、事件之前表现、事件之后完整评估、独立seed和所有失败成本。耦合、guard或接触条件的影响是待检验假设。
