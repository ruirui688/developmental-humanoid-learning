"""Unfrozen C5 engineering draft; no event timing or research gate declared.

The actor receives native observations. Hidden gain is applied in the command
channel, while the original asset's motor gain and gear remain unchanged.
"""
from __future__ import annotations

import hashlib
import json
import time

import mujoco
import numpy as np

from developmental_physics.environment import GroundBodyEnv


def _gains(value):
    array = np.asarray(value, dtype=float)
    if array.shape != (8,) or not np.isfinite(array).all() or np.any(array <= 0.) or np.any(array > 1.):
        raise ValueError("Eight finite hidden channel gains in (0,1] required")
    array = array.copy()
    array.setflags(write=False)
    return array


class PerturbedGroundBodyEnv(GroundBodyEnv):
    """Command scaling preserves accepted-command history and paid steps.

    This draft supports only boundary changes; it never schedules an event
    inside step, waits, resets the body or adds uncharged physics steps.
    """
    def __init__(self, config=None):
        super().__init__(config)
        self._channel_gains = _gains(np.ones(8))

    def parameter_record(self):
        return {"base_model_fingerprint": super().parameter_fingerprint(),
                "hidden_channel_gains": self._channel_gains.tolist(),
                "execution_order": "accepted request -> hidden scaling -> current angle guard -> unchanged unit motor"}

    def plant_fingerprint(self):
        return hashlib.sha256(json.dumps(self.parameter_record(), sort_keys=True).encode()).hexdigest()

    def set_channel_gains(self, gains):
        proposal = _gains(gains)
        before = self.parameter_record()
        self._channel_gains = proposal
        return {"status": "applied", "before": before, "after": self.parameter_record(),
                "new_physics_substeps": 0}

    def step(self, torque):
        requested = np.asarray(torque, dtype=float)
        if requested.shape != (8,) or not np.isfinite(requested).all():
            raise ValueError("torque must be a finite vector of length 8")
        if not self._reset_done:
            raise RuntimeError("reset must be called before step")
        if self.terminated:
            raise RuntimeError("episode stopped; reset is required")
        accepted = np.clip(requested, -self.action_limits, self.action_limits)
        scaled = accepted*self._channel_gains
        # Mirror the base environment's public command acceptance condition.
        # Restore semantics even if integration or diagnostics throws midway.
        will_accept = self._stop_reason() is None
        try:
            result = super().step(scaled)
        finally:
            if will_accept:
                self.last_command[:] = accepted
        result.observation["previous_command"] = self.last_command.copy()
        result.diagnostics["requested_torque"] = requested.tolist()
        result.diagnostics["accepted_torque"] = accepted.tolist()
        result.diagnostics["hidden_command_transform"] = {
            "accepted_request": accepted.tolist(), "channel_gains": self._channel_gains.tolist(),
            "scaled_before_guard": scaled.tolist(),
            "paid_substeps": result.diagnostics["executed_substeps"],
            "motor_gain_or_gear_changed": False,
            "applied_history_semantics": "actual unit-motor command after hidden scaling and angle guard"}
        return result

    def change_armature(self, joint_indices, values):
        """Unvalidated engineering event; any failure is fatal to its caller.

        Armature enters the runtime generalized mass calculation. This draft
        intentionally exposes the applied array even if mj_forward fails;
        it performs no rollback or retry. No physical step is integrated.
        """
        if type(joint_indices) is not tuple or not joint_indices or len(set(joint_indices)) != len(joint_indices):
            raise ValueError("Nonempty immutable unique joint indices required")
        if any(type(i) is not int or not 0 <= i < 8 for i in joint_indices):
            raise ValueError("Native joint indices 0..7 required")
        proposal = np.asarray(values, dtype=float)
        if proposal.shape != (len(joint_indices),) or not np.isfinite(proposal).all() or np.any(proposal < 0.):
            raise ValueError("Finite nonnegative armature per declared joint required")
        before = {"qpos": self.data.qpos.copy(), "qvel": self.data.qvel.copy(),
                  "time": float(self.data.time), "physics_steps": self.physics_steps,
                  "step_id": self.step_id, "last_command": self.last_command.copy(),
                  "armature": self.model.dof_armature.copy(), "plant": self.plant_fingerprint()}
        dofs = [int(self.model.jnt_dofadr[self._joint_ids[i]]) for i in joint_indices]
        record = {"status": "attempted", "joint_indices": list(joint_indices),
                  "dof_indices": dofs, "proposal": proposal.tolist(), "before": before}
        wall, cpu = time.perf_counter(), time.process_time()
        try:
            self.model.dof_armature[dofs] = proposal
            record["parameter_assignment_completed"] = True
            mujoco.mj_forward(self.model, self.data)
            for key in ("qpos", "qvel", "last_command"):
                actual = self.last_command if key == "last_command" else getattr(self.data, key)
                if not np.array_equal(before[key], actual):
                    raise RuntimeError(f"armature forward changed live {key}")
            if (self.data.time != before["time"] or self.physics_steps != before["physics_steps"]
                    or self.step_id != before["step_id"]):
                raise RuntimeError("armature event changed time or paid counters")
            record["status"] = "applied"
        except BaseException as exc:
            record["status"] = "failed"
            record["error"] = {"type": type(exc).__name__, "message": str(exc)}
            exc.parameter_event_record = record
            raise
        finally:
            record["after_armature"] = self.model.dof_armature.copy()
            record["after_plant"] = self.plant_fingerprint()
            record["wall_seconds"] = time.perf_counter()-wall
            record["cpu_seconds"] = time.process_time()-cpu
            record["confirmed_physics_substeps_added"] = self.physics_steps-before["physics_steps"]
        return record
