"""Capture repair sources and run finite pytest stubs only, no physical integration."""
import contextlib
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import sys
import time

base = Path(__file__).resolve().parent
prefix = base/'repair_02'
sources = {}
for name in ('perturbed_environment.py', 'test_perturbed_environment.py', Path(__file__).name):
    data=(base/name).read_bytes()
    target=Path(str(prefix)+'_'+name)
    with target.open('xb') as stream:
        stream.write(data)
    sources[name]={'original':str(base/name),'saved':str(target),'sha256':hashlib.sha256(data).hexdigest()}
with Path(str(prefix)+'_attempt.json').open('x',encoding='utf-8') as stream:
    json.dump({'utc':datetime.now(timezone.utc).isoformat(),'scope':'finite synthetic tests only'},stream,indent=2)
wall,cpu=time.perf_counter(),time.process_time()
buffer=io.StringIO()
with contextlib.redirect_stdout(buffer),contextlib.redirect_stderr(buffer):
    import pytest
    code=int(pytest.main(['-q',str(base/'test_perturbed_environment.py')]))
execution={'exit_code':code,'sources':sources,'wall_seconds':time.perf_counter()-wall,
    'cpu_seconds':time.process_time()-cpu,'cpu_scope':'This Python process through pytest import and complete finite tests; no child subprocess.',
    'physical_calls':0,'event_timing_frozen':False,'research_protocol_frozen':False,
    'physical_validation':False,'source_unchanged':all(hashlib.sha256(Path(v['original']).read_bytes()).hexdigest()==v['sha256'] for v in sources.values())}
stdout=buffer.getvalue().encode()
with Path(str(prefix)+'_stdout.txt').open('xb') as stream:
    stream.write(stdout)
execution['stdout_sha256']=hashlib.sha256(stdout).hexdigest()
with Path(str(prefix)+'_execution.json').open('x',encoding='utf-8',newline='\n') as stream:
    json.dump(execution,stream,indent=2);stream.write('\n')
print(buffer.getvalue(),end='')
print(json.dumps(execution))
raise SystemExit(code)
