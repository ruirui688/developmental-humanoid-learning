"""Preserve the aborted first setup with source bytes; no physics/Git/import retries."""
import hashlib
import importlib.metadata
import json
from pathlib import Path
import sys
import zipfile

ROOT = next(p for p in Path(__file__).resolve().parents if (p/"pyproject.toml").is_file())
OUTPUT = Path(__file__).resolve().parent
sources = [*sorted((ROOT/"src/developmental_physics").glob("*.py")),
           ROOT/"src/developmental_physics/assets/ground_body.xml", ROOT/"pyproject.toml",
           ROOT/"scripts/audit_local_frozen.py", ROOT/"external/c4_pair_pd_audit_staging/audit_pair_pd.py",
           *(ROOT/"external/c4_pair_pd_staging"/name for name in
             ("pair_pd_development.py", "test_pair_pd_development.py", "schema_integration.py", "PROTOCOL.md")),
           Path(__file__)]
source_bytes = {p.relative_to(ROOT).as_posix(): p.read_bytes() for p in sources}
zip_path = OUTPUT/"source_first.zip"
if zip_path.exists():
    raise FileExistsError(zip_path)
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as archive:
    for name, data in source_bytes.items():
        archive.writestr(name, data)
record = {
    "synthetic": True, "science_acceptance": False, "status": "setup_failed_before_collection",
    "reason": "MuJoCo import platform.system -> Windows uname/win32_ver -> subprocess.check_output rejected",
    "stdout": "stdout_first.txt", "collector_invocations": 0, "audit_invocations": 0,
    "real_physics_steps": 0, "synthetic_control_calls": 0, "synthetic_substeps": 0,
    "body_model_constructions": 0, "body_model_fits": 0, "parameter_updates": 0, "git_calls": 0,
    "subprocess_entry_attempts_rejected": [{"entry": "subprocess.check_output", "purpose": "Windows platform version", "count": 1}],
    "process_wall_seconds": None, "process_cpu_seconds": None,
    "exec_shell_wrapper_wall_seconds": 0.5967673,
    "timing_boundary": "Native tool reported whole command wall time; Python setup timers were not persisted before import rejection. CPU time unknown.",
    "source_commit": None, "source_git_blobs": {}, "git_resolution": "not queried",
    "python_version": sys.version, "python_executable": sys.executable, "gpu": None,
    "dependencies": dict(sorted((d.metadata["Name"], d.version) for d in importlib.metadata.distributions())),
    "source_sha256": {name: hashlib.sha256(data).hexdigest() for name, data in source_bytes.items()},
    "source_snapshot_sha256": hashlib.sha256(zip_path.read_bytes()).hexdigest(),
    "claim_boundary": "Aborted setup only; no runner/auditor or scientific validation occurred.",
}
(OUTPUT/"setup_failure_first.json").write_text(json.dumps(record, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")
manifest = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUTPUT.iterdir()) if p.is_file()}
(OUTPUT/"manifest.json").write_text(json.dumps(manifest, indent=2)+"\n", encoding="utf-8")
print(json.dumps({"status": record["status"], "sources": len(source_bytes), "source_snapshot_sha256": record["source_snapshot_sha256"]}))
