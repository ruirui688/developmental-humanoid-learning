"""Preserve second failed setup source before the unexecuted one-line correction."""
import hashlib
import importlib.metadata
import json
from pathlib import Path
import sys
import zipfile

ROOT = next(p for p in Path(__file__).resolve().parents if (p/"pyproject.toml").is_file())
OUTPUT = Path(__file__).resolve().parent
sources = [*sorted((ROOT/"src/developmental_physics").glob("*.py")),
           ROOT/"src/developmental_physics/assets/ground_body.xml", ROOT/"pyproject.toml",
           ROOT/"scripts/audit_local_frozen.py", ROOT/"external/c4_pair_pd_audit_staging/audit_pair_pd.py",
           *(ROOT/"external/c4_pair_pd_staging"/name for name in
             ("pair_pd_development.py", "test_pair_pd_development.py", "schema_integration.py", "PROTOCOL.md")),
           Path(__file__)]
source_bytes = {p.relative_to(ROOT).as_posix(): p.read_bytes() for p in sources}
zip_path = OUTPUT/"source_first.zip"
if zip_path.exists():
    raise FileExistsError(zip_path)
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as archive:
    for name, data in source_bytes.items():
        archive.writestr(name, data)
failure = json.loads((OUTPUT/"setup_exception_first.json").read_text(encoding="utf-8"))
record = {
    "synthetic": True, "science_acceptance": False, "status": "setup_failed_before_collection",
    "reason": "Python3.10 platform.uname_result requires five fields; harness passed six",
    "stdout": "stdout_first.txt", "collector_invocations": 0, "audit_invocations": 0,
    "real_physics_steps": 0, "synthetic_control_calls": 0, "synthetic_substeps": 0,
    "body_model_constructions": 0, "body_model_fits": 0, "parameter_updates": 0, "git_calls": 0,
    "rejected_entry_attempts": failure["rejected_entry_attempts"],
    "process_wall_seconds": failure["wall_seconds"], "process_cpu_seconds": failure["cpu_seconds"],
    "exec_shell_wrapper_wall_seconds": 0.5037751,
    "timing_boundary": "Process timer starts after imports/ROOT setup; failed guarded setup persisted before exiting. Shell wrapper separately measured by tool.",
    "source_commit": None, "source_git_blobs": {}, "git_resolution": "not queried",
    "python_version": sys.version, "python_executable": sys.executable, "gpu": None,
    "dependencies": dict(sorted((d.metadata["Name"], d.version) for d in importlib.metadata.distributions())),
    "source_sha256": {name: hashlib.sha256(data).hexdigest() for name, data in source_bytes.items()},
    "source_snapshot_sha256": hashlib.sha256(zip_path.read_bytes()).hexdigest(),
    "claim_boundary": "Second aborted setup only; no runner/auditor schema or scientific validation occurred. No third attempt was performed.",
}
(OUTPUT/"setup_failure_first.json").write_text(json.dumps(record, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")
manifest = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUTPUT.iterdir()) if p.is_file()}
(OUTPUT/"manifest.json").write_text(json.dumps(manifest, indent=2)+"\n", encoding="utf-8")
print(json.dumps({"status": record["status"], "sources": len(source_bytes), "source_snapshot_sha256": record["source_snapshot_sha256"]}))
