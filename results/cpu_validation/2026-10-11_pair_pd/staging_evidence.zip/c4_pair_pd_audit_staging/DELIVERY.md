# Fixed shoulder/elbow PD independent audit — engineering delivery

Date: 2026-10-11. This directory is ignored staging. No tracked files or Git state were changed by this subtask. The parent task owns production promotion, protocol freezing, runner integration, commits and pushes.

## Files and SHA-256

| File | SHA-256 |
| --- | --- |
| `audit_pair_pd.py` | `2a75d4c94a591d0e2b4c1d29ec8b0331e8154aa34fc42fbc48f9d982df01a989` |
| `test_pair_pd_audit.py` | `3cf3dfef8d92f090e20087bba74b85886c27c767ba641f96e24b5993619bcaf1` |
| `synthetic_stdout.txt` | `b7d191505ed927cee5d877508c80174f465b2226038a01b63096168e50cb78da` |
| `synthetic_tests.xml` | `c8665a397f356bbebf837011b485634c4add801a93d52e1356cd276d1ae3b108` |
| Shared `scripts/audit_local_frozen.py` | `b5fea70d3733a1bab77e49bf559432475899436693cf6c1b0b4767369c913461` |

The shared audit is loaded directly from its file. Both the new audit and shared audit must be covered by the collector's source ZIP and SHA manifest. At audit time their runtime bytes must match the archived source. Source validation also checks unique ZIP coverage, the protocol and collector, clean source commit/status, Git blob IDs calculated from archived bytes, and—when `git_root` is provided—the actual committed tree and file bytes.

## Implemented scope

The numerical plan is immutable source code, checked before trace/source archive consumption: seeds 0/1/2 with fixed reset seeds; supine development trials; shoulder/elbow indices 0/1; `Kp=(64,64)`; nine `Kd` pairs from `(0,1,2) × (1,2,4)`; 100 prefix calls and 200 control calls per trial; 27 trials; maximum 8100 calls and 81000 physics substeps. Metadata cannot shrink the plan or supply alternative gains, ranges, directions or scope.

The audit independently reconstructs public asset ranges, feasible target directions, raw 8D observations and action permissions, current-target PD commands, endpoint guards, StudyAbort, full/prefix/control budgets and risk totals, actual action-history effort, fixed tracking windows, candidate qualification, and exact candidate selection. Missing actual history prevents candidate selection and remains an explicit effort lower bound. The selection order is joint raw RMSE, worst-axis raw RMSE, control actual squared effort, then candidate index.

Partial calls, returned-but-unwritten results, already-written final results, paid substeps with no return, terminal outcomes and fatal blocked suffixes are accounted for without filling missing values with zero or rerunning failed trials. Ineligible candidates require a nonempty recorded qualification-failure list; exact prose matching of those failure reasons is not enforced. Independent outcomes are retained in the report.

`audit(..., git_root=None, spec=DRAFT_SPEC)` is engineering diagnosis only. A validated selection requires complete source/Git checks, a picked candidate, zero audit failures, the non-synthetic production scope, and an explicitly frozen scientific protocol. The CLI uses production scope and requires a new output directory outside the input archive.

## Finite synthetic verification

Executed once after implementation:

```powershell
& 'external/cpu_physics_env/Scripts/python.exe' -m pytest -q external/c4_pair_pd_audit_staging/test_pair_pd_audit.py --junitxml=external/c4_pair_pd_audit_staging/synthetic_tests.xml 2>&1 | Tee-Object -FilePath external/c4_pair_pd_audit_staging/synthetic_stdout.txt
exit $LASTEXITCODE
```

Result: **22 passed in 3.93 seconds**. Stdout and JUnit XML above retain this run. Tests import only the independent audit, pytest and the standard library; AST checks prohibit collector/environment/controller/NumPy/MuJoCo/torch imports, and subprocess calls are blocked in the fixture.

The manually built full 27-trial schema fixture represents 8100 synthetic calls / 81000 synthetic substeps / zero updates. The manually built fatal fixture represents 101 synthetic attempts / 100 returned calls / 1003 synthetic substeps, followed by 26 blocked trials. Each deliberately reports exactly two source-check failures (`source_commit_format` and `clean_collection_source`), because no source commit/status/blob evidence is fabricated. Other schema, arithmetic, qualification and selection checks pass; `validated_selection` remains false. These two diagnostic failures are expected assertions inside passing tests, not scientific source-validation success.

Additional finite primitive cases cover malformed/immutable scope, PD arithmetic and input validation, equal-threshold StudyAbort, fixed last-20 windows, partial and missing calls, returned-but-unwritten accounting, exact selection hierarchy, and detection of premature targets or forged budgets. Test archives remain in pytest temporary storage; they are synthetic fixtures, not physical evidence.

Real environment calls: **0**. Parameter/model updates or fits: **0**. New pair/raw20–22 trajectory reads: **0**. Git calls: **0**. No scientific experiment or real runner integration was performed.

## Parent integration requirements

Promote the auditor to `scripts/audit_pair_pd.py`, the collector to `src/developmental_physics/pair_pd_development.py`, and the protocol to `docs/PAIR_PD_DEVELOPMENT_PROTOCOL.md`; production suite must be `pair_pd_development`. Include both audit sources in the collector ZIP/manifest and freeze committed source before real collection. Use one bounded runner/schema integration before physical execution.

The earlier collector synthetic fixture uses simplified ranges; production audit reads the actual public asset ranges and must not be relaxed to accept a fake layout. Align a runner fixture to the asset for a positive integration case, or retain the simplified fixture as an explicit engineering negative case. Public motor-limited flags, if checked in runner integration, should accept semantic booleans and integer 0/1 without a dtype-only rejection.

Do not treat this delivery, synthetic selection, softer contact, waiting prefixes, or changed fixed controller gains as learned skill or an online-learning benefit. Production scientific adoption and any later PD/short-pulse experiment remain the parent task's responsibility.
