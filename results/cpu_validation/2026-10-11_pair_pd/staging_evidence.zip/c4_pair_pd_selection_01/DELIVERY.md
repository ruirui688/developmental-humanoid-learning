# 双轴 PD：最新选择规则修正与有限工程证据交付

2026-10-11。所有子任务修改仅在 ignored `external/`。无 tracked 修改、Git 读取、提交或推送；父任务负责正式推广和提交。本交付取代此前草案交付中关于“最差轴平均”的选择说明。

## 最新固定选择顺序

父任务在正式冻结前明确核正为：

1. 三个 development seed 的双轴联合原始 RMSE 均值；
2. 三个 seed 的联合原始 RMSE 最大值，即最差 seed；
3. 三个 seed 的双轴 active 实际平方努力和的均值；
4. candidate 索引。

collector、独立 auditor、协议、手工 fixture 和两份选择测试现已同步。auditor 还独立核验已存 `sort_order`。未改变固定九组 Kd、Kp、seed、目标、方向、prefix、预算、停止条件或选择资格。未重新运行完整 27 trial。

最新源码 SHA-256：

| 文件 | SHA-256 |
| --- | --- |
| `external/c4_pair_pd_staging/pair_pd_development.py` | `48318313f3c3c6f40062d64a483f4e2e8dc352c6d278fb97b4f3bf5912e95215` |
| `external/c4_pair_pd_staging/test_pair_pd_development.py` | `cc67c98e81c04464568ccc8d1c874038e74115b848a48ac4dbc3450e3c59294c` |
| `external/c4_pair_pd_staging/PROTOCOL.md` | `dda09e210649eaed3f57612213e4d217abcf430eb9c71f104a9667dbe5ea5979` |
| `external/c4_pair_pd_audit_staging/audit_pair_pd.py` | `a3f596c053b2f06e9d0fe099e8d10449787b38a6e03f6a4c5361c27d722322b2` |
| `external/c4_pair_pd_audit_staging/test_pair_pd_audit.py` | `31184f77c6b2d0c3a5b0f8df205d2d6dc0c8573fa586a42834abbd7d923ca4b0` |
| `external/c4_pair_pd_staging/schema_integration.py` | `bab106906f781bb94f229bf18151cc0c8324616f83d7b96f9ac455877367a8e5` |
| `scripts/audit_local_frozen.py`（未修改） | `b5fea70d3733a1bab77e49bf559432475899436693cf6c1b0b4767369c913461` |

## 本次有限选择测试

仅执行四个 selection primitive 测试，一次结果 **4 passed in 0.37 s**；stdout 与 JUnit XML 在本目录。没有调用 collector、环境、模型构造/更新、物理或 Git。

两份测试各含一个预先手工指定的反例：candidate A 三 seed joint RMSE 为 1/2/3、误差轴交替；candidate B 为 2/2/2、误差固定在轴 0。两者均值为 2；每个轴 RMSE 与 joint 的均方关系一致。旧最差轴平均会选 A（`4√2/3 < 2√2`），新最差 seed 必须选 B（2 < 3），即使 B 的 effort 为 100、A 为 1。预期精确 key 为 A `[2,3,1,0]`、B `[2,2,100,1]`，避免 collector 与 auditor 共享错误仍一起通过。

同时保留均值优先、精确 nextafter、努力和索引并列、缺 seed/缺实际历史不能获选的选择边界。未执行 full-schema 测试或完整 synthetic runner，所以这四个 primitive 结果只验证最新选择规则；此前完整工程联调属于旧规则源代码。

## 此前 runner/auditor 联调与失败原件

`external/c4_pair_pd_schema_01`：首次 setup 在 `import mujoco` 的 Windows 版本查询触发被拒绝的 `subprocess.check_output` 时退出。collector/auditor 均未调用，真实与合成费用均零。保留 stdout、完整 30 项源码 ZIP/SHA 与 setup 记录。Python 内部 wall/CPU 未来得及保存，记录为 null；工具整个 shell 命令 wall 为 0.5967673 s，不冒充 Python CPU。

`external/c4_pair_pd_schema_02`：第二次 setup 使用了不适配 Python 3.10 的六字段 `platform.uname_result`，TypeError 后退出，同样未调用 collector/auditor。保存原件和 source ZIP；内部 timer wall 0.000998 s、CPU 0.0 s；shell wrapper wall 0.5037751 s。签名静态核实为 `(system,node,release,version,machine)`，修正为五字段。

父任务随后明确授权一次第三 prefix；`external/c4_pair_pd_schema_03` 一次完成 27 trial、8100 synthetic attempts/returns、81000 fake substeps。模型/数据构造、全部 `mj_`/`mju_` 调用、真实环境构造、身体模型构造/update 及 subprocess/Git 均有拒绝替身；拒绝入口尝试为零。fixture 按公共 XML 的真实原 8D 关节名与范围构造记录，history 为 synthetic 的当前状态 `.03` zero/request projection。此矩阵没有非零 guard 干预，不代表检验了 guard 的物理效应。

03 首次 independent audit：1,080,792 checks，恰好两个预期源证据失败 `source_commit_format` / `clean_collection_source`，最大数值差 `4.44e-16`；`validated_selection=False`，`science_acceptance=False`。collector envelope wall/CPU 6.308488/6.218750 s，audit envelope 2.677866/2.640625 s，total 9.292856/9.140625 s。真实物理、参数更新、拟合、Git 均零。

03 的旧选择规则原件保持不变：source ZIP SHA `e73cf57956b891d8c5d58f4598fe0b980b76e4053181a7c507c0f43b3859fc16`；首次 audit SHA `ed8129b19a438716786b84f05a5f6de6631c6c647a85aa028c401e1f2af4ee54`；accounting SHA `dcfac33cb71a425b22742876ede6ece6a20ffa8673b2410e16fdcaac33e10d93`。01 source ZIP SHA `9f1db8cb4dc2bc84398aab176efc50184acfac80763aedb2017ac55739e9f072`；02 source ZIP SHA `5c4e3e68381246925b4ddfdbe817300cb4c74ab4c209390435f0ff3aaedb35c6`。

03 只作为旧选择 schema 的工程证据；不覆盖、不重新审计以假装它来自最新 source，也不将其 synthetic candidate 0 移作真实 gain 选择。不曾执行第四次 full runner。

## 正式推广与可克隆测试

runner test 已支持 sibling import，否则从 `developmental_physics` 正式 package 导入；缺 MuJoCo 时整个 physics fixture 模块 `pytest.importorskip`。真实执行禁用测试显式 monkeypatch `FORMAL_EXECUTION_FROZEN=False`，因此正式 frozen 状态不使其误报。audit test 支持 sibling import，否则按精确 `ROOT/scripts/audit_pair_pd.py` 加载；保持 standard-library-only、无 collector/environment/NumPy/MuJoCo import。

父任务推广时仍需做精确路径转换，不能留下对 ignored 源码的依赖：

- collector → `src/developmental_physics/pair_pd_development.py`，protocol → `docs/PAIR_PD_DEVELOPMENT_PROTOCOL.md`，auditor → `scripts/audit_pair_pd.py`；两审计必须在源码 ZIP 内。
- 两份 test → tracked `tests/`；collector 的 `SYNTHETIC_FIXTURE_PATH` 指向确切 tracked runner test，synthetic support 删除仅此 ignored harness 的路径。
- 正式 collector suite 为 `pair_pd_development`；若同一正式 collector 支持 toy/synthetic，显式 `synthetic=True` suite 为 `pair_pd_development_draft`。不从归档 metadata 决定受审 scope。
- 若在 clean clone 运行完整 toy audit fixture，auditor 的 synthetic spec 源路径应显式转换为上面的 tracked collector/protocol/auditor 路径（数值固定 scope 不变），以免 `make_archive()` 读取 ignored 文件。synthetic 标记、backend、Git=None、`scientific_frozen=False` 均继续明示，synthetic 禁止科学采用。这项正式路径转换由父任务完成，本 ignored 交付没有修改 production scope。
- 正式 freeze/source clean commit/Git blob 校验与后续真实一次执行由父任务负责；当前 ignored collector 仍 `FORMAL_EXECUTION_FROZEN=False`。

本次未读取任何新的真实 pair 轨迹、raw20–22 或拟合结果；没有重写既有研究结论。最终实物/算法结论只能来自正式冻结后、保留全部失败与实际预算的物理实验。
