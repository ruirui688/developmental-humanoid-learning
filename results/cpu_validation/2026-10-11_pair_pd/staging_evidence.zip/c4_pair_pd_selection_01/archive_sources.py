"""Archive finite selection-test source and existing evidence, no execution/Git."""
import hashlib
import importlib.metadata
import json
from pathlib import Path
import sys
import zipfile

ROOT = next(p for p in Path(__file__).resolve().parents if (p/"pyproject.toml").is_file())
OUTPUT = Path(__file__).resolve().parent
sources = [*sorted((ROOT/"src/developmental_physics").glob("*.py")),
           ROOT/"src/developmental_physics/assets/ground_body.xml", ROOT/"pyproject.toml",
           ROOT/"scripts/audit_local_frozen.py",
           *(ROOT/"external/c4_pair_pd_staging"/name for name in
             ("pair_pd_development.py", "test_pair_pd_development.py", "PROTOCOL.md", "schema_integration.py")),
           *(ROOT/"external/c4_pair_pd_audit_staging"/name for name in
             ("audit_pair_pd.py", "test_pair_pd_audit.py")), Path(__file__)]
blobs = {p.relative_to(ROOT).as_posix(): p.read_bytes() for p in sources}
archive_path = OUTPUT/"source_snapshot.zip"
if archive_path.exists():
    raise FileExistsError(archive_path)
with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as snapshot:
    for name, blob in blobs.items():
        snapshot.writestr(name, blob)
record = {
    "kind": "four finite selection primitive tests, latest worst-seed rule",
    "result": "4 passed in 0.37s", "full_runner_invocations": 0,
    "real_environment_calls": 0, "real_physics_steps": 0, "synthetic_environment_calls": 0,
    "model_updates": 0, "fits": 0, "git_calls": 0, "gpu": None,
    "source_commit": None, "source_git_blobs": {},
    "python_version": sys.version, "python_executable": sys.executable,
    "dependencies": dict(sorted((d.metadata["Name"], d.version) for d in importlib.metadata.distributions())),
    "source_sha256": {name: hashlib.sha256(data).hexdigest() for name, data in blobs.items()},
    "source_snapshot_sha256": hashlib.sha256(archive_path.read_bytes()).hexdigest(),
    "claim_boundary": "Latest selection primitives only; full schema_03 evidence retains its older criterion/source. No scientific validation.",
}
(OUTPUT/"metadata.json").write_text(json.dumps(record, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")
prior = {}
for suffix in ("01", "02", "03"):
    directory = ROOT/("external/c4_pair_pd_schema_"+suffix)
    prior[directory.relative_to(ROOT).as_posix()] = {
        p.relative_to(directory).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(directory.rglob("*")) if p.is_file()}
(OUTPUT/"preserved_schema_integrity.json").write_text(json.dumps(prior, indent=2)+"\n", encoding="utf-8")
manifest = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUTPUT.iterdir()) if p.is_file()}
(OUTPUT/"manifest.json").write_text(json.dumps(manifest, indent=2)+"\n", encoding="utf-8")
print(json.dumps({"source_snapshot_sha256": record["source_snapshot_sha256"], "source_count": len(blobs),
                  "delivery_sha256": manifest["DELIVERY.md"]}))
