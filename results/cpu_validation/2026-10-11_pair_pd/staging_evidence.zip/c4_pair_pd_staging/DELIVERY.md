# 双轴有限 PD 开发：ignored 工程草案交付

2026-10-11。父任务 `/root` 指定范围；目录 `external/c4_pair_pd_staging/` 被 `.gitignore` 的 `external/` 忽略。没有修改 tracked 文件，没有 Git 调用、真实物理、真实拟合或新 pair 轨迹读取。

## 文件与入口

- `pair_pd_development.py`：`run_pair_pd(output, *, protocol_path, synthetic=False)`。FORMAL_EXECUTION_FROZEN=False；真实调用立即拒绝，synthetic必须显式替换GroundBodyEnv。
- `PROTOCOL.md`：root指定固定Kp双轴9阻尼候选、预算、失败、记录和选择规则的未冻结工程协议。
- `test_pair_pd_development.py`：20项有限合成检查。显式SyntheticEnv，真实GroundBodyEnv构造和所有subprocess.check_output均被测试禁止；平台字段明确省略而非伪造。
- `synthetic_stdout.txt` / `synthetic_tests.xml`：最终原始输出。
- `synthetic_stdout_initial_setup_failure.txt` / `synthetic_tests_initial_setup_failure.xml`：保留首次测试隔离失败原字节。
- `check_scope.py` / `scope_inventory.json`：标准库源码范围检查、依赖版本及文件SHA256。

最终命令：

```powershell
$env:PYTHONPATH = 'src'
& 'external/cpu_physics_env/Scripts/python.exe' -m pytest -q external/c4_pair_pd_staging/test_pair_pd_development.py --junitxml=external/c4_pair_pd_staging/synthetic_tests.xml
& 'external/cpu_physics_env/Scripts/python.exe' external/c4_pair_pd_staging/check_scope.py
```

**20 passed in 11.66s**；Python3.10.11/NumPy2.2.6/MuJoCo3.15.0/pytest8.4.2。MuJoCo只作为现有模块依赖导入，未构造真实env或执行step。首次17失败/3通过均是采集前Windows `platform.platform()`调用subprocess("ver")触发全面禁止；未进入SyntheticEnv采集，更没有物理费用。fixture明确省略此字段后最终20项通过，失败输出完整保留。

## 固定行为

固定seed0/1/2、supine、原8D j0/j1、Kp=(64,64)、Kd按product肩[0,1,2]×肘[1,2,4]；候选0为旧组合。每trialfresh100zero prefix+200active，自己的原生末端qref/方向；不裁负肘qref或目标。current-only两段.04/.08目标，无切换预告，原PD数学及.5权限。其他六轴请求零、接触/环境保护不改；active任一目标轴>=.12位移或>=1速度停止。完整terminal评分且仍不complete，partial仅保留raw误差。

完整三seed九候选SyntheticEnv合同实际执行27trial/8100calls/81000synthetic substeps/0updates，prefix2700/27000，control5400/54000。真实物理增量均0。这不是正式实验或机器人仿真结果。

请求努力按finally已付费子步；actual历史逐8D核验，逐轴与双轴和分别计。missing历史继续保存跟踪/风险和明确下界，actual不完整候选不eligible；非法历史普通trial失败。未返回paid成本、returned-unwritten与partial缺失保留。普通失败独立下一trial，中断/IO/任何trace写错误fatal余planned blocked。原 `_archive_record/_exception_snapshot/_write_json`、原 `_risk/_risk_add` 和 `feedback_validate.pd_request`复用，没有身体模型实例/fit/update或额外教师。

tracking保存逐轴及联合RMSE、完整/partial原始errors、固定segment0/1与固定80–99/180–199末20窗口的planned/returned/complete/partial/missing、signed mean。full/prefix/control风险使用全8D速度、子步接触峰/冲量、动能、穿透、guard及限位端点，不只检查所选两轴。源ZIP包含现有全部developmental_physics源码、资产、项目文件、协议、runner和auditor依赖；synthetic另含精确fixture源码。metadata每项SHA与ZIP原字节合同已通过。

选择只考虑同candidate所有声明seed完整且actual覆盖全部paid，不能截短排名；按三seedjoint原始RMSE均值、max轴三seed原始RMSE均值、双轴control实际平方努力均值、candidate索引精确升序。所有候选及失败原因/费用保留；无eligible时picked=null/status=blocked。该选择仅有限固定Kp阻尼开发，不声称全增益最优或身体模型优势。

合成测试另覆盖两轴q/v等值停止、末计划停止、partial/environment主reason、prefix其他轴大速度、paid未返回普通/IO/中断、missing/invalid actual、非finite第7轴、PD-before-step失败、tracefatal、不可行目标与选择层级。source范围检查确认PD数学只接收q/v/current_target/kd且没有Attribute访问；本runner没有直接body-model核心导入、模型创建或拟合。

## 正式采用前仍需要父任务完成

本草案不冻结真实physics、不提交推送、不执行scientific审计。future `scripts/audit_pair_pd.py` 及依赖必须入source ZIP，缺文件禁止正式路径。父任务可按最终审计命名调整AUDITOR_PATH/支持清单。正式路径要求clean来源；每个ZIP原字节Gitblob与exact HEAD:path匹配，metadata记录commit/status/blob。ignored runner/protocol不能在打开flag后冒充tracked来源，必须由root正式推广、检查、提交推送。

synthetic路径不读取Git；sourcecommit/status/dirty=null、blobs={}并明示“not resolved”。没有借用当前clean commit为合成档案制造通过来源。正式源审计与目标/限位/异常/paid窗口标准库重算由独立auditor实施；本交付只有合成合同结果，没有strong baseline、方法收益、技能学习或安全证明。

## 原字节 SHA256

| 文件 | SHA256 |
|---|---|
| `pair_pd_development.py` | `79a8a1a2a4d3b4a80e0582526d6e37aa5579bd309a002028181524d940115e90` |
| `test_pair_pd_development.py` | `e79c942e4387a39f67babc9e852017829871db350bd3ad275da7b3cb53c27fb3` |
| `PROTOCOL.md` | `2c9ada5358e8cad3bf8575274af0d91ce94e582e76d4f750bc8d5bb95df4006b` |
| `synthetic_stdout.txt` | `e9375a72c876507c61c7525503daa7a1619616e69acae80a0f7789f274dcdc6e` |
| `synthetic_tests.xml` | `f0715d9f7fc1069fbee8a570cad9f67c701d99d4d86f09a98dbaae65d5784308` |
| `synthetic_stdout_initial_setup_failure.txt` | `7be6b3e65939df96efb6690a303ec4d99c82935d95e85be110809dd53547db86` |
| `synthetic_tests_initial_setup_failure.xml` | `99f85c1876dd74bfbf38b77de283352f4afb31442aa2b1d7109c96ffe96a575e` |
| `check_scope.py` | `cd3892bf7cf45e45f4f4f472f0ef6a0caa3da1e56c50677e5c09b7a5f0b4309f` |

原始复用源码哈希与依赖版本均见 `scope_inventory.json`。物理calls/substeps0，真实轨迹新增读取0，真实参数拟合0，tracked写入0，Git命令0。
