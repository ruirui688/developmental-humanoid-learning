"""One full synthetic runner/auditor schema integration, never scientific adoption.

All MuJoCo execution/model/data entry points, subprocess/Git and body-model
construction/update entry points are rejected before the collector is used.
This script and the exact fixture are included in the collector source ZIP.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
import traceback


ROOT = next(p for p in Path(__file__).resolve().parents if (p/"pyproject.toml").is_file())
OUTPUT = ROOT/"external/c4_pair_pd_schema_03"
PROCESS_STARTED, PROCESS_CPU_STARTED = time.perf_counter(), time.process_time()
REJECTED_CALLS = []


def write(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False)+"\n", encoding="utf-8")


def main():
    if OUTPUT.exists():
        raise FileExistsError("First integration prefix already exists; no overwrite or rerun")
    OUTPUT.mkdir()
    total_wall, total_cpu = time.perf_counter(), time.process_time()
    blocked_calls, replacements = REJECTED_CALLS, []

    def reject(label):
        def blocked(*args, **kwargs):
            blocked_calls.append(label)
            raise AssertionError("synthetic-only integration rejected "+label)
        return blocked

    for name in ("run", "Popen", "check_output", "check_call", "call"):
        setattr(subprocess, name, reject("subprocess."+name))
        replacements.append("subprocess."+name)
    platform.platform = lambda: "synthetic integration; platform subprocess deliberately not queried"
    # MuJoCo's import selects its native library using platform.system(). On
    # Windows that query may invoke `ver` through subprocess. Use the already
    # available Python/platform environment without a subprocess or host query.
    assert sys.platform == "win32" and os.name == "nt"
    architecture = os.environ.get("PROCESSOR_ARCHITECTURE", "unspecified")
    fixed_uname = platform.uname_result("Windows", "synthetic-no-host-query", "", "", architecture)
    platform.uname = lambda: fixed_uname
    platform.system = lambda: "Windows"
    platform.machine = lambda: architecture
    platform.release = platform.version = platform.processor = platform.node = lambda: ""
    sys.path.insert(0, str(ROOT/"src"))
    sys.path.insert(0, str(ROOT/"external/c4_pair_pd_staging"))
    import mujoco
    # Replace module entry points before importing the runner/environment.
    class RejectedMjModel:
        __new__ = staticmethod(reject("mujoco.MjModel"))
        from_xml_path = staticmethod(reject("mujoco.MjModel.from_xml_path"))
        from_xml_string = staticmethod(reject("mujoco.MjModel.from_xml_string"))
        from_binary_path = staticmethod(reject("mujoco.MjModel.from_binary_path"))
    mujoco.MjModel = RejectedMjModel
    mujoco.MjData = reject("mujoco.MjData")
    replacements.extend(("mujoco.MjModel", "mujoco.MjData"))
    for name in tuple(vars(mujoco)):
        if name.startswith(("mj_", "mju_")) and callable(getattr(mujoco, name)):
            setattr(mujoco, name, reject("mujoco."+name))
            replacements.append("mujoco."+name)
    import pair_pd_development as runner
    import test_pair_pd_development as fixture
    from developmental_physics import local_model, local_pair_model
    for cls in (local_model.LocalBodyModel, local_model.HingeBodyModel,
                local_pair_model.PairBodyModel, local_pair_model.DiagonalPairBodyModel,
                local_pair_model.CoupledPairBodyModel):
        for name in ("__init__", "update"):
            label = cls.__module__+"."+cls.__name__+"."+name
            setattr(cls, name, reject(label))
            replacements.append(label)
    runner._REAL_ENV.__init__ = reject("GroundBodyEnv.__init__")
    replacements.append("GroundBodyEnv.__init__")
    runner.GroundBodyEnv = fixture.SyntheticEnv
    fixture.SyntheticEnv.instances = []
    # The default class declaration has no injected faults or shortened plan.
    assert runner.DEVELOPMENT_SEEDS == (0, 1, 2) and len(runner.FIXED_KD) == 9
    assert runner.PREFIX_STEPS == 100 and runner.CONTROL_STEPS == 200
    assert fixture.SyntheticEnv.fail_step is None and fixture.SyntheticEnv.stop_step is None
    audit_path = ROOT/runner.AUDITOR_PATH
    loader = importlib.util.spec_from_file_location("_schema_pair_pd_audit", audit_path)
    independent = importlib.util.module_from_spec(loader)
    sys.modules[loader.name] = independent
    loader.loader.exec_module(independent)
    source_paths = [Path(__file__), Path(runner.__file__), Path(fixture.__file__), audit_path,
                    independent.COMMON_PATH, runner.MODEL_PATH, ROOT/runner.PROTOCOL_PATH]
    write(OUTPUT/"integration_setup.json", {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "synthetic": True, "science_acceptance": False,
        "rejected_entry_points": replacements,
        "source_sha256": {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                          for p in source_paths},
        "physics_backend": "no MuJoCo execution; deterministic synthetic fixture only",
        "range_origin": "public XML range attributes converted to radians in native joint order",
        "guard_history_origin": "synthetic current-state zero/request projection; repeated fake samples",
    })
    collection_started, collection_cpu = time.perf_counter(), time.process_time()
    collector_error = None
    metadata = None
    try:
        metadata = runner.run_pair_pd(OUTPUT/"raw", protocol_path=ROOT/runner.PROTOCOL_PATH, synthetic=True)
    except BaseException as exc:
        collector_error = {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
        write(OUTPUT/"collector_exception_first.json", collector_error)
    collector_envelope = {"wall_seconds": time.perf_counter()-collection_started,
                          "cpu_seconds": time.process_time()-collection_cpu}
    audit_error, report = None, None
    audit_started, audit_cpu = time.perf_counter(), time.process_time()
    try:
        report = independent.audit(OUTPUT/"raw", git_root=None, spec=independent.DRAFT_SPEC)
        write(OUTPUT/"audit_first.json", report)
    except BaseException as exc:
        audit_error = {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
        write(OUTPUT/"audit_exception_first.json", audit_error)
    audit_envelope = {"wall_seconds": time.perf_counter()-audit_started,
                      "cpu_seconds": time.process_time()-audit_cpu}
    expected_failures = ["source_commit_format", "clean_collection_source"]
    failed_labels = None if report is None else [v["check"] for v in report["violations"]]
    engineering_consistent = (collector_error is None and audit_error is None and not blocked_calls
        and metadata["completed_trials"] == 27 and metadata["control_calls_attempted"] == 8100
        and metadata["control_steps"] == 8100 and metadata["physics_steps"] == 81000
        and report["failed_checks"] == 2 and failed_labels == expected_failures
        and report["validated_selection"] is False)
    accounting = {
        "synthetic": True, "science_acceptance": False,
        "engineering_schema_consistent": engineering_consistent,
        "collector_exception": collector_error, "audit_exception": audit_error,
        "real_physics_steps": 0, "real_environment_calls": 0, "parameter_updates": 0,
        "body_model_constructions": 0, "body_model_fits": 0, "git_calls": 0,
        "rejected_entry_attempts": blocked_calls,
        "synthetic_trial_count": len(fixture.SyntheticEnv.instances),
        "synthetic_control_attempts": None if metadata is None else metadata["control_calls_attempted"],
        "synthetic_returned_calls": None if metadata is None else metadata["control_steps"],
        "synthetic_substeps": None if metadata is None else metadata["physics_steps"],
        "expected_unresolved_source_failures": expected_failures,
        "actual_audit_failure_labels": failed_labels,
        "validated_selection": None if report is None else report["validated_selection"],
        "collector_envelope": collector_envelope, "audit_envelope": audit_envelope,
        "total_wall_seconds": time.perf_counter()-total_wall,
        "total_cpu_seconds": time.process_time()-total_cpu,
        "timing_scope": "one process; total includes guarded setup/imports/source snapshots and first audit; collector metadata keeps its internal timer",
        "claim_boundary": "interface/arithmetical schema integration only; synthetic costs are not physical interaction or learned skill",
    }
    write(OUTPUT/"integration_accounting.json", accounting)
    print(json.dumps(accounting, indent=2, ensure_ascii=False))
    return 0 if engineering_consistent else 1


if __name__ == "__main__":
    try:
        result = main()
    except BaseException as exc:
        if OUTPUT.is_dir() and not (OUTPUT/"integration_setup.json").exists():
            write(OUTPUT/"setup_exception_first.json", {
                "synthetic": True, "science_acceptance": False,
                "status": "setup_failed_before_collection", "type": type(exc).__name__,
                "message": str(exc), "traceback": traceback.format_exc(),
                "real_physics_steps": 0, "synthetic_control_calls": 0, "body_model_fits": 0, "git_calls": 0,
                "rejected_entry_attempts": REJECTED_CALLS,
                "wall_seconds": time.perf_counter()-PROCESS_STARTED,
                "cpu_seconds": time.process_time()-PROCESS_CPU_STARTED,
            })
        raise
    raise SystemExit(result)
