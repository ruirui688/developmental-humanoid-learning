"""Ignored standard-library source/hash inventory; no runner execution."""
import ast
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import xml.etree.ElementTree as ET


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
tree = ast.parse((HERE/"pair_pd_development.py").read_text(encoding="utf-8"))
functions = {node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)}
pd_function = functions["pd_pair_request"]
assert [arg.arg for arg in pd_function.args.args] == ["q", "v", "current_target", "kd"]
pd_calls = sorted({node.func.id for node in ast.walk(pd_function)
                   if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)})
assert set(pd_calls) <= {"len", "ValueError", "pd_request", "range", "tuple"}
assert not any(isinstance(node, ast.Attribute) for node in ast.walk(pd_function))
imports = sorted({node.module if isinstance(node, ast.ImportFrom) else alias.name
                  for node in ast.walk(tree) if isinstance(node, (ast.Import, ast.ImportFrom))
                  for alias in (node.names if isinstance(node, ast.Import) else [None])})
assert not any("local_pair_model" in name or "local_model" in name for name in imports)
assignments = {node.targets[0].id: node.value for node in tree.body
               if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)}
assert ast.literal_eval(assignments["FORMAL_EXECUTION_FROZEN"]) is False
synthetic_git_branch = functions["_source_git_record"].body[0]
assert isinstance(synthetic_git_branch, ast.If) and ast.unparse(synthetic_git_branch.test) == "synthetic"
assert len(synthetic_git_branch.body) == 1 and isinstance(synthetic_git_branch.body[0], ast.Return)
suite = ET.parse(HERE/"synthetic_tests.xml").getroot().find("testsuite")
assert suite is not None and suite.attrib["tests"] == "20"
assert all(suite.attrib[key] == "0" for key in ("errors", "failures", "skipped"))
files = [HERE/"pair_pd_development.py", HERE/"test_pair_pd_development.py", HERE/"PROTOCOL.md",
         HERE/"synthetic_stdout.txt", HERE/"synthetic_tests.xml",
         HERE/"synthetic_stdout_initial_setup_failure.txt", HERE/"synthetic_tests_initial_setup_failure.xml",
         Path(__file__).resolve(), ROOT/"src/developmental_physics/collect.py",
         ROOT/"src/developmental_physics/elbow_feedback_validate.py",
         ROOT/"src/developmental_physics/feedback_validate.py", ROOT/"src/developmental_physics/environment.py",
         ROOT/"src/developmental_physics/probes.py", ROOT/"scripts/audit_local_frozen.py"]
report = {
    "kind": "ignored pair-PD draft; explicitly replaced SyntheticEnv only",
    "runtime": {"python": platform.python_version(), "numpy": importlib.metadata.version("numpy"),
                "mujoco": importlib.metadata.version("mujoco"), "pytest": importlib.metadata.version("pytest")},
    "tests": {"passed": 20, "errors": 0, "failures": 0, "skipped": 0,
              "reported_junit_seconds": suite.attrib["time"], "pytest_stdout_seconds": 11.66},
    "direct_imports": imports, "pd_math_argument_names": [arg.arg for arg in pd_function.args.args],
    "pd_direct_calls": pd_calls, "formal_execution_frozen": False,
    "synthetic_git_branch_returns_before_any_call": True,
    "independent_auditor_required_future_path": "scripts/audit_pair_pd.py",
    "evidence_boundary": {"physical_calls": 0, "physical_substeps": 0, "real_trajectory_reads": 0,
                          "real_parameter_fit": 0, "tracked_files_written": 0, "git_commands": 0,
                          "synthetic_full_plan": {"trials": 27, "calls": 8100, "substeps": 81000},
                          "scientific_selection_claim": False},
    "files_sha256": {str(path.relative_to(ROOT)).replace("\\", "/"):
                     hashlib.sha256(path.read_bytes()).hexdigest() for path in files},
}
(HERE/"scope_inventory.json").write_text(json.dumps(report, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")
print(json.dumps(report, indent=2, ensure_ascii=False))
